from luna3.common.requests import makeRequest
from luna3.common.luna_response import LunaResponse
from typing import Optional, Dict, Generator, Union, List


class FacesApi:
    """
    Class for request to luna-faces.

    Attributes:
        :host (str): luna-faces host, default "127.0.0.1"
        :protocol (str): enum "https" or "http", default "http"
        :port (int): port of luna-faces, default 5030
        :api (int): api version of  luna-faces, default 1
        :lunaRequestId: Luna-Request-Id.
        :asyncRequest (bool): default mode for request async or blocking
    """

    def __init__(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 5030, protocol: Optional[str] = "http",
                 api: Optional[int] = 1, async: Optional[bool] = False, lunaRequestId: Optional[str] = None) -> None:
        self.host = host
        self.port = port
        self.protocol = protocol
        self.api = api
        self.asyncRequest = async
        self.lunaRequestId = lunaRequestId

    def updateSettings(self, **kwargs):
        """
        Update settings (host, port, protocol, api, asyncRequest).

        Keyword Args:
            host (str): host ip, localhost for default
            port (int): host port, 5030 for default
            protocol (str): protocol, http for default
            api (int): api version, 1 for default
            lunaRequestId (str): Luna-Request-Id
        """
        for settings in self.__dict__:
            if settings in kwargs:
                self.__dict__[settings] = kwargs[settings]

    @property
    def baseUri(self) -> str:
        """
        Property get base part of url.
        >>> self.baseUri
        "http://127.0.0.1:5030/1"
        """
        return "{}://{}:{}/{}".format(self.protocol, self.host, self.port, self.api)

    def getAsyncMode(self, async: Optional[bool] = None) -> bool:
        """
        Get final async mode.

        Agrs:
            async (bool): async mode as function argument.
            
        Returns:
            If async is None, return self.asyncRequest else async
        """
        return async if async is not None else self.asyncRequest

    def getRequestIdHeader(self, lunaRequestId: Optional[str] = None) -> Optional[Dict[str, str]]:
        """
        Get final request id.

        Agrs:
            lunaRequestId: Luna-Request-Id as function argument. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
        Returns:
            None if lunaRequestId is None, else return dict with self.lunaRequestId else dict with lunaRequestId
        """
        if lunaRequestId is not None:
            return {"LUNA-Request-Id": lunaRequestId}
        elif self.lunaRequestId is not None:
            return {"LUNA-Request-Id": self.lunaRequestId}
        else:
            return None

    def getVersion(self, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get version of luna-faces

        Agrs:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri[:-2] + "/version", "GET", headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), raiseError=raiseError)

    def createFace(self, accountId: str, attributesId: Optional[str] = None, eventId: Optional[str] = None,
                   userData: Optional[str] = "", externalId: Optional[str] = None,
                   lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                   raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create new face in luna-faces

        Agrs:
            userData: face user data
            eventId: reference to event which created face
            attributesId: attributes id
            accountId: id of account
            externalId: external id of the person, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {"account_id": accountId, "user_data": userData}
        if attributesId is not None:
            body["attributes_id"] = attributesId
        if eventId is not None:
            body["event_id"] = eventId
        if externalId is not None:
            body['external_id'] = externalId
        return makeRequest(self.baseUri + "/faces", "POST", json=body, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def putFace(self, faceId: str, accountId: str, attributesId: Optional[str] = None, eventId: Optional[str] = None,
                userData: Optional[str] = "", lunaRequestId: Optional[bool] = None, async: Optional[bool] = None,
                raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Put face in luna-faces

        Agrs:
            faceId: external face id
            userData: face user data
            eventId: reference to event which created face
            attributesId: attributes id
            accountId: id of account
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {"account_id": accountId, "user_data": userData}
        if attributesId is not None:
            body["attributes_id"] = attributesId
        if eventId is not None:
            body["event_id"] = eventId
        return makeRequest(self.baseUri + "/faces/" + faceId, "PUT", json=body, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def getFaces(self, userData: Optional[str] = None, accountId: Optional[str] = None, eventId: Optional[str] = None,
                 listId: Optional[str] = None, faceIds: Optional[List[str]] = None, timeLt: Optional[str] = None,
                 timeGte: Optional[str] = None, page: Optional[int] = 1, pageSize: Optional[int] = 10,
                 externalId: Optional[str] = None, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                 raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get faces by filters. Optional you can set, that faces must belong to account.

        Agrs:
            userData: user data, part of user data, case insensitive
            accountId account id
            eventId: event id
            listId: list id
            faceIds: face ids
            timeLt: upper bound of face create time
            timeGte: lower bound of face create time
            page: page count, default 1
            pageSize: page size, default 10
            externalId: external id of the person, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"user_data": userData, "account_id": accountId, "event_id": eventId, "list_id": listId,
                   "face_ids": faceIds, "time__lt": timeLt, "time__gte": timeGte, "page": page, "page_size": pageSize,
                   'external_id': externalId}
        return makeRequest(self.baseUri + "/faces", "GET", queryParams=queries, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def deleteFaces(self, faceIds: List[str], accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                    async: Optional[bool] = None,
                    raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete faces. Optional you can set, that faces must belong to account.

        Agrs:
            faceIds: face id list
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        body = {"face_ids": faceIds}
        return makeRequest(self.baseUri + "/faces", "DELETE", queryParams=queries, async=self.getAsyncMode(async),
                           json=body, headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def getFace(self, faceId: str, accountId: Optional[str] = None, externalId: Optional[str] = None,
                lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get face by id. Optional you can set, that face must belongs to account.

        Agrs:
            faceId: face id
            accountId: account id
            async: execution in asynchronous mode, disabled by default
            externalId: external id of the person, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId, 'external_id': externalId}
        return makeRequest("{}/faces/{}".format(self.baseUri, faceId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def updateFace(self, faceId: str, accountId: Optional[str] = None, attributesId: Optional[str] = None,
                   eventId: Optional[str] = None, userData: Optional[str] = None, externalId: Optional[str] = None,
                   lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Update face. You can update event id, user data, attributes id. Optional you can set, that face must belong
        to account.

        Agrs:
            faceId: face id
            accountId: account id
            attributesId: new attributes id
            eventId: new event id
            externalId: external id of the person, if it has its own mapping in the system
            userData: new user data
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async (bool): execution in asynchronous mode, disabled by default
            raiseError (bool): if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {}
        if userData is not None:
            body["user_data"] = userData
        if attributesId is not None:
            body["attributes_id"] = attributesId
        if eventId is not None:
            body["event_id"] = eventId
        if externalId is not None:
            body['external_id'] = externalId
        queries = {"account_id": accountId}
        return makeRequest("{}/faces/{}".format(self.baseUri, faceId), "PATCH", json=body, queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def deleteFace(self, faceId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                   async: Optional[bool] = None,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete face. Optional you can set, that face must belong to account.

        Agrs:
            faceId: face id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/faces/{}".format(self.baseUri, faceId), "DELETE", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def createList(self, accountId: str, userData: Optional[str] = "", listType: Optional[int] = 0,
                   lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create list.

        Agrs:
            accountId: account id
            userData: user data
            listType: list type, 1 - persons, 0 faces
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {"account_id": accountId, "user_data": userData, "type": listType}
        return makeRequest(self.baseUri + "/lists", "POST", json=body, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def deleteLists(self, listIds: List[str], accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                    async: Optional[bool] = None,
                    raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete lists. Optional you can set, that lists must belong to account.

        Agrs:
            listIds: ids of lists
            accountId: account id,
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        body = {"list_ids": listIds}
        return makeRequest(self.baseUri + "/lists", "DELETE", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def getLists(self, userData: Optional[str] = None, accountId: Optional[str] = None, listType=None,
                 page: Optional[int] = 1, pageSize: Optional[int] = 10, lunaRequestId: Optional[str] = None,
                 async: Optional[bool] = None,
                 raiseError=False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get lists. Optional you can set, that lists must belong to account.

        Agrs:
            userData: user data, part of user data, case sensitive
            accountId: account id
            listType: list type, 1 - persons, 0 faces
            page: page, default 1
            pageSize: page size, default 10
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId, "user_data": userData, "page": page, "page_size": pageSize,
                   "type": listType}
        return makeRequest(self.baseUri + "/lists", "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), raiseError=raiseError)

    def getList(self, listId: str, accountId: Optional[str] = None, page: Optional[int] = 1,
                pageSize: Optional[int] = 10, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get list. Optional you can set, that list must belong to account.

        Agrs:
            listId: list id
            accountId: account id
            page: page count, default 1
            pageSize: page size, default 10
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"page": page, "page_size": pageSize, "account_id": accountId}
        return makeRequest("{}/lists/{}".format(self.baseUri, listId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), raiseError=raiseError)

    def deleteList(self, listId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                   async: Optional[bool] = None,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Remove list. Optional you can set, that list must belong to account.

        Agrs:
            listId: list id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/lists/{}".format(self.baseUri, listId), "DELETE", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), raiseError=raiseError)

    def updateListUserData(self, listId: str, userData: str, accountId: Optional[str] = None,
                           lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                           raiseError: Optional[bool] = False) -> \
                           Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Update user data of list. Optional you can set, that list must belong to account.

        Agrs:
            listId: list id
            userData: new user data
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        body = {"user_data": userData}
        return makeRequest("{}/lists/{}".format(self.baseUri, listId), "PATCH", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def link(self, listId: str, faceIds: Optional[List[str]] = None, personIds: Optional[List[str]] = None,
             action: Optional[str] = "attach",
             accountId: Optional[str] = None, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
             raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Attach or detach faces to list. Optional you can set, that list and faces must belong to account.

        Agrs:
            listId: list id
            faceIds: face ids
            personIds: person ids
            action: attach or detach
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        body = {"action": action, "list_id": listId}
        if faceIds is not None:
            body["face_ids"] = faceIds
        else:
            body["person_ids"] = personIds
        return makeRequest("{}/linker".format(self.baseUri), "PATCH", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def getAttributesIdsFromList(self, listId: str, timeLt: Optional[str] = None, timeGte: Optional[str] = None,
                                 page: Optional[int] = 1, pageSize: Optional[int] = 1000,
                                 lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                                 raiseError: Optional[bool] = False) -> \
                                 Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get all ids attributes from list by period.

        Agrs:
            listId: list id
            timeLt: upper bound of face create time
            timeGte: lower bound of face create time
            page: page, default 1
            pageSize: page size, default 1000, max 100000
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"time__lt": timeLt, "time__gte": timeGte, "page": page, "page_size": pageSize}
        return makeRequest("{}/lists/{}/attributes".format(self.baseUri, listId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def createPerson(self, accountId: str, userData: Optional[str] = "", lunaRequestId: Optional[str] = None,
                     async: Optional[bool] = None, raiseError: Optional[bool] = False) -> \
                     Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create list.

        Agrs:
            accountId: account id
            userData: user data
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {"account_id": accountId, "user_data": userData}
        return makeRequest(self.baseUri + "/persons", "POST", json=body,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), raiseError=raiseError)

    def deletePersons(self, personIds: List[str], accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                      async: Optional[bool] = None, raiseError: Optional[bool] = False) -> \
                      Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete lists. Optional you can set, that lists must belong to account.

        Agrs:
            personIds: ids of persons
            accountId: account id,
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        body = {"person_ids": personIds}
        return makeRequest(self.baseUri + "/persons", "DELETE", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), json=body, raiseError=raiseError)

    def getPersons(self, userData: Optional[str] = None, accountId: Optional[str] = None, timeLt: Optional[str] = None,
                   timeGte: Optional[str] = None, personIds: Optional[List[str]] = None,
                   page: Optional[int] = 1, pageSize: Optional[int] = 10, lunaRequestId: Optional[str] = None,
                   async: Optional[bool] = None,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get lists. Optional you can set, that lists must belong to account.

        Agrs:
            userData: user data, part of user data, case sensitive
            accountId: account id
            personIds: list of person ids
            timeLt: upper bound of face create time
            timeGte: lower bound of face create time
            page: page, default 1
            pageSize: page size, default 10
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId, "user_data": userData, "page": page, "page_size": pageSize,
                   "time__lt": timeLt, "time__gte": timeGte, "person_ids": personIds}
        return makeRequest(self.baseUri + "/persons", "GET", queryParams=queries, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def getPerson(self, personId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                  async: Optional[bool] = None,
                  raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get list. Optional you can set, that list must belong to account.

        Agrs:
            personId: person id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/persons/{}".format(self.baseUri, personId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def deletePerson(self, personId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                     async: Optional[bool] = None,
                     raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Remove list. Optional you can set, that list must belong to account.

        Agrs:
            personId: person id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/persons/{}".format(self.baseUri, personId), "DELETE", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def updatePersonUserData(self, personId: str, userData: str, accountId: Optional[str] = None,
                             lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                             raiseError: Optional[bool] = False) -> \
                             Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Update user data of person. Optional you can set, that list must belong to account.

        Agrs:
            personId: person id
            userData: new user data
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        body = {"user_data": userData}
        return makeRequest("{}/persons/{}".format(self.baseUri, personId), "PATCH", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def linkFaceToPerson(self, faceId: str, personId: str, action: Optional[str] = "attach",
                         accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                         async: Optional[bool] = None, raiseError: Optional[bool] = False) -> \
                         Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Attach or detach face to person.Optional you can set, that list must belong to account.

        Agrs:
            faceId: face id
            personId: person id
            action: attach or detach face from person
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"account_id": accountId}
        body = {"person_id": personId, "face_id": faceId, "action": action}
        return makeRequest("{}/facelinker".format(self.baseUri), "PATCH", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)
