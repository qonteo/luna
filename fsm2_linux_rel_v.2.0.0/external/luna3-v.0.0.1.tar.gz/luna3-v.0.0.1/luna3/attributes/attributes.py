from luna3.common.requests import makeRequest
from luna3.common.base_api import BaseAPI
from luna3.common.luna_response import LunaResponse
from typing import Optional, List, Generator, Union


class AttributesApi(BaseAPI):
    """
    Class for request to luna-attributes.

    Attributes:
        :host (str): luna-attributes host, default "127.0.0.1"
        :protocol (str): enum "https" or "http", default "http"
        :port (int): port of luna-events, default 5050
        :api (int): api version of  luna-events, default 1
        :lunaRequestId: Luna-Request-Id.
        :asyncRequest (bool): default mode for request async or blocking
    """
    def __init__(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 5050, protocol: Optional[str] = "http",
                 api: Optional[int] = 1, async: Optional[bool] = False, lunaRequestId: Optional[str] = None) -> None:
        super().__init__(port, host, protocol, api, async, lunaRequestId)

    def getAttributes(self, objects: List[str], samples: int, retrive: str, lunaRequestId: Optional[str] = None,
                      async: Optional[bool] = None,
                      raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get list of attributes

        Agrs:
            objects: list of attributes to delete
            attributeId: attribute id
            samples: samples from which the attributes were extracted.
            retrive: List of attributes splitted by comma. Retrive only them. By default return all attributes.
                     descriptor, age, gender

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {'objects': objects}
        queries = {'samples': samples, 'retrive': retrive}
        return makeRequest(self.baseUri + "/attributes", "GET", queryParams=queries, body=body,
                           async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def createAttributes(self, descriptor: str, descriptor_samples: List[str], gender: int, gender_samples: List[str],
                         age: int, age_samples: List[str], lunaRequestId: Optional[str] = None,
                         async: Optional[bool] = None,
                         raiseError: Optional[bool] = False) -> Union[
                         Generator[LunaResponse, None, None], LunaResponse]:
        """
        Create new attributes

        Agrs:
            descriptor: binary descriptor encode in base64 string.
            descriptor_samples: list of warp image id from which the attribute was extracted.
            gender: Gender. 0 - man, 1 - woman.
            gender_samples: list of warp image id from which the attribute was extracted.
            age: age from 0 to 100.
            age_samples: list of warp image id from which the attribute was extracted.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {'descriptor': descriptor}
        if descriptor_samples is not None:
            body['descriptor_samples'] = descriptor_samples
        if gender is not None:
            body['gender'] = gender
        if gender_samples is not None:
            body['gender_samples'] = gender_samples
        if age is not None:
            body['age'] = age
        if age_samples is not None:
            body['age_samples'] = age_samples
        return makeRequest(self.baseUri + "/attributes", "POST", json=body, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def deleteAttributes(self, objects: List[str], lunaRequestId: Optional[str] = None,
                         async: Optional[bool] = None,
                         raiseError: Optional[bool] = False) -> Union[
                         Generator[LunaResponse, None, None], LunaResponse]:
        """
        Delete list of attributes

        Agrs:
            objects: list of attributes to delete

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {'objects': objects}
        return makeRequest(self.baseUri + "/attributes", "DELETE", json=body, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def optionsAttributes(self, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                          raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Returns allowed request methods and all attributes.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri + "/attributes", "OPTIONS", async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def getAttribute(self, attributeId: str, samples: int, retrive: str, lunaRequestId: Optional[str] = None,
                     async: Optional[bool] = None,
                     raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Retrieve a attributes by id.

        Agrs:
            attributeId: attribute id
            samples: samples from which the attributes were extracted.
            retrive: List of attributes splitted by comma. Retrive only them. By default return all attributes.
                     descriptor, age, gender

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'samples': samples, 'retrive': retrive}
        return makeRequest(self.baseUri + "/attributes/" + attributeId, "GET", queryParams=queries,
                           async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def createAttribute(self, attributeId: str, descriptor: str, descriptor_samples: List[str], gender: int,
                        gender_samples: List[str], age: int, age_samples: List[str],
                        lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                        raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create new attributes with specified id

        Agrs:
            attributeId: attribute id
            descriptor: binary descriptor encode in base64 string.
            descriptor_samples: list of warp image id from which the attribute was extracted.
            gender: Gender. 0 - man, 1 - woman.
            gender_samples: list of warp image id from which the attribute was extracted.
            age: age from 0 to 100.
            age_samples: list of warp image id from which the attribute was extracted.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {'descriptor': descriptor}
        if descriptor_samples is not None:
            body['descriptor_samples'] = descriptor_samples
        if gender is not None:
            body['gender'] = gender
        if gender_samples is not None:
            body['gender_samples'] = gender_samples
        if age is not None:
            body['age'] = age
        if age_samples is not None:
            body['age_samples'] = age_samples
        return makeRequest(self.baseUri + "/attributes/" + attributeId, "PUT", json=body,
                           async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def updateAttribute(self, attributeId: str, descriptor: str, descriptor_samples: List[str], gender: int,
                        gender_samples: List[str], age: int, age_samples: List[str],
                        lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                        raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Update attribute with specified id

        Agrs:
            attributeId: attribute id
            descriptor: binary descriptor encode in base64 string.
            descriptor_samples: list of warp image id from which the attribute was extracted.
            gender: Gender. 0 - man, 1 - woman.
            gender_samples: list of warp image id from which the attribute was extracted.
            age: age from 0 to 100.
            age_samples: list of warp image id from which the attribute was extracted.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {'descriptor': descriptor}
        if descriptor_samples is not None:
            body['descriptor_samples'] = descriptor_samples
        if gender is not None:
            body['gender'] = gender
        if gender_samples is not None:
            body['gender_samples'] = gender_samples
        if age is not None:
            body['age'] = age
        if age_samples is not None:
            body['age_samples'] = age_samples
        return makeRequest(self.baseUri + "/attributes/" + attributeId, "PATCH", json=body,
                           async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def deleteAttribute(self, attributeId: str, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                        raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete attribute with specifeid id

        Agrs:
            attributeId: attribute id

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri + "/attributes/" + attributeId, "DELETE", async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)
