from typing import List, Union, Optional, Generator
from luna3.common.base_api import BaseAPI
from luna3.common.http_objs import Image
from luna3.common.multipart import asyncMultipartProducer, createMultipart
from luna3.common.requests import makeRequest
from luna3.common.luna_response import LunaResponse


class CoreAPI(BaseAPI):
    """
    CoreAPI class set provides low level building blocks for face analysis and recognition services.

    Attributes:
        :host (str): luna-core host, default "127.0.0.1"
        :protocol (str): enum "https" or "http", default "http"
        :port (int): port of luna-core, default 8083
        :api (int): api version of  luna-core, default 13
        :lunaRequestId: Luna-Request-Id.
        :asyncRequest (bool): default mode for request async or blocking
    """

    def __init__(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 8083, protocol: Optional[str] = "http",
                 api: Optional[int] = 13, async: Optional[bool] = False, lunaRequestId: Optional[str] = None):
        super().__init__(port, host, protocol, api, async, lunaRequestId)

    def extractDescriptor(self, images: Union[Image, List[Image]], lunaRequestId: Optional[str] = None,
                          lunaOutputDescriptorID: Optional[str] = None, estimateBasicAttributes: Optional[bool] = None,
                          estimateEyesAttributes: Optional[bool] = None, estimateMouthAttributes: Optional[bool] = None,
                          estimateHeadPose: Optional[bool] = None, estimateGaze: Optional[bool] = None,
                          estimateEmotions: Optional[bool] = None, estimateQuality: Optional[bool] = None,
                          detectLandmarks5: Optional[bool] = None, detectLandmarks68: Optional[bool] = None,
                          scoreThreshold: Optional[float] = None, extractDescriptor: Optional[bool] = None,
                          aggregateDescriptor: Optional[bool] = None, extractExif: Optional[bool] = None,
                          warpedImage: Optional[bool] = None, temporary: Optional[bool] = None,
                          async: Optional[bool] = None, asyncRequest: Optional[bool] = False,
                          raiseError: \
                                  Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create face descriptors from images.

        Args:
            images: Single image or images list for extraction.
            lunaOutputDescriptorID: Optional header to specify descriptor id to be used for DB storage
                        instead of auto-generated one.
                        This header may also be specified on per-part basis when posting multipart/form-data requests.
                        Only supported with warped images.Pattern:
                        ^[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$
            estimateBasicAttributes: Whether to estimate basic face attributes from the image.
            estimateEyesAttributes: Whether to estimate eye attributes from the image.
                        Not supported with warped images
            estimateMouthAttributes: Whether to estimate mouth attributes from the image.
            estimateHeadPose: Whether to estimate head pose from the image.
                        Not supported with warped images.
            estimateGaze: Whether to estimate eye gaze from the image.
                        Not supported with warped images.
            estimateEmotions: Whether to estimate emotions from the image.
            estimateQuality: Whether to estimate input face image quality.
            detectLandmarks5: Whether to detect basic 5-point facial landmarks on the image.
                                Not supported with warped images.
            detectLandmarks68: Whether to detect extended 68-point facial landmarks on the image.
                                Not supported with warped images.
            scoreThreshold: All the face descriptors with quality score below the threshold will be ignored.
            extractDescriptor: Whether to extract face descriptor(s).
            aggregateDescriptor: Whether to aggregate face descriptor(s).
                                Only supported with warped images.
            extractExif: Whether to extract EXIF meta information from input JPEG images.
            warpedImage: Whether input image is a warped or arbitrary image.
            temporary: Switch between temporary and persistent DB storage policy.
            async: Switch between asynchronous and synchronous task processing.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = {}
        requestId = self.getRequestIdHeader(lunaRequestId)
        if requestId:
            headers.update(requestId)
        if lunaOutputDescriptorID is not None and isinstance(images, Image):
            headers["LUNA-Output-Descriptor-ID"] = lunaOutputDescriptorID

        if isinstance(images, list):
            multipartBoundary = "LUNACOREB0UnDaRyStRiNg"
            headers['Content-Type'] = 'multipart/form-data; boundary={}'.format(multipartBoundary)
        else:
            headers['Content-Type'] = images.mimetype

        queries = {}
        boolean_args = {
            "estimate_basic_attributes": estimateBasicAttributes,
            "estimate_eyes_attributes": estimateEyesAttributes,
            "estimate_mouth_attributes": estimateMouthAttributes,
            "estimate_head_pose": estimateHeadPose,
            "estimate_gaze": estimateGaze,
            "estimate_emotions": estimateEmotions,
            "estimate_quality": estimateQuality,
            "detect_landmarks5": detectLandmarks5,
            "detect_landmarks68": detectLandmarks68,
            "extract_descriptor": extractDescriptor,
            "aggregate_descriptor": aggregateDescriptor,
            "extract_exif": extractExif,
            "warped_image": warpedImage,
            "temporary": temporary,
            "async": async,
        }
        for k, v in boolean_args.items():
            if v is not None:
                queries[k] = int(v)
        if scoreThreshold is not None:
            queries["score_threshold"] = scoreThreshold

        bodyImages = {}
        asyncMode = self.getAsyncMode(asyncRequest)

        if isinstance(images, list):
            if asyncMode:
                bodyImages['body_producer'] = lambda x: asyncMultipartProducer(multipartBoundary, images, x)
            else:
                bodyImages['body'] = createMultipart(multipartBoundary, images)
        elif isinstance(images, Image):
            bodyImages['body'] = images.body
        else:
            raise ValueError('At least one image is required')

        return makeRequest(self.baseUri + "/extractor", "POST", queryParams=queries, headers=headers,
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError, **bodyImages)

    def getDescriptor(self, descriptorID: str, temporary: Optional[bool] = None, accept: Optional[str] = '*/*',
                      lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = False,
                      raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Retrieve a descriptor by id.

        Args:
            descriptorID: string - pattern: ^[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$
            temporary: Switch between temporary and persistent DB storage policy.
            accept: Output data format mime type. application/x-vl-xpk or application/x-vl-face-descriptor.
                        if default */* as accepted type, XPK format is picked.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """

        headers = {'Accept': accept}
        requestId = self.getRequestIdHeader(lunaRequestId)
        if requestId:
            headers.update(requestId)

        queries = {'id': descriptorID}
        if temporary is not None:
            queries['temporary'] = int(temporary)

        return makeRequest(self.baseUri + '/descriptors', 'GET', queryParams=queries, headers=headers,
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def uploadDescriptor(self, contentType: str, descriptorInBytes: bytes, lunaRequestId: Optional[str] = None,
                         temporary: Optional[bool] = None, asyncRequest: Optional[bool] = False,
                         raiseError: Optional[bool] = False) \
            -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Upload an existing descriptor.

        Args:
            contentType: application/x-vl-xpk or application/x-vl-face-descriptor
            descriptorInBytes: byte's array (descriptor)
            temporary: Switch between temporary and persistent DB storage policy.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """

        queries = {}
        if temporary is not None:
            queries['temporary'] = int(temporary)

        headers = {"Content-Type": contentType}
        requestId = self.getRequestIdHeader(lunaRequestId)
        if requestId is not None:
            headers.update(requestId)
        return makeRequest(self.baseUri + '/descriptors', 'POST', queryParams=queries, headers=headers,
                           body=descriptorInBytes, async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def replaceDescriptor(self, descriptorID: str, contentType: str, descriptorInBytes: bytes,
                          temporary: Optional[str] = None, lunaRequestId: Optional[str] = None,
                          asyncRequest: Optional[bool] = False, raiseError: Optional[bool] = False) \
            -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Upload an existing descriptor with given id.

        Args:
            descriptorID: string - pattern: ^[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$
            contentType: application/x-vl-xpk or application/x-vl-face-descriptor
            descriptorInBytes: byte's array (descriptor)
            temporary: Switch between temporary and persistent DB storage policy.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """

        queries = {'id': descriptorID}
        if temporary is not None:
            queries['temporary'] = int(temporary)

        headers = {"Content-Type": contentType}
        requestId = self.getRequestIdHeader(lunaRequestId)
        if requestId is not None:
            headers.update(requestId)
        return makeRequest(self.baseUri + '/descriptors', 'PUT', queryParams=queries, headers=headers,
                           body=descriptorInBytes, async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def deleteDescriptor(self, descriptorIDs: List[str], temporary: str = None, lunaRequestId: Optional[str] = None,
                         asyncRequest: Optional[bool] = False, raiseError: Optional[bool] = False) \
            -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Remove a descriptor from DB by id

        Args:
            descriptorIDs: list of string - pattern:
                                        ^[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$
            temporary: Switch between temporary and persistent DB storage policy.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """

        queries = {}
        if temporary is not None:
            queries['temporary'] = int(temporary)

        return makeRequest(self.baseUri + '/descriptors', 'DELETE', queryParams=queries,
                           json={'ids': descriptorIDs}, headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def countDescriptors(self, temporary: Optional[str] = None, lunaRequestId: Optional[str] = None,
                         asyncRequest: Optional[bool] = False, raiseError: Optional[bool] = False) \
            -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Counts all descriptors stored within the given storage policy and returns their number.

        Args:
            temporary: Switch between temporary and persistent DB storage policy.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """

        queries = {}
        if temporary is not None:
            queries['temporary'] = int(temporary)

        return makeRequest(self.baseUri + '/descriptors/count', 'GET', queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def match(self, reference: str, candidates: Optional[List[str]] = None, lists: Optional[List[str]] = None,
              temporary: Optional[bool] = None, limit: Optional[int] = None, lunaRequestId: Optional[str] = None,
              async: Optional[bool] = None, asyncRequest: Optional[bool] = False,
              raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Match reference descriptor to candidates and get the most similar results.

        Args:
            reference: Reference descriptor id.
            candidates: Array of candidate descriptor ids.
            lists: Array of candidate descriptor list ids.
            limit: Maximum number of matching descriptors to return. Ftom 1 to 5.
            temporary: Whether the reference descriptor should be taken from temporary storage
            async: Switch between asynchronous and synchronous task processing.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """

        queries = {'reference': reference}
        if async is not None:
            queries['async'] = int(async)

        body = {'reference': reference}
        if lists is not None:
            body['lists'] = lists
        else:
            body['candidates'] = candidates
        if temporary is not None:
            body['temporary'] = temporary
        if limit is not None:
            body['limit'] = limit

        return makeRequest(self.baseUri + '/matcher', 'POST', queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def createList(self, descriptorIDs: List[str], lunaRequestId: Optional[str] = None,
                   asyncRequest: Optional[bool] = False,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create a new list.

        Args:
            descriptorIDs: list of descriptor ids
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """

        return makeRequest(self.baseUri + '/lists', 'POST', json={'data': descriptorIDs},
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def getList(self, listId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                asyncRequest: Optional[bool] = False,
                raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Retrieve a list by id.
        If no id is specified, returns a list of all lists in the DB.

        Args:
            listId: List unique identifier.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri + '/lists', 'GET', queryParams={'id': listId},
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def replaceList(self, listId: str, data: List[str], lunaRequestId: Optional[str] = None,
                    asyncRequest: Optional[bool] = False,
                    raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Replace list data by id.

        Args:
            listId: list to be replaced.
            data: new data for list.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        json_ = {'mode': 'put', 'data': data}
        return makeRequest(self.baseUri + '/lists', 'PUT', queryParams={'id': listId}, json=json_,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def appendList(self, listId: str, data: List[str], lunaRequestId: Optional[str] = None,
                   asyncRequest: Optional[bool] = False,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Append list data by id.

        Args:
            listId: list to be appended.
            data: new data for list.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        json_ = {'mode': 'patch', 'data': data}
        return makeRequest(self.baseUri + '/lists', 'PUT', queryParams={'id': listId}, json=json_,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def deleteList(self, listIds: List[str], lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = False,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Remove a list from DB by id.

        Args:
            listIds: list of string - pattern:
                        ^[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri + '/lists', 'DELETE',
                           json={'ids': listIds}, headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def getExtractorResults(self, taskID: str, lunaRequestId: Optional[str] = None,
                            asyncRequest: Optional[bool] = False, raiseError: Optional[bool] = False) \
            -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get task result by id.

        Args:
            taskID: Task id.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri + '/results/extractor', 'GET', queryParams={'id': taskID},
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)

    def getMatchResults(self, taskID: str, limit: Optional[int] = None, lunaRequestId: Optional[str] = None,
                        asyncRequest: Optional[bool] = False, raiseError: Optional[bool] = False) \
            -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get task result by id.

        Args:
            taskID: Task id.
            limit: Maximum number of matching descriptors to return. Ftom 1 to 5.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'limit': limit}
        if taskID is not None:
            queries['id'] = taskID
        return makeRequest(self.baseUri + '/results/matcher', 'GET', queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(asyncRequest), raiseError=raiseError)
