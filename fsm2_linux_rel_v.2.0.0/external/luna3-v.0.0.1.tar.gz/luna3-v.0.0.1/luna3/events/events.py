from luna3.common.requests import makeRequest
from luna3.common.base_api import BaseAPI
from luna3.common.luna_response import LunaResponse
from typing import Optional, List, Generator, Union


class EventsApi(BaseAPI):
    """
    Class for request to luna-events.

    Attributes:
        :host (str): luna-events host, default "127.0.0.1"
        :protocol (str): enum "https" or "http", default "http"
        :port (int): port of luna-events, default 5040
        :api (int): api version of  luna-events, default 1
        :lunaRequestId: Luna-Request-Id.
        :asyncRequest (bool): default mode for request async or blocking
    """

    def __init__(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 5040, protocol: Optional[str] = "http",
                 api: Optional[int] = 1, async: Optional[bool] = False, lunaRequestId: Optional[str] = None) -> None:
        super().__init__(port, host, protocol, api, async, lunaRequestId)

    def putEvents(self, events: Optional[List[str]], lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                  raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Put events to luna-events.

        Args:
            events: list of events. Every event is following dict:
                    .. json:object:: event
                        :showexample:
        
                        :property account_id UUID4: account id, required
                        :property create_time iso8601: create time, required
                        :property event_id UUID4: event id, required
                        :property descriptor_id UUID4: descriptor id, required, unique
                        :property attribute_id UUID4: attribute id
                        :property source street_address: source
                        :property top_similar_face_id UUID4: sim face id
                        :property top_similar_face_list UUID4: sim face list
                        :property top_similar_face_similarity float: most similar face similarity
                        :property match_result object: match result
                        :property extract_result object: extract result
                        :property face_id UUID4: face id
                        :property attach_result object: attach result
                        :property gender boolean: gender
                        :property age _range_100: age
                        :property head_angle str: dot-separated head angles
                        :property emotion _enum_anger_disgust_fear_happiness_neutral_sadness: emotion
                        :property race _enum_white_black_red_yellow: race
                        :property tags _list_str: tag list
                        :property user_data user_name: user data
                        :property sample_ids _list_(UUID4): user data

            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            
        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*. 
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri + "/events", "PUT", json=events, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def getEvents(self, target: Optional[List[str]] = None, createTimeGte: Optional[str] = None,
                  createTimeLt: Optional[str] = None, accountId: Optional[str] = None,
                  eventIds: Optional[List[str]] = None, topSimilarFaceList: Optional[List[str]] = None,
                  topSimilarFaceIds: Optional[List[str]] = None, topSimilarFaceSimGte: Optional[str] = None,
                  topSimilarFaceSimLt: Optional[str] = None, ageLt: Optional[int] = None, ageGte: Optional[int] = None,
                  gender: Optional[int] = None, emotions: Optional[str] = None, headAngles: Optional[int] = None,
                  faceIds: Optional[List[str]] = None, userData: Optional[str] = None, page: Optional[int] = 1,
                  pageSize: Optional[int] = 10, order: Optional[str] = "desc", sources: Optional[List[str]] = None,
                  tags: Optional[List[str]] = None, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                  raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get events by filters.

        Args:
            target: list of events' fields to receive instead of full events,
                    fields should be from ("account_id", "create_time", "event_id", "descriptor_id",
                    "attribute_id", "source", "top_similar_face_id", "top_similar_face_list",
                    "top_similar_face_sim", "match_result", "extract_result", "face_id", "attach_result",
                    "gender", "age", "head_angle", "emotion", "race", "tags", "user_data", "sample_ids")

            createTimeGte:  lower including create time boundary
            createTimeLt: upper excluding create time boundary
            accountId: event account id
            faceIds: ids of faces linked with an event
            eventIds: event ids
            userData: event user data
            sources: list of source
            tags: users tags
            topSimilarFaceList: searched Luna API list
            topSimilarFaceIds: top similar face ids
            topSimilarFaceSimGte: lower including top similarity boundary
            topSimilarFaceSimLt: upper excluding top similarity boundary
            ageLt: upper excluding age boundary
            ageGte: lower including age boundary
            gender: gender of event (0 or 1)
            emotions: dominant emotions in event (one of "anger", "disgust", "fear", "happiness", "neutral",
                        "sadness"
            headAngles: head angle(0, 1, 2)
            page: number of result page
            pageSize: count of results in page
            order: result sort order (ask or desc)
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            
        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*. 
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'target': target, "create_time__gte": createTimeGte, "account_id": accountId, "event_ids": eventIds,
                   "top_similar_face_list": topSimilarFaceList, "top_similar_face_ids": topSimilarFaceIds,
                   "top_similar_face_sim__gte": topSimilarFaceSimGte, "top_similar_face_sim__lt": topSimilarFaceSimLt,
                   "age__lt": ageLt, "age__gte": ageGte, "gender": gender, "emotions": emotions,
                   "head_angles": headAngles,
                   "user_data": userData, "create_time__lt": createTimeLt, "tags": tags, "face_ids": faceIds,
                   "sources": sources, "page": page, "page_size": pageSize, "order": order}
        return makeRequest(self.baseUri + "/events", "GET", async=self.getAsyncMode(async), queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def getEventsStats(self, aggregator: str, groupBy: str, target: List[str], createTimeGte: Optional[str] = None,
                       createTimeLt: Optional[str] = None, topSimilarFaceSimGte: Optional[str] = None,
                       topSimilarFaceSimLt: Optional[str] = None, ageLt: Optional[int] = None,
                       ageGte: Optional[int] = None, accountId: Optional[str] = None,
                       eventIds: Optional[List[str]] = None, faceIds: Optional[List[str]] = None,
                       topSimilarFaceList: Optional[List[str]] = None, topSimilarFaceIds: Optional[List[str]] = None,
                       gender: Optional[int] = None, emotions: Optional[str] = None, headAngles: Optional[int] = None,
                       userData: Optional[str] = None, sources: Optional[str] = None, tags: Optional[List[str]] = None,
                       lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                       raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get events statistics by aggregation (<aggregator> and <groupBy> on <target>) and filters.

        Args:
            aggregator: aggregation type, one of max, min, avg or count
            groupBy: group by time period (1d, 5m, etc.) or frequency grouping (dayOfWeek, monthOfYear, etc.)
            target: list of events' fields to aggregate, note that avg, min and max aggregations only avaible for
                           numeric fields, fields should be from ("account_id", "create_time", "event_id", 
                           "descriptor_id", "attribute_id", "source", "top_similar_face_id", "top_similar_face_list", 
                           "top_similar_face_sim", "match_result", "extract_result", "face_id", "attach_result", 
                           "gender", "age", "head_angle", "emotion", "race", "tags", "user_data", "sample_ids")

            createTimeGte:  lower including create time boundary
            createTimeLt: upper excluding create time boundary
            accountId: event account id
            faceIds: ids of faces linked with an event
            eventIds: event ids
            userData: event user data
            sources: list of source
            tags: users tags
            topSimilarFaceList: searched Luna API list
            topSimilarFaceIds: top similar face ids
            topSimilarFaceSimGte: lower including top similarity boundary
            topSimilarFaceSimLt: upper excluding top similarity boundary
            ageLt: upper excluding age boundary
            ageGte: lower including age boundary
            gender: gender of event (0 or 1)
            emotions: dominant emotions in event (one of "anger", "disgust", "fear", "happiness", "neutral", "sadness")
            headAngles: head angle(0, 1, 2)
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            
        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*. 
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"aggregator": aggregator, "group_by": groupBy, "target": target, "create_time__gte": createTimeGte,
                   "account_id": accountId, "event_ids": eventIds, "top_similar_face_list": topSimilarFaceList,
                   "top_similar_face_ids": topSimilarFaceIds, "top_similar_face_sim__gte": topSimilarFaceSimGte,
                   "top_similar_face_sim__lt": topSimilarFaceSimLt, "age__lt": ageLt, "age__gte": ageGte,
                   "gender": gender, "emotions": emotions, "head_angles": headAngles, "user_data": userData,
                   "create_time__lt": createTimeLt, "tags": tags, "face_ids": faceIds, "sources": sources}
        return makeRequest(self.baseUri + "/events_stats", "GET", async=self.getAsyncMode(async),
                           queryParams=queries, headers=self.getRequestIdHeader(lunaRequestId),
                           raiseError=raiseError)
