from luna3.common.requests import makeRequest
from luna3.common.luna_response import LunaResponse
from typing import Optional, Dict, Generator, Union, List


class StoreApi:
    """
    Class for request to luna-image-store.

    Attributes:
        :host (str): luna-image-store host, default "127.0.0.1"
        :protocol (str): enum "https" or "http", default "http"
        :port (int): port of luna-image-store, default 5020
        :api (int): api version of luna-image-store, default 1
        :asyncRequest (bool): default mode for request async or blocking
        :lunaRequestId: Luna-Request-Id.
    """

    def __init__(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 5030, protocol: Optional[str] = "http",
                 api: Optional[int] = 1, async: Optional[bool] = False, lunaRequestId: Optional[str] = None) -> None:
        self.host = host
        self.port = port
        self.protocol = protocol
        self.api = api
        self.asyncRequest = async
        self.lunaRequestId = lunaRequestId

    def updateSettings(self, **kwargs):
        """
        Update settings (host, port, protocol, api, asyncRequest).

        Keyword Args:
            host (str): host ip, localhost for default
            port (int): host port, 5030 for default
            protocol (str): protocol, http for default
            api (int): api version, 1 for default
            lunaRequestId (str): Luna-Request-Id
        """
        for settings in self.__dict__:
            if settings in kwargs:
                self.__dict__[settings] = kwargs[settings]

    @property
    def baseUri(self) -> str:
        """
        Property get base part of url.
        >>> self.baseUri
        "http://127.0.0.1:5030/1"
        """
        return "{}://{}:{}/{}".format(self.protocol, self.host, self.port, self.api)

    def getAsyncMode(self, async: Optional[bool] = False) -> bool:
        """
        Get final async mode.

        Agrs:
            async (bool): async mode as function argument.

        Returns:
            If async is None, return self.asyncRequest else async
        """
        return async if async is not None else self.asyncRequest

    def getRequestIdHeader(self, lunaRequestId: Optional[str] = None) -> Optional[Dict[str, str]]:
        """
        Get final request id.

        Agrs:
            lunaRequestId: Luna-Request-Id as function argument. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
        Returns:
            None if lunaRequestId is None, else return dict with self.lunaRequestId else dict with lunaRequestId
        """
        if lunaRequestId is not None:
            return {"LUNA-Request-Id": lunaRequestId}
        elif self.lunaRequestId is not None:
            return {"LUNA-Request-Id": self.lunaRequestId}
        else:
            return None

    def getVersion(self, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                   raiseError: Optional[bool] = False) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get version of luna-image-store

        Agrs:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*. 
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri[:-2] + "/version", "GET", headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), raiseError=raiseError)

    def createBucket(self, bucketName: Optional[str] = '', lunaRequestId: Optional[str] = None,
                     async: Optional[bool] = None,
                     raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create bucket with bucketName.

        Agrs:
            bucketName: bucket's name
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"bucket": bucketName}
        return makeRequest(self.baseUri + '/buckets', 'POST', queryParams=queries, async=self.getAsyncMode(async),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError)

    def getBuckets(self, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                   raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get buckets with lunaRequestId.

        Agrs:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri + '/buckets', 'GET', headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), raiseError=raiseError)

    def postImage(self, imageInBytes: bytearray, bucketName: str, contentType: Optional[str] = "image/jpeg",
                  createThumbnails: Optional[int] = 0, lunaRequestId: Optional[str] = None,
                  async: Optional[bool] = None,
                  raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Post an image to bucket.

        Agrs:
            imageInBytes: byte's array (image)
            bucketName: bucket's name
            contentType: content-type of image or image/jpeg for default
            createThumbnails: thumbnails creation's flag
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"thumbnails": createThumbnails}
        headers = {"Content-Type": contentType}
        requestId = self.getRequestIdHeader(lunaRequestId)
        if requestId is not None:
            headers.update(requestId)
        return makeRequest('{}/buckets/{}/images'.format(self.baseUri, bucketName), 'POST', queryParams=queries,
                           headers=headers, body=imageInBytes, async=self.getAsyncMode(async), raiseError=raiseError)

    def putImage(self, imageInBytes, imageId, bucketName, contentType: Optional[str] = "image/jpeg",
                 createThumbnails: Optional[int] = 0, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                 raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Put an image to bucket.

        Agrs:
            imageInBytes: byte's array (image)
            imageId: image id
            bucketName: bucket's name
            contentType: content-type of image or image/jpeg for default
            createThumbnails: thumbnails creation's flag
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"thumbnails": createThumbnails}
        headers = {"Content-Type": contentType}
        requestId = self.getRequestIdHeader(lunaRequestId)
        if requestId is not None:
            headers.update(requestId)
        return makeRequest('{}/buckets/{}/images/{}'.format(self.baseUri, bucketName, imageId), 'PUT',
                           queryParams=queries, headers=headers, body=imageInBytes, async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def getImage(self, bucketName: str, imageId: str, lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                 raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get image from bucket.

        Agrs:
            bucketName: bucket's name
            imageId: external image id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/images/{}'.format(self.baseUri, bucketName, imageId), 'GET',
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def deleteImage(self, bucketName: str, imageId: str, lunaRequestId: Optional[str] = None,
                    async: Optional[bool] = None,
                    raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete image from bucket.

        Agrs:
            bucketName: bucket's name
            imageId: image id to delete
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/images/{}'.format(self.baseUri, bucketName, imageId), 'DELETE',
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def deleteImages(self, bucketName: str, imageIds: List[str], lunaRequestId: Optional[str] = None,
                     async: Optional[bool] = None,
                     raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete images from bucket.

        Agrs:
            bucketName: bucket's name
            imageIds: images ids to delete
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/images'.format(self.baseUri, bucketName), 'DELETE', json={'images': imageIds},
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def postObject(self, objectBody: str, bucketName: str, contentType: Optional[str] = "application/json",
                   lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                   raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Post object to bucket.

        Args:
            objectBody: object, available: text, json
            bucketName: bucket's name
            contentType: content-type of object or application/json for default
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = {"Content-Type": contentType}
        requestId = self.getRequestIdHeader(lunaRequestId)
        if requestId is not None:
            headers.update(requestId)
        return makeRequest('{}/buckets/{}/objects'.format(self.baseUri, bucketName), 'POST', headers=headers,
                           body=objectBody, async=self.getAsyncMode(async), raiseError=raiseError)

    def putObject(self, objectBody: str, objectId: str, bucketName: str,
                  contentType: Optional[str] = "application/json", lunaRequestId: Optional[str] = None,
                  async: Optional[bool] = None,
                  raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Put object to bucket.

        Agrs:
            obj: object, available: text, json
            objectId: object id
            bucketName: bucket's name
            contentType: content-type of object or application/json for default
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = {"Content-Type": contentType}
        requestId = self.getRequestIdHeader(lunaRequestId)
        if requestId is not None:
            headers.update(requestId)
        return makeRequest('{}/buckets/{}/objects/{}'.format(self.baseUri, bucketName, objectId), 'PUT',
                           headers=headers, body=objectBody, async=self.getAsyncMode(async), raiseError=raiseError)

    def getObject(self, bucketName: str, objectId: str, acceptType: Optional[str] = None,
                  lunaRequestId: Optional[str] = None, async: Optional[bool] = None,
                  raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get object from bucket.

        Agrs:
            bucketName: bucket's name
            objectId: object id
            acceptType: acceptable content-type of response body
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        requestId = self.getRequestIdHeader(lunaRequestId)
        if acceptType is None and requestId is None:
            headers = None
        else:
            headers = {}
            if acceptType is not None:
                headers.update({"Accept": acceptType})
            if requestId is not None:
                headers.update(requestId)
        return makeRequest('{}/buckets/{}/objects/{}'.format(self.baseUri, bucketName, objectId), 'GET',
                           headers=headers, async=self.getAsyncMode(async), raiseError=raiseError)

    def deleteObject(self, bucketName: str, objectId: str, lunaRequestId: Optional[str] = None,
                     async: Optional[bool] = None,
                     raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete object from bucket.

        Agrs:
            bucketName: bucket's name
            objectId: object id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/objects/{}'.format(self.baseUri, bucketName, objectId), 'DELETE',
                           headers=self.getRequestIdHeader(lunaRequestId), async=self.getAsyncMode(async),
                           raiseError=raiseError)

    def deleteObjects(self, bucketName: str, objectIds: List[str], lunaRequestId: Optional[str] = None,
                      async: Optional[bool] = None,
                      raiseError: Optional[bool] = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete objects from bucket.

        Agrs:
            bucketName: bucket's name
            objectIds: objects ids to delete
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                                 requests, in system logs. Pattern:
                                        ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            async: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/objects'.format(self.baseUri, bucketName), 'DELETE',
                           json={'objects': objectIds}, headers=self.getRequestIdHeader(lunaRequestId),
                           async=self.getAsyncMode(async), raiseError=raiseError)
