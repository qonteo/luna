from luna3.faces.faces import FacesApi
from luna3.image_store.image_store import StoreApi
from luna3.events.events import EventsApi
from luna3.attributes.attributes import AttributesApi
from luna3.core.core import CoreAPI
from typing import Optional


class Client:
    """
    Client for all services
    Attributes:
        :lunaFaces (FacesApi): service luna-faces
        :lunaImageStore (StoreApi): service luna-image-store
        :lunaEvents (EventsApi): service luna-events
        :lunaAttributes (AttributesApi): service luna-attributes
        :lunaCore (CoreAPI): service luna-core
    """

    def __init__(self, lunaRequestId: str = None):
        """
        Init client for luna-services.

            lunaRequestId: request id
        """
        self.lunaFaces = FacesApi(lunaRequestId=lunaRequestId)
        self.lunaImageStore = StoreApi(lunaRequestId=lunaRequestId)
        self.lunaEvents = EventsApi(lunaRequestId=lunaRequestId)
        self.lunaAttrubutes = AttributesApi(lunaRequestId=lunaRequestId)
        self.lunaCore = CoreAPI(lunaRequestId=lunaRequestId)

    def updateLunaFacesSettings(self, host="127.0.0.1", port=5030, protocol="http", api=1, async=False):
        """
        Update settings of luna-faces

        Agrs:
            host: luna-faces host, default "127.0.0.1"
            port: port of luna-faces, default 5030
            protocol: enum "https" or "http", default "http"
            api: api version of luna-faces, default 1
            async: default mode for request async or blocking
        """
        self.lunaFaces.updateSettings(host=host, port=port, protocol=protocol, api=api, asyncRequest=async)

    def updateLunaImageStoreSettings(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 5030,
                                     protocol: Optional[str] = "http", api: Optional[int] = 1,
                                     async: Optional[bool] = False) -> None:
        """
        Update settings of luna-faces

        Agrs:
            host: luna-faces host, default "127.0.0.1"
            port: port of luna-faces, default 5030
            protocol: enum "https" or "http", default "http"
            api: api version of luna-image-store, default 1
            async: default mode for request async or blocking
        """
        self.lunaImageStore.updateSettings(host=host, port=port, protocol=protocol, api=api,
                                           asyncRequest=async)

    def updateLunaEventsSettings(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 5040,
                                 protocol: Optional[str] = "http", api: Optional[int] = 1,
                                 async: Optional[bool] = False) -> None:
        """
        Update settings of luna-events

        Agrs:
            host: luna-faces host, default "127.0.0.1"
            port: port of luna-faces, default 5040
            protocol: enum "https" or "http", default "http"
            api: api version of luna-events, default 1
            async: default mode for request async or blocking
        """
        self.lunaEvents.updateSettings(host=host, port=port, protocol=protocol, api=api,
                                       asyncRequest=async)

    def updateLunaAttributesSettings(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 5050,
                                 protocol: Optional[str] = "http", api: Optional[int] = 1,
                                 async: Optional[bool] = False) -> None:
        """
        Update settings of luna-attributes

        Agrs:
            host: luna-attributes host, default "127.0.0.1"
            port: port of luna-attributes, default 5050
            protocol: enum "https" or "http", default "http"
            api: api version of luna-attributes, default 1
            async: default mode for request async or blocking
        """
        self.lunaEvents.updateSettings(host=host, port=port, protocol=protocol, api=api,
                                       asyncRequest=async)

    def updateLunaCoreSettings(self, host: Optional[str] = "127.0.0.1", port: Optional[int] = 8083,
                                 protocol: Optional[str] = "http", api: Optional[int] = 1,
                                 async: Optional[bool] = False) -> None:
        """
        Update settings of luna-core

        Agrs:
            host: luna-faces host, default "127.0.0.1"
            port: port of luna-faces, default 8083
            protocol: enum "https" or "http", default "http"
            api: api version of luna-python-server, default 13
            async: default mode for request async or blocking
        """
        self.lunaCore.updateSettings(host=host, port=port, protocol=protocol, api=api,
                                     asyncRequest=async)
