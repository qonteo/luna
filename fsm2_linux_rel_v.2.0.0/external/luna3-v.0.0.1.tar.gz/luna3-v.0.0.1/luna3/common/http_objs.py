import filetype


class Image:
    """Image obj

        Args:
            filename: filename. may be path to the image.
            name: name of image.
            mimetype: property. image mimetype. Can be autodetected from body.
            _mimetype: privat store mimetype
            body: property. binary representation of image. Can be uploaded by filename path.
            _body: privat store body bytes
            multipartHeaders: Custom headers for multipart body
        """
    def __init__(self, filename: str, name: str = None, mimetype: str = None, body: bytes = None,
                 multipartHeaders: dict = None) -> None:
        self.filename = filename
        self.name = name
        self._body = body
        self._mimetype = mimetype
        self.multipartHeaders = multipartHeaders

    @property
    def body(self) -> bytes:
        """
        Lazy body. If not set, upload by filename path.
        :return: body
        """
        if self._body is not None:
            return self._body
        else:
            with open(self.filename, 'rb') as f:
                self._body = f.read()
            return self._body

    @body.setter
    def body(self, body: bytes):
        """
        Set body
        :param body: binary representation of image
        """
        self._body = body

    @property
    def mimetype(self):
        """
        Lazy mimetype. If not set, executed from body.
        :return: mimetype
        """
        if self._mimetype is not None:
            return self._mimetype
        else:
            self._mimetype = self.getMimetype(self.body)
            return self._mimetype

    @mimetype.setter
    def mimetype(self, mimetype: str):
        """
        Set mimetype

        :param mimetype: image mimetype
        """
        self._mimetype = mimetype

    @property
    def multipartContentDisposition(self) -> str:
        """
        generate ContentDisposition for multipart body

        :return: Content-Disposition
        """
        if self.name is not None:
            name = ' name="%s";' % self.name
        else:
            name = ''
        return 'Content-Disposition: form-data;%s filename="%s"' % (name, self.filename)

    @staticmethod
    def getMimetype(body) -> str:
        """"
        The function gets mimetype of body
        Available mimetypes are: image/jpeg, image/png, image/gif, image/bmp, image/tiff, image/x-portable-pixmap

        :param body: image's bytes
        :type body: bytes

        :raise Exception: ValueError if body has wrong mimetype

        :rtype: String
        :return: Content-type of body.
        """

        contentType = filetype.guess(body)
        if contentType is not None:
            if contentType.mime in ('image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/tiff'):
                return contentType.mime
        else:
            if body[:2] in (b'P6', b'P3'):
                return 'image/x-portable-pixmap'
        raise ValueError("wrong mimetype, availbale mimetypes are: image/jpeg, image/png, image/gif, image/bmp, "
                         "image/tiff, image/x-portable-pixmap")
