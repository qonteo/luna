from .requests import makeRequest


class BaseAPI:
    """
    Base class for request to luna services.

    Attributes:
        :host (str): luna host, default "127.0.0.1"
        :protocol (str): enum "https" or "http", default "http"
        :port (int): port of luna service
        :api (int): api version of  luna, default 1
        :asyncRequest (bool): default mode for request async or blocking
    """

    def __init__(self, port, host = "127.0.0.1", protocol = "http", api = 1, async = False,
                 lunaRequestId = None):
        self.host = host
        self.port = port
        self.protocol = protocol
        self.api = api
        self.asyncRequest = async
        self.lunaRequestId = lunaRequestId

    def updateSettings(self, **kwargs):
        """
        Update settings (host, port, protocol, api, asyncRequest).

        :param kwargs: dict with settings
        """
        for settings in self.__dict__:
            if settings in kwargs:
                self.__dict__[settings] = kwargs[settings]

    @property
    def baseUri(self) -> str:
        """
        Property get base part of url.
        >>> self.baseUri
        "http://127.0.0.1:5030/1"
        """
        return "{}://{}:{}/{}".format(self.protocol, self.host, self.port, self.api)

    def getAsyncMode(self, async):
        """
        Get final async mode.

        :param async: async mode as function argument.
        :return: if async is None, return self.asyncRequest else async
        """
        return async if async is not None else self.asyncRequest

    def getRequestIdHeader(self, lunaRequestId):
        """
        Get final request id.

        :param lunaRequestId: Luna-Request-Id as function argument.
        :return: if lunaRequestId is None, return self.lunaRequestId else lunaRequestId
        """
        if lunaRequestId is not None:
            return {"LUNA-Request-Id": lunaRequestId}
        elif self.lunaRequestId is not None:
            return {"LUNA-Request-Id": self.lunaRequestId}
        else:
            return None

    def getVersion(self, lunaRequestId = None, async = None, raiseError = False):
        """
        Get version of luna service

        :param lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type lunaRequestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
        :param async: execution in asynchronous mode, disabled by default
        :type async: bool
        :param raiseError: if request fails, LunaApiException is raised
        :type raiseError: bool
        :return: In body of :class:`~.LunaResponse` will return json with version.
        :rtype: :class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*
        """
        return makeRequest("{}://{}:{}/{}".format(self.protocol, self.host, self.port, "version"), "GET",
                           headers = self.getRequestIdHeader(lunaRequestId),
                           async = self.getAsyncMode(async), raiseError = raiseError)
