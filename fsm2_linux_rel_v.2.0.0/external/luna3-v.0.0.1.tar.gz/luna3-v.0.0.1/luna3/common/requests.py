from .luna_response import LunaResponse
from .exceptions import LunaApiException
from tornado import httpclient, gen, escape
from tornado.httpclient import HTTPRequest
import ujson


def generateStringQueryParams(queryParams = None):
    """
    The function generates a string with the query parameters for the request to LUNA API

    :param queryParams: dictionary with parameters
    :type queryParams: dict

    :rtype: str
    :return: query parameters string

    >>> generateStringQueryParams({"warped_image": 1, "estimate_attributes": 0})
    'warped_image=1&estimate_attributes=0'

    >>> generateStringQueryParams({"warped_image": 1, "parts": [0,1,2,5]})
    'warped_image=1&parts=0,1,2,5'

    >>> generateStringQueryParams({"user_data": "new data"})
    'user_data=new%20data'
    """
    queryStr = ""
    if queryParams is not None:
        for param in queryParams:
            if queryParams[param] is None:
                continue
            if type(queryParams[param]) in [list, tuple]:
                queryStr += "&{}={}".format(param, ",".join(queryParams[param]))
            elif type(queryParams[param]) in [int, float]:
                queryStr += "&{}={}".format(param,queryParams[param])
            elif type(queryParams[param]) == bool:
                queryStr += "&{}={}".format(param, int(queryParams[param]))
            else:
                queryStr += "&{}={}".format(param, escape.url_escape(queryParams[param], plus = False))
        queryStr = queryStr[1:] if len(queryStr) > 0 else ""
    return queryStr


def processedTornadoReply(reply, raiseError):
    """
    :class:`~.LunaApiException` generator.

    If *raiseError* is true and the request fails, an exception is thrown.

    :param reply: response
    :type reply: :class:`~.LunaResponse`
    :param raiseError: throw exception or not
    :type raiseError: bool

    :rtype: :class:`~.LunaResponse`
    :return: *reply*
    """
    if reply.success:
        return reply
    else:
        if raiseError:
            raise LunaApiException("Not expected code fom LUNA API", reply)
        return reply


def createRequest(url, method, body = None, json = None, queryParams = None, headers = None, **kwargs):
    """
    The function generates *tornado HTTPRequest*.

    :param json: json
    :param url: request URL
    :type url: str
    :param method: request method
    :type method: str
    :param body: request body
    :type body: str, binary
    :param queryParams: query parameters
    :type queryParams: dict
    :param headers: headers for request
    :type headers: dict
    :param requestTimeOut: request processing timeout in seconds (20 by default).
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout seconds (20 by default).
    :type connectTimeOut: int
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: *tornado HTTPRequest*
    :return: HTTP-request. The request can be used in method  *fetch*
    """
    headers_ = {}
    if headers is not None:
        headers_.update(headers)
    if "requestId" in kwargs and kwargs["requestId"] is not None:
        headers_["LUNA-Request-Id"] = kwargs["requestId"]
    url += "?" + generateStringQueryParams(queryParams)
    requestParams = {}
    if "requestTimeOut" in kwargs:
        requestParams["request_timeout"] = kwargs["requestTimeOut"]
    if "connectTimeOut" in kwargs:
        requestParams["connect_timeout"] = kwargs["connectTimeOut"]
    if "body_producer" in kwargs:
        requestParams["body_producer"] = kwargs["body_producer"]
    body_ = None
    if body is not None:
        body_ = body
    elif json is not None:
        body_ = ujson.dumps(json, ensure_ascii = False)
        headers_["Content-Type"] = "application/json"

    request = HTTPRequest(url, method = method, body = body_, headers = headers_, allow_nonstandard_methods = True,
                          **requestParams)
    return request


def executeRequest(request, raiseError):
    """
    The function executes the request in the synchronous mode.

    If raiseError is True and response status code is different from 2xx, an exception is thrown.

    :param request:
    :type: *tornado HTTP-request*
    :param raiseError: throw exception or not
    :type raiseError: bool
    :rtype: :class:`~.LunaResponse`
    :return:  :class:`~.LunaResponse` with LUNA API Answer
    """
    httpClient = httpclient.HTTPClient()
    reply = LunaResponse(httpClient.fetch(request, raise_error = False))
    return processedTornadoReply(reply, raiseError)


@gen.coroutine
def executeAsyncRequest(request, raiseError):
    """
    The function executes the request in the asynchronous mode.

    If raiseError is True and response status code is different from 2xx, an exception is thrown.

    ** ATTENTION** This function works in tornado ioloop.


    :param request:
    :type: *tornado HTTP-request*
    :param raiseError: throw exception or not
    :type raiseError: bool
    :rtype: *tornado coroutine*
    :return:  *tornado coroutine* with :class:`~.LunaResponse`
    """
    httpClient = httpclient.AsyncHTTPClient()
    result = yield httpClient.fetch(request, raise_error = False)
    reply = LunaResponse(result)
    return processedTornadoReply(reply, raiseError)


def makeRequest(url, method, queryParams = None, body = None, json = None, raiseError = False, headers = None,
                **kwargs):
    """
    The function creates and fetches a request.

    :param json: json
    :type json: dict, list
    :param url: request URL
    :type url: str
    :param method: request method
    :type method: str
    :param body: request body
    :type bool: str, binary
    :param queryParams: query parameters
    :type queryParams: dict
    :param headers: headers for request
    :type headers: dict
    :param requestTimeOut: request's processing  timeout in seconds (20 by default).
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds (20 by default).
    :type requestTimeOut: int
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern: ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$

    :rtype: :class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    request = createRequest(url, method, body, json, queryParams, headers, **kwargs)
    if "async" in kwargs:
        if kwargs["async"]:
            return executeAsyncRequest(request, raiseError)
    return executeRequest(request, raiseError)
