# -*- coding: utf-8 -*-
"""
Dependencies installation and versioning.
"""
from setuptools import setup
from setuptools import setup, find_packages
from luna3.version import VERSION

setup(name="luna3",
      version="v.{}.{}.{}".format(VERSION["major"], VERSION["minor"], VERSION["patch"]),
      description="luna3, a internal python library for connect between services VisionLabs LUNA.",
      author="VisionLabs",
      author_email="info@visionlabs.ru",
      packages=find_packages(exclude=["docs", "tests", "tests.*"]),
      package_dir={"": "."},
      zip_safe=False,

      license="http://www.apache.org/licenses/LICENSE-2.0",
      url="http://visionlabs.ai/ru/luna-sdk-info.html",
      install_requires=[
          'tornado>=4.4.2',
          'filetype==1.0.0',
          'ujson==1.35',
          'chardet==3.0.4'
      ],
      )
