class AuthorizationError(Exception):

    def __init__(self, message, errorCode):
        super(AuthorizationError, self).__init__(message)
        self.errorCode = errorCode


class ApiError(Exception):

    def __init__(self, message, errorCode):
        super(ApiError, self).__init__(message)
        self.errorCode = errorCode


class LunaApiException(Exception):

    def __init__(self, message, errorCode, lunaAPIError = None):
        super(
            LunaApiException, self).__init__(message)
        self.errorCode = errorCode
        self.error = lunaAPIError