from tornado import httpclient, gen
from tornado.httpclient import HTTPRequest

import base64
import json

from lunavl.exceptions import AuthorizationError, LunaApiException
from lunavl.luna_response import LunaResponse

import filetype

DEFAULT_API = 3

def processedTornadoReply(reply, raiseError):
    """
    :class:`~.LunaApiException` generator.

    If *raiseError* is true and the request fails, an exception is thrown.

    :param reply: response
    :type reply: :class:`~.LunaResponse`
    :param raiseError: throw exception or not
    :type raiseError: bool

    :rtype: :class:`~.LunaResponse`
    :return: *reply*
    """
    if reply.success:
        return reply
    else:
        if raiseError:
            raise LunaApiException("Not expected code fom LUNA API", 101, reply)
        return reply


def createAuthHeaderFromLoginPassword(authData):
    """
    The function generates an authorization header for LUNA API (by login and password).

    :param authData: dictionary with login and password
    :type authData: dict

    :rtype: dict
    :return: return dict *{'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ=',
                            'LUNA-Request-Id': 'RequestId'}*

    >>> createAuthHeaderFromLoginPassword({"login": "hornsandhooves@ya.ru", "password" : "secretpassword"})
    {'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ='}
    """
    login = authData["login"]
    password = authData["password"]
    strAuth = login + ":" + password
    base64Auth = base64.b64encode(str.encode(strAuth)).decode("utf-8")
    headers = {'Authorization': 'Basic ' + base64Auth}
    return headers


def createAuthHeaderFromToken(authData):
    """
    The function generates authorization header for LUNA API by the token.

    :param authData: dictionary with the token
    :type authData: dict

    :rtype: dict
    :return: return dict *{'X-Auth-Token': "16fd2706-8baf-433b-82eb-8c7fada847da"}*

    >>> createAuthHeaderFromToken({"token": "16fd2706-8baf-433b-82eb-8c7fada847da"})
    {'X-Auth-Token': "16fd2706-8baf-433b-82eb-8c7fada847da"}
    """
    return {'X-Auth-Token': authData["token"]}


def createAuthHeader(authData):
    """
    The function creates authorization header for LUNA API from the dictionary with authorization data. If authorization
    data is not found, :class:`~.AuthorizationError` is thrown.

    :param authData: dict with keys "login" and "password" or "token".
    :type authData: dict

    :rtype: dict
    :return: dictionary in format {'X-Auth-Token': "16fd2706-8baf-433b-82eb-8c7fada847da"} or
             {'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ='}

    >>> createAuthHeaderFromLoginPassword({"login": "hornsandhooves@ya.ru", "password" : "secretpassword",
    ... "token": "16fd2706-8baf-433b-82eb-8c7fada847da", "some_data" : "test"})
    {'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ='}

    >>> createAuthHeaderFromLoginPassword({"login": "hornsandhooves@ya.ru", "token":
    ... "16fd2706-8baf-433b-82eb-8c7fada847da", "some_data" : "test"})
    {'X-Auth-Token': "16fd2706-8baf-433b-82eb-8c7fada847da"}

    >>> createAuthHeader({"login": "hornsandhooves@ya.ru"})
    Traceback (most recent call last):
        ...
    lunavl.exceptions.AuthorizationError: Authorization data is not set

    """
    auth = {}
    if "token" in authData:
        if authData["token"] is not None:
            return createAuthHeaderFromToken(authData)
    if ("login" not in authData) or ("password" not in authData):
        raise AuthorizationError("Authorization data does not set", 1)
    if authData["login"] is not None and authData["password"] is not None:
        return createAuthHeaderFromLoginPassword(authData)
    raise AuthorizationError("Authorization data does not set", 1)


def createRequest(url, method, body = None, queryParams = None, additionalHeaders = None, **kwargs):
    """
    The function generates *tornado HTTPRequest*.

    :param url: request URL
    :type url: str
    :param method: request method
    :type method: str
    :param body: request body
    :type bool: str, binary
    :param queryParams: query parameters
    :type queryParams: dict
    :param additionalHeaders: headers for request without an authorization header
    :type additionalHeaders: dict
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: st
    :param token: token id for authorization
    :type token: str
    :param requestTimeOut: request processing timeout in seconds (20 by default).
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout seconds (
                           20 by default).
    :type requestTimeOut: int
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: *tornado HTTPRequest*
    :return: HTTP-request. The request can be used in method  *fetch*
    """
    headers = createAuthHeader(kwargs)
    if additionalHeaders is not None:
        headers.update(additionalHeaders)
    if "requestId" in kwargs and kwargs["requestId"] is not None:
        headers["LUNA-Request-Id"] = kwargs["requestId"]
    url += "?" + generateStringQueryParams(queryParams)
    requestParams = {}
    if "requestTimeOut" in kwargs:
        requestParams["request_timeout"] = kwargs["requestTimeOut"]
    if "connectTimeOut" in kwargs:
        requestParams["connect_timeout"] = kwargs["connectTimeOut"]
    request = HTTPRequest(url, method = method, body = body, headers = headers, allow_nonstandard_methods = True,
                          **requestParams)
    return request


def executeRequest(request, raiseError):
    """
    The function executes the request in the synchronous mode.

    If raiseError is True and response status code is different from 2xx, an exception is thrown.

    :param request:
    :type: *tornado HTTP-request*
    :param raiseError: throw exception or not
    :type raiseError: bool

    :rtype: :class:`~.LunaResponse`
    :return:  :class:`~.LunaResponse` with LUNA API Answer
    """
    httpClient = httpclient.HTTPClient()
    reply = LunaResponse(httpClient.fetch(request, raise_error = False))
    return processedTornadoReply(reply, raiseError)


@gen.coroutine
def executeAsyncRequest(request, raiseError):
    """
    The function executes the request in the asynchronous mode.

    If raiseError is True and response status code is different from 2xx, an exception is thrown.

    ** ATTENTION** This function works in tornado ioloop.


    :param request:
    :type: *tornado HTTP-request*
    :param raiseError: throw exception or not
    :type raiseError: bool

    :rtype: *tornado coroutine*
    :return:  *tornado coroutine* with :class:`~.LunaResponse`
    """
    httpClient = httpclient.AsyncHTTPClient()
    result = yield httpClient.fetch(request, raise_error = False)
    reply = LunaResponse(result)
    return processedTornadoReply(reply, raiseError)


def makeRequest(url, method, queryParams = None, body = None, raiseError = False, additionalHeaders = None, **kwargs):
    """
    The function creates and fetches a request.

    :param url: request URL
    :type url: str
    :param method: request method
    :type method: str
    :param body: request body
    :type bool: str, binary
    :param queryParams: query parameters
    :type queryParams: dict
    :param additionalHeaders: headers for request without authorization header
    :type additionalHeaders: dict
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: st
    :param token: token id for authorization
    :type token: str
    :param requestTimeOut: request's processing  timeout in seconds (20 by default).
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds (
                           20 by default).
    :type requestTimeOut: int
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: :class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    request = createRequest(url, method, body, queryParams, additionalHeaders, **kwargs)
    if "async" in kwargs:
        if kwargs["async"]:
            return executeAsyncRequest(request, raiseError)
    return executeRequest(request, raiseError)


def generateStringQueryParams(queryParams = None):
    """
    The function generates a string with the query parameters for the request to LUNA API

    :param queryParams: dictionary with parameters
    :type queryParams: dict

    :rtype: str
    :return: query parameters string

    >>> generateStringQueryParams({"warped_image": 1, "estimate_attributes": 0})
    'warped_image=1&estimate_attributes=0'

    >>> generateStringQueryParams({"warped_image": 1, "parts": [0,1,2,5]})
    'warped_image=1&parts=0,1,2,5'

    >>> generateStringQueryParams()
    ''

    """
    queryStr = ""
    if queryParams is not None:
        for param in queryParams:
            if type(queryParams[param]) in [list, tuple]:
                queryStr += "&{}={}".format(param, ",".join(queryParams[param]))
            else:
                queryStr += "&{}={}".format(param, queryParams[param])
        queryStr = queryStr[1:]
    return queryStr


def getAccountData(lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function gets account's data: email, organization name and status (whether the account is suspended or not).

    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default).
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account".format(lunaUrl), "GET", raiseError = raiseError, **kwargs)


def getTokens(lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
	The function gets account's tokens. Every token is represented ин *id* and *token data*.

    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens".format(lunaUrl), "GET", raiseError = raiseError, **kwargs)


def createToken(tokenData = "", lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function creates a token with token data. New token's *id* is returned.

    :param tokenData: token data for token
    :type tokenData: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens".format(lunaUrl), "POST", body = json.dumps({"token_data": tokenData}),
                       raiseError = raiseError, **kwargs)


def deleteTokens(tokens, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function remove a tokens' list.

    :param tokens: list of token ids.
    :type tokens: List[str]
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens".format(lunaUrl), "DELETE", body = json.dumps({"tokens": tokens}),
                       raiseError = raiseError, **kwargs)


def getToken(tokenId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function gets *token data* of a token, which corresponds to *tokenId*.

    :param tokenId: token *id* 
    :type tokenId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens/{}".format(lunaUrl, tokenId), "GET", raiseError = raiseError, **kwargs)


def patchTokenData(tokenId, tokenData, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False,
                   **kwargs):
    """
    The function patches a token data for the token, which corresponds to *tokenId*.

    :param tokenId: token *id*
    :type tokenId: str
    :param tokenData: token data 
    :type tokenData: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens/{}".format(lunaUrl, tokenId), "PATCH",
                       body = json.dumps({"token_data": tokenData}), raiseError = raiseError, **kwargs)


def deleteToken(tokenId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function remove a token, which corresponds to *tokenId*.

    :param tokenId: token *id* 
    :type tokenId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens/{}".format(lunaUrl, tokenId), "DELETE", raiseError = raiseError, **kwargs)


def getPersons(page = 1, pageSize = 10, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False,
               **kwargs):
    """
    The function gets all persons of the account. Result is a list of persons and number of persons for the account.
    Each person is represented by *person_id*, *user_data*, *linked_descriptors*, linked_lists*.

    :param page: page number, positive.
    :type page: int
    :param pageSize: number of results per page, positive.
    :type pageSize: int
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons".format(lunaUrl), "GET", raiseError = raiseError,
                       queryParams = {"page": page, "page_size": pageSize}, **kwargs)


def createPerson(userData = "", lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function creates a person with user data. New person's *Id* is returned.

    :param userData: user data for person
    :type userData: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons".format(lunaUrl), "POST", raiseError = raiseError,
                       body = json.dumps({"user_data": userData}), **kwargs)


def getPerson(personId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function gets a person, which corresponds to *personId*.

    :param personId: person *id*
    :type personId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}".format(lunaUrl, personId), "GET", raiseError = raiseError, **kwargs)


def deletePerson(personId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function removes a person, which corresponds *personId*.

    :param personId: person *id*
    :type personId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}".format(lunaUrl, personId), "DELETE", raiseError = raiseError, **kwargs)


def patchUserData(personId, userData, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False,
                  **kwargs):
    """
    The function patches *user_data* to the person.

    :param personId: person *id*
    :type personId: str
    :param userData: user data for person
    :type userData: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}".format(lunaUrl, personId), "PATCH", raiseError = raiseError,
                       body = json.dumps({"user_data": userData}), **kwargs)


def createList(listType, listData = "", lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False,
               **kwargs):
    """
    The function creates a list with list data. New list's *Id* is returned.

    :param listType: list's typr ("persons" or "descriptors)
    :type listType: str
    :param listData: list data
    :type listData: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists".format(lunaUrl), "POST", queryParams = {"type": listType},
                       raiseError = raiseError, body = json.dumps({"list_data": listData}), **kwargs)


def getLists(lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function get all lists for the account.

    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists".format(lunaUrl), "GET", raiseError = raiseError, **kwargs)


def deleteLists(lists, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function removes lists.

    :param lists: list of list ids.
    :type lists: List[str]
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists".format(lunaUrl), "DELETE", body = json.dumps({"lists": lists}),
                       raiseError = raiseError, **kwargs)


def getList(listId, page = 1, pageSize = 10, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
            raiseError = False, **kwargs):
    """
    The function gets objects in the list.

    :param listId: list *id*
    :type listId: str

    :param page: page number, positive.
    :type page: int
    :param pageSize: number of results per page, positive.
    :type pageSize: int
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists/{}".format(lunaUrl, listId), "GET", raiseError = raiseError,
                       queryParams = {"page": page, "page_size": pageSize}, **kwargs)


def patchListData(listId, listData, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False,
                  **kwargs):
    """
    The function patches list data.

    :param listId: list *id*
    :type listId: str
    :param listData: list data
    :type listData: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists/{}".format(lunaUrl, listId), "PATCH", raiseError = raiseError,
                       body = json.dumps({"list_data": listData}), **kwargs)


def deleteList(listId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function removes a list.

    :param listId: list *id*
    :type listId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists/{}".format(lunaUrl, listId), "DELETE", raiseError = raiseError, **kwargs)


def extractDescriptors(body = None, filename = None, contentType = None, warpedImage = False,
                       estimateAttributes = False, estimateEmotions = False, estimateQuality = False,
                       scoreThreshold = 0, extractDescriptor = True, extractExif = False,
                       lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    Extract descriptors from a image. Image can be represented as raw bytes or path to file.

    :param body: image's bytes
    :type body: bytearray
    :param filename: path to the folder with the image
    :type filename: str
    :param contentType: image mime type, if contentType is not set, will try to determine it by ourselves
                        raise ValueError if mimetype of content is not matches with acceptable formats
                        (Available mimetypes are: image/jpeg, image/png, image/gif, image/bmp, image/tiff,
                         application/x-vl-xpk, application/x-vl-face-descriptor, image/x-portable-pixmap)
    :type contentType: str
    :param warpedImage: Determines, whether an input image is a warped or an arbitrary one. Exact image warping
                        algorithm is proprietary and this flag is intended for VisionLabs front-end tools only.

                        The warped image has the following properties:

                        * size is always 250x250 pixels;

                        * color format is always RGB; 

                        * single face in a photo;

                        * the face is always centered and rotated so that imaginary line between the eyes is
                        horizontal.
    :type warpedImage: bool
    :param estimateAttributes: whether to estimate face attributes from the image or not(gender, age, glasses).
    :type estimateAttributes: bool
    :param estimateEmotions: Whether to estimate emotions from the image.
    :type estimateEmotions: bool
    :param estimateQuality: whether to estimate faces' suitability for recognition or not
    :type estimateQuality: bool
    :param scoreThreshold: If estimate_quality parameter is set to 1, it is possible to apply a threshold check
                             to each estimation. All face detections with quality below the threshold are
                             ignored and no descriptors are extracted from them. The function proceeds as
                             usual with all the remaining detections (if left).
    :type scoreThreshold: float
    :param extractDescriptor: whether to extract face descriptor(s) or nor.
    :type extractDescriptor: bool
    :param extractExif: Whether to extract EXIF meta information from the input image or not.

                        Exact output varies since there are no mandatory data writing requirements both to the authoring
                        software and digital cameras.

                        This function parses only the tags and outputs their names and values as-is.
    :type extractExif: bool

    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    if body is None and filename is None:
        raise ValueError

    if body is not None:
        body = body
    else:
        with open(filename, "rb") as f:
            body = f.read()

    if contentType is None:
        contentType = getContentType(body)

    queryParams = {"estimate_attributes": int(estimateAttributes),
                   "estimate_emotions": int(estimateEmotions),
                   "estimate_quality": int(estimateQuality),
                   "extract_descriptor": int(extractDescriptor),
                   "warped_image": int(warpedImage),
                   "extract_exif": int(extractExif),
                   "score_threshold": scoreThreshold}

    return makeRequest("{}/storage/descriptors".format(lunaUrl), "POST", queryParams = queryParams,
                       raiseError = raiseError, additionalHeaders = {"Content-Type": contentType}, body = body,
                       **kwargs)


def getDescriptors(page = 1, pageSize = 10, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                   raiseError = False, **kwargs):
    """
    The function gets accounts' descriptors. Result is a list of descriptors and number of descriptors
    for the account. Every descriptor is represented by *descriptor_id* and number of  *linked_lists*, the descriptor
    is attached to.

    :param page: page number, positive.
    :type page: int
    :param pageSize: number of results per page, positive.
    :type pageSize: int
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/descriptors".format(lunaUrl), "GET", raiseError = raiseError,
                       queryParams = {"page": page, "page_size": pageSize}, **kwargs)


def getDescriptor(descriptorId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function gets the descriptor, which corresponds to *descriptorId*.

    :param descriptorId: descriptor *id*
    :type descriptorId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/descriptors/{}".format(lunaUrl, descriptorId), "GET", raiseError = raiseError,
                       **kwargs)


def linkDescriptorToPerson(personId, descriptorId, action, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                           raiseError = False, **kwargs):
    """
    The function creates or deletes a link between a descriptor and a person.

    :param personId: person id
    :type personId: str
    :param descriptorId: descriptor id
    :type descriptorId: str
    :param action: "attach" or "detach"
    :type action: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}/linked_descriptors".format(lunaUrl, personId), "PATCH",
                       raiseError = raiseError, queryParams = {"descriptor_id": descriptorId, "do": action}, **kwargs)


def getLinkedDescriptorToPerson(personId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False,
                                **kwargs):
    """
    The function gets the list of descriptors, which are linked to a person.

    :param personId: person id
    :type personId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}/linked_descriptors".format(lunaUrl, personId), "GET",
                       raiseError = raiseError, **kwargs)


def linkListToPerson(personId, listId, action, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                     raiseError = False, **kwargs):
    """
    The function creates or deletes a link between a list and a person.

    :param personId: person id
    :type personId: str
    :param listId: list id
    :type listId: str
    :param action: "attach" or "detach"
    :type action: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}/linked_lists".format(lunaUrl, personId), "PATCH",
                       raiseError = raiseError, queryParams = {"list_id": listId, "do": action}, **kwargs)


def getLinkedListsToPerson(personId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False,
                           **kwargs):
    """
    The function gets the list of lists, which are linked to a person.

    :param personId: person id
    :type personId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}/linked_lists".format(lunaUrl, personId), "GET",
                       raiseError = raiseError, **kwargs)


def linkListToDescriptor(descriptorId, listId, action, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                         raiseError = False,
                         **kwargs):
    """
    The function creates or deletes a link between a list and a descriptor.

    :param descriptorId: descriptor id
    :type descriptorId: str
    :param listId:  list id
    :type listId: str
    :param action: "attach" or "detach"
    :type action: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/descriptors/{}/linked_lists".format(lunaUrl, descriptorId), "PATCH",
                       raiseError = raiseError, queryParams = {"list_id": listId, "do": action}, **kwargs)


def getLinkedListsToDescriptor(descriptorId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                               raiseError = False, **kwargs):
    """
    The function gets the list of lists, the descriptor is linked to.

    :param descriptorId: descriptor id
    :type descriptorId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/descriptors/{}/linked_lists".format(lunaUrl, descriptorId), "GET",
                       raiseError = raiseError, **kwargs)


def getPortrait(descriptorId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function gets the portrait, which corresponds to *descriptorId*.

    :param descriptorId: descriptor id
    :type descriptorId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/portraits/{}".format(lunaUrl, descriptorId), "GET",
                       raiseError = raiseError, **kwargs)


def setOneRequiredArgument(args, t):
    for params in t:
        if t[params] is not None:
            args[params] = t[params]
            return
    raise ValueError


def identify(personId = None, descriptorId = None, listId = None, personIds = None, limit = 3,
             lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function matches a descriptor or person with a list of candidate persons.

    Either *descriptor_id* or *person_id* parameter should be specified as the reference and 
	either *list_id* or *person_ids* parameter should be determined as the candidate.

    :param personId: person id to take the reference descriptors from
    :type personId: str
    :param descriptorId: reference descriptor id.
    :type descriptorId: str
    :param listId: candidate list id.
    :type listId: str
    :param personIds: list of candidate person ids
    :type personIds: list[str]
    :param limit:
    :type limit: int
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    queryParams = {"limit": limit}
    setOneRequiredArgument(queryParams, {"person_id": personId, "descriptor_id": descriptorId})
    setOneRequiredArgument(queryParams, {"list_id": listId, "person_ids": personIds})

    return makeRequest("{}/matching/identify".format(lunaUrl), "POST", queryParams = queryParams,
                       raiseError = raiseError, **kwargs)


def match(personId = None, descriptorId = None, listId = None, descriptorsIds = None, limit = 3,
          lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function matches a descriptor or a person with a list of candidate descriptors.

	Either *descriptor_id* or *person_id* parameter should be specified as the reference and either *list_id* or
	*descriptor_ids*  parameter should be determined as the candidate.

    :param personId: person id to take the reference descriptors from
    :type personId: str
    :param descriptorId: reference descriptor id.
    :type descriptorId: str
    :param listId: candidate list id.
    :type listId: str
    :param descriptorIds: list of candidate descriptor ids
    :type descriptorIds: list[str]
    :param limit:
    :type limit: int
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    queryParams = {"limit": limit}
    setOneRequiredArgument(queryParams, {"person_id": personId, "descriptor_id": descriptorId})
    setOneRequiredArgument(queryParams, {"list_id": listId, "descriptor_ids": descriptorsIds})

    return makeRequest("{}/matching/match".format(lunaUrl), "POST", queryParams = queryParams,
                       raiseError = raiseError, **kwargs)


def verify(descriptorId, personId, lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False,
           **kwargs):
    """
    The function matches a descriptor with candidate person descriptors.

    :param descriptorId: reference descriptor id.
    :type descriptorId: str
    :param personId: reference person id.
    :type personId: str
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    queryParams = {"person_id": personId, "descriptor_id": descriptorId}
    return makeRequest("{}/matching/verify".format(lunaUrl), "POST", queryParams = queryParams,
                       raiseError = raiseError, **kwargs)


def search(body = None, filename = None, contentType = None, limit = 3, warpedImage = False,
           estimateAttributes = False, estimateQuality = False, scoreThreshold = 0,
           extractExif = False, listId = None, descriptorIds = None, personIds = None,
           lunaUrl = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError = False, **kwargs):
    """
    The function extracts a descriptor from a photo, then matches it to a list of candidates.

    Either *list_id* or *person_ids* or *descriptor_ids* parameter should be specified as the candidate.  

    :param body: image bytes
    :type body: bytearray
    :param filename: path to folder with the image
    :type filename: str
    :param contentType: image mime type, if contentType is not set, will try to determine it by ourselves
                        raise ValueError if mimetype of content is not matches with acceptable formats
                        (Available mimetypes are: image/jpeg, image/png, image/gif, image/bmp, image/tiff,
                        application/x-vl-xpk, application/x-vl-face-descriptor, image/x-portable-pixmap)
    :type contentType: str
    :param warpedImage: Determines, whether an input image is a warped or an arbitrary one. Exact image warping
                        algorithm is proprietary and this flag is intended for VisionLabs front-end tools only.

                        The warped image has the following properties:

                        * size is always 250x250 pixels;

                        * color format is always RGB; 

                        * single face in a photo;

                        * the face is always centered and rotated so that imaginary line between the eyes is
                           horizontal.
    :type warpedImage: bool
    :param estimateAttributes: whether to estimate face attributes for the image or not (gender, age, glasses).
    :type estimateAttributes: bool
    :param estimateQuality: estimate face suitability for recognition
    :type estimateQuality: bool
    :param scoreThreshold: If estimate_quality parameter is set to 1, it is possible to apply a threshold check
                             to each estimation. All face detections with the quality below the threshold are
                             ignored and no descriptors are extracted from them. The function proceeds as
                             usual with all the remaining detections (if left).
    :type scoreThreshold: float
    :param extractExif: Whether to extract EXIF meta information from the input image or not.

                        Exact output varies since there are no mandatory data writing requirements both to the authoring
                        software and digital cameras.

                        This function only parses the tags and outputs their names and values as-is.
    :type extractExif: bool
    :param listId: candidate list id.
    :type listId: str
    :param descriptorIds: list of candidate descriptor ids
    :type descriptorIds: list[str]
    :param personIds: list of candidate person ids
    :type personIds: list[str]
    :param limit:
    :type limit: int
    :param lunaUrl: base part of URL to Luna API with API version.
    :type lunaUrl: str
    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param login: account's login for authorization
    :type login: str
    :param password: account's password for authorization
    :type password: str
    :param async: execution in asynchronous mode, disabled by default
    :type async: bool
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    if body is None and filename is None:
        raise ValueError

    if body is not None:
        body = body
    else:
        with open(filename, "rb") as f:
            body = f.read()

    if contentType is None:
        contentType = getContentType(body)

    queryParams = {"estimate_attributes": int(estimateAttributes),
                   "estimate_quality": int(estimateQuality),
                   "warped_image": int(warpedImage),
                   "extract_exif": int(extractExif),
                   "limit": limit,
                   "score_threshold": scoreThreshold}


    setOneRequiredArgument(queryParams, {"list_id": listId, "person_ids": personIds, "descriptor_ids": descriptorIds})
    return makeRequest("{}/matching/search".format(lunaUrl), "POST", queryParams = queryParams,
                       raiseError = raiseError, additionalHeaders = {"Content-Type": contentType}, body = body,
                       **kwargs)


def getVersion(url, raiseError = False, **kwargs):
    """
    The function gets LUNA API version.


    :param raiseError: if request fails, LunaApiException is raised
    :type raiseError: bool
    :param requestTimeOut: request's processing  timeout in seconds (20 by default)
    :type requestTimeOut: int
    :param connectTimeOut: connection timeout in seconds.
    :type requestTimeOut: int
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string
    :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                      requests, in system logs.
    :type requestId: string - pattern:
                     ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


    :rtype: LunaResponse
    :return: structure with status code, request and decoded Luna API response body is returned.
    """
    requestParams = {}
    if "requestTimeOut" in kwargs:
        requestParams["request_timeout"] = kwargs["requestTimeOut"]
    if "connectTimeOut" in kwargs:
        requestParams["connect_timeout"] = kwargs["connectTimeOut"]
    if "requestId" in kwargs and kwargs["requestId"] is not None:
        requestParams["headers"] = {"LUNA-Request-Id": kwargs["requestId"]}
    request = HTTPRequest(url + "/version", method = "GET", **requestParams)

    return executeRequest(request, raiseError = raiseError)


def getContentType(body):
    """"
    The function gets mimetype of body
    Available mimetypes are: image/jpeg, image/png, image/gif, image/bmp, image/tiff, application/x-vl-xpk,
                             application/x-vl-face-descriptor, image/x-portable-pixmap

    :param body: image's bytes
    :type body: bytearray

    :raise Exception: ValueError if body has wrong mimetype

    :rtype: String
    :return: Content-type of body.
    """

    contentType = filetype.guess(body)
    if contentType is not None:
        if contentType.mime in ('image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/tiff'):
            return contentType.mime
    else:
        if body[:4] == b'XPKF':
            return 'application/x-vl-xpk'
        elif body[:2] == b'dp':
            return 'application/x-vl-face-descriptor'
        elif body[:2] in (b'P6', b'P3'):
            return 'image/x-portable-pixmap'
    raise ValueError("wrong mimetype, availbale mimetypes are: image/jpeg, image/png, image/gif, image/bmp, "
                     "image/tiff, application/x-vl-xpk, application/x-vl-face-descriptor")
