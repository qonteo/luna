"""Python http client for VisionLabs Luna."""
from tornado import escape
from lunavl.exceptions import ApiError
from lunavl.luna_api import *


def createAuthHeader(**kwargs):
    if ("login" not in kwargs) or ("password" not in kwargs):
        raise AuthorizationError("Authorization data does not set", 1)
    login = kwargs["login"]
    password = kwargs["password"]
    strAuth = login + ":" + password
    base64Auth = base64.b64encode(str.encode(strAuth)).decode("utf-8")
    headers = {'Authorization': 'Basic ' + base64Auth}
    return headers


class LunaHttpClient:
    """
    Synchronous and  asynchronous HTTP-client for connecting to VisionLabs LUNA API.

    The :class:`~.LunaHttpClient` object holds information necessary to
    connect to LUNA API. Also, one can choose either a synchronous or asynchronous operation mode. Asynchronous requests
    to Luna API are realized using tornado-coroutine. In asynchronous mode one should run tornado ioloop. Every
    asynchronous request returns coroutine with :class:`~.LunaResponse`.

    For more information on requests and responses from LUNA API refer to the LUNA API documentation.

        :param lunaHost:                    LUNA API service hostname ("http://127.0.0.1")
        :type host: str
        :param lunaPort:                    LUNA API service listener port (5000)
        :type lunaPort: int
        :param lunaApi:                     Luna API version (2)
        :type lunaApi: int
        :param async:                       client operation mode, default (synchronous)
        :type async: bool
        :param login:                       account login
        :type login: str
        :param password:                    account password
        :type password: str
        :param token:                       account token
        :type token: str

    One must set login/password or token for authorization in LUNA API service.

    **ATTENTION**:  some LUNA API methods support authorization by login/password only.

    """

    def __init__(self, api = 3, endPoint = "http://127.0.0.1", port = 5000, async = False, **kwargs):

        self.lunaHost = endPoint
        self.lunaPort = str(port)
        self.lunaApi = api
        self.login = None
        self.password = None
        self.token = None
        self.asyncClient = async

        if "login" in kwargs:
            self.login = kwargs["login"]
        if "password" in kwargs:
            self.password = kwargs["password"]
        if "token" in kwargs:
            self.token = kwargs["token"]

        if not self.checkAPIVersion():
            raise ApiError("Version  API of Luna API does not match", 10)

    def checkAPIVersion(self):

        reply = getVersion(self.lunaHost + ":" + str(self.lunaPort))
        if reply.statusCode == 599:
            raise LunaApiException("Failed connect to LUNA API", 100)
        elif reply.statusCode != 200:
            raise LunaApiException("Not expected code fom LUNA API", 101, escape.json_decode(reply.body))
        if self.lunaApi == 1:
            if reply.body["Version"]["api"] == self.lunaApi:
                return True
            return False
        else:
            if "luna_api" not in reply.body["Version"]:
                return False
            if reply.body["Version"]["luna_api"]["api"] == self.lunaApi:
                return True
            return False

    def getLunaUrl(self):
        """
        Luna API URL generation

        :return: based part "http://127.0.0.1:5000/3"
        """
        return "{}:{}/{}".format(self.lunaHost, self.lunaPort, self.lunaApi)

    def getAccountData(self, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function gets account data: e-mail, organization name, and status (account is suspended or not).

        :param raiseError: LunaApiException is raised if the request failed
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: :class:`~.LunaResponse`
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getAccountData(self.getLunaUrl(), raiseError, requestTimeOut = requestTimeOut,
                              connectTimeOut = connectTimeOut, login = self.login,
                              password = self.password, token = self.token, async = self.asyncClient,
                              requestId = requestId)

    def getTokens(self, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function gets account tokens. Every token is represented by *id* and *token data*.

        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getTokens(self.getLunaUrl(), raiseError, requestTimeOut = requestTimeOut,
                         connectTimeOut = connectTimeOut, login = self.login,
                         password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def createToken(self, tokenData = "", raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                    requestId = None):
        """
        The function creates a token with token data. Returns the new token *id*.

        :param tokenData: user data for the token
        :type tokenData: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return createToken(tokenData, self.getLunaUrl(), raiseError, requestTimeOut = requestTimeOut,
                           connectTimeOut = connectTimeOut, login = self.login,
                           password = self.password, token = self.token, async = self.asyncClient,
                           requestId = requestId)

    def deleteTokens(self, tokens, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function removes tokens' list.

        :param tokens: list of token ids.
        :type tokens: List[str]
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return deleteTokens(tokens, self.getLunaUrl(), raiseError, requestTimeOut = requestTimeOut,
                           connectTimeOut = connectTimeOut, login = self.login,
                           password = self.password, token = self.token, async = self.asyncClient,
                           requestId = requestId)

    def getToken(self, tokenId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function gets *token data* for a token, which corresponds to *tokenId*.

        :param tokenId: token *id*
        :type tokenId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getToken(tokenId, self.getLunaUrl(), raiseError, requestTimeOut = requestTimeOut,
                        connectTimeOut = connectTimeOut, login = self.login,
                        password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def patchTokenData(self, tokenId, tokenData, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                       requestId = None):
        """
        The function patch token data to the token, which corresponds to *tokenId*.

        :param tokenId: token *id*
        :type tokenId: str
        :param tokenData: user data for the token
        :type tokenData: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return patchTokenData(tokenId, tokenData, self.getLunaUrl(), raiseError, requestTimeOut = requestTimeOut,
                              connectTimeOut = connectTimeOut, login = self.login,
                              password = self.password, token = self.token, async = self.asyncClient,
                              requestId = requestId)

    def deleteToken(self, tokenId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The fucntion removes a token, which corresponds to *tokenId*.

        :param tokenId: token *id*
        :type tokenId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return deleteToken(tokenId, self.getLunaUrl(), raiseError, requestTimeOut = requestTimeOut,
                           connectTimeOut = connectTimeOut, login = self.login,
                           password = self.password, token = self.token, async = self.asyncClient,
                           requestId = requestId)

    def getPersons(self, page = 1, pageSize = 10, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                   requestId = None):
        """
        The function gets all persons of the account. Result is a list of persons and number of persons for the account.
        Each person is represented by *person_id*, *user_data*, *linked_descriptors*, linked_lists*.

        :param page: page number, positive.
        :type page: int
        :param pageSize: number of results per page, positive.
        :type pageSize: int
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getPersons(lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                          connectTimeOut = connectTimeOut, login = self.login,
                          password = self.password, token = self.token, page = page, pageSize = pageSize,
                          async = self.asyncClient, requestId = requestId)

    def createPerson(self, userData = "", raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                     requestId = None):
        """
        The function creates a person with user data. New person's *Id* is returned.

        :param userData: user data for person
        :type userData: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return createPerson(lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                            connectTimeOut = connectTimeOut, login = self.login,
                            password = self.password, token = self.token, userData = userData, async = self.asyncClient,
                            requestId = requestId)

    def getPerson(self, personId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function gets a person, which corresponds to *personId*.

        :param personId: person *id*
        :type personId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getPerson(lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                         connectTimeOut = connectTimeOut, login = self.login,
                         password = self.password, token = self.token, personId = personId, async = self.asyncClient,
                         requestId = requestId)

    def patchUserData(self, personId, userData, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                      requestId = None):
        """
        The function patches *user_data* to the person.

        :param personId: person *id*
        :type personId: str
        :param userData: user data for the person
        :type userData: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return patchUserData(lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                             connectTimeOut = connectTimeOut, login = self.login, async = self.asyncClient,
                             password = self.password, token = self.token, personId = personId, userData = userData,
                             requestId = requestId)

    def deletePerson(self, personId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function removes a person, which corresponds *personId*.

        :param personId: person *id*
        :type personId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return deletePerson(lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                            connectTimeOut = connectTimeOut, login = self.login,
                            password = self.password, token = self.token, personId = personId, async = self.asyncClient,
                            requestId = requestId)

    def createList(self, listType, listData = "", raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                   requestId = None):
        """
        The function creates a list with list data. New list's *Id* is returned.

        :param listType: list's type ("persons" or "descriptors)
        :type listType: str
        :param listData: list data for the list
        :type listData: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return createList(listType, listData, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                          requestTimeOut = requestTimeOut,
                          connectTimeOut = connectTimeOut, login = self.login,
                          password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def getLists(self, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function get all lists for the account.

        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getLists(lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                        connectTimeOut = connectTimeOut, login = self.login, password = self.password,
                        token = self.token, async = self.asyncClient, requestId = requestId)

    def deleteLists(self, lists, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function removes lists.

        :param lists: list of list ids.
        :type lists: List[str]
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return deleteLists(lists, lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                           connectTimeOut = connectTimeOut, login = self.login, password = self.password,
                           token = self.token, async = self.asyncClient, requestId = requestId)

    def getList(self, listId, page = 1, pageSize = 10, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                requestId = None):
        """
        The function gets objects in the list.

        :param listId: list *id*
        :type listId: str

        :param page: page number, positive.
        :type page: int
        :param pageSize: number of results per page, positive.
        :type pageSize: int
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getList(listId, page, pageSize, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                       requestTimeOut = requestTimeOut, connectTimeOut = connectTimeOut, login = self.login,
                       password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def patchListData(self, listId, listData, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                      requestId = None):
        """
        The function patches list data.

        :param listId: list *id*
        :type listId: str
        :param listData: list data
        :type listData: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$

        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return patchListData(listId, listData, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                             requestTimeOut = requestTimeOut, connectTimeOut = connectTimeOut, login = self.login,
                             password = self.password, token = self.token, async = self.asyncClient,
                             requestId = requestId)

    def deleteList(self, listId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function removes a list.

        :param listId: list *id*
        :type listId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return deleteList(listId, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                          requestTimeOut = requestTimeOut, connectTimeOut = connectTimeOut, login = self.login,
                          password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def extractDescriptors(self, body = None, filename = None, contentType = None, warpedImage = False,
                           estimateAttributes = False, estimateEmotions = False, estimateQuality = False,
                           scoreThreshold = 0, extractDescriptor = True, extractExif = False, raiseError = False,
                           requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function extracts descriptors from an image. Image can be represented as raw bytes or a path to some folder.

        :param body: image's bytes
        :type body: bytearray
        :param filename: path to the folder with the image
        :type filename: str
        :param contentType: image mime type
        :type contentType: str
        :param warpedImage: Determines, whether an input image is a warped or an arbitrary one. Exact image warping
                            algorithm is proprietary and this flag is intended for VisionLabs front-end tools only.

                            The warped image has the following properties:

                            * size is always 250x250 pixels;

                            * color format is always RGB;

                            * single face in a photo;

                            * the face is always centered and rotated so that imaginary line between the eyes is
                           horizontal.

        :type warpedImage: bool
        :param estimateAttributes: whether to estimate face attributes from the image or not(gender, age, glasses).
        :type estimateAttributes: bool
        :param estimateEmotions: Whether to estimate emotions from the image.
        :type estimateEmotions: bool
        :param estimateQuality: whether to estimate faces' suitability for recognition or not
        :type estimateQuality: bool
        :param scoreThreshold: If estimate_quality parameter is set to 1, it is possible to apply a threshold check
                                 to each estimation. All face detections with quality below the threshold are
                                 ignored and no descriptors are extracted from them. The function proceeds as
                                 usual with all the remaining detections (if left).
        :type scoreThreshold: float
        :param extractDescriptor: whether to extract face descriptor(s) or not.
        :type extractDescriptor: bool
        :param extractExif: Whether to extract EXIF meta information from the input image or not.

                            Exact output varies since there are no mandatory data writing requirements both to the
                            authoring software and digital cameras.

                            This function parses only the tags and outputs their names and values as-is.
        :type extractExif: bool

        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """

        return extractDescriptors(body = body, filename = filename, contentType = contentType,
                                  warpedImage = warpedImage,
                                  estimateAttributes = estimateAttributes, estimateEmotions = estimateEmotions,
                                  estimateQuality = estimateQuality, scoreThreshold = scoreThreshold,
                                  extractDescriptor = extractDescriptor, extractExif = extractExif,
                                  lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                                  connectTimeOut = connectTimeOut, login = self.login,
                                  password = self.password, token = self.token, async = self.asyncClient,
                                  requestId = requestId)

    def getDescriptors(self, page = 1, pageSize = 10, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                       requestId = None):
        """
        The function gets accounts' descriptors. Result is a list of descriptors and number of descriptors
        for the account. Every descriptor is represented by *descriptor_id* and number of  *linked_lists*, the
        descriptor is attached to.

        :param page: page number, positive.
        :type page: int
        :param pageSize: number of results per page, positive.
        :type pageSize: int
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getDescriptors(page, pageSize, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                              requestTimeOut = requestTimeOut,
                              connectTimeOut = connectTimeOut, login = self.login,
                              password = self.password, token = self.token, async = self.asyncClient,
                              requestId = requestId)

    def getDescriptor(self, descriptorId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                      requestId = None):
        """
        The function gets the descriptor, which corresponds to *descriptorId*.

        :param descriptorId: descriptor *id*
        :type descriptorId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getDescriptor(descriptorId, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                             requestTimeOut = requestTimeOut,
                             connectTimeOut = connectTimeOut, login = self.login,
                             password = self.password, token = self.token, async = self.asyncClient,
                             requestId = requestId)

    def linkDescriptorToPerson(self, personId, descriptorId, action = "attach", raiseError = False, requestTimeOut = 60,
                               connectTimeOut = 20, requestId = None):
        """
        The function creates or deletes a link between a descriptor and a person.

        :param personId: person id
        :type personId: str
        :param descriptorId: descriptor id
        :type descriptorId: str
        :param action: "attach" or "detach"
        :type action: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return linkDescriptorToPerson(personId, descriptorId, action, lunaUrl = self.getLunaUrl(),
                                      raiseError = raiseError,
                                      requestTimeOut = requestTimeOut,
                                      connectTimeOut = connectTimeOut, login = self.login,
                                      password = self.password, token = self.token, async = self.asyncClient,
                                      requestId = requestId)

    def getLinkedDescriptorToPerson(self, personId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                                    requestId = None):
        """
        The function gets the list of descriptors, which are linked to a person.

        :param personId: person id
        :type personId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getLinkedDescriptorToPerson(personId, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                                           requestTimeOut = requestTimeOut,
                                           connectTimeOut = connectTimeOut, login = self.login,
                                           password = self.password, token = self.token, async = self.asyncClient,
                                           requestId = requestId)

    def linkListToPerson(self, personId, listId, action = "attach", raiseError = False, requestTimeOut = 60,
                         connectTimeOut = 20, requestId = None):
        """
        The function creates or deletes a link between a list and a person.

        :param personId:  person id
        :type personId: str
        :param listId: list id
        :type listId: str
        :param action: "attach" or "detach"
        :type action: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return linkListToPerson(personId, listId, action, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                                requestTimeOut = requestTimeOut,
                                connectTimeOut = connectTimeOut, login = self.login,
                                password = self.password, token = self.token, async = self.asyncClient,
                                requestId = requestId)

    def getLinkedListsToPerson(self, personId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                               requestId = None):
        """
        The function gets the list of lists, which are linked to a person.

        :param personId: person id
        :type personId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getLinkedListsToPerson(personId, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                                      requestTimeOut = requestTimeOut,
                                      connectTimeOut = connectTimeOut, login = self.login,
                                      password = self.password, token = self.token, async = self.asyncClient,
                                      requestId = requestId)

    def linkListToDescriptor(self, descriptorId, listId, action = "attach", raiseError = False, requestTimeOut = 60,
                             connectTimeOut = 20, requestId = None):
        """
        The function creates or deletes a link between a list and a descriptor.

        :param descriptorId: descriptor id
        :type descriptorId: str
        :param listId: list id
        :type listId: str
        :param action: "attach" or "detach"
        :type action: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return linkListToDescriptor(descriptorId, listId, action, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                                    requestTimeOut = requestTimeOut,
                                    connectTimeOut = connectTimeOut, login = self.login,
                                    password = self.password, token = self.token, async = self.asyncClient,
                                    requestId = requestId)

    def getLinkedListsToDescriptor(self, descriptorId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
                                   requestId = None):
        """
        The function gets the list of lists, the descriptor is linked to.

        :param descriptorId: descriptor id
        :type descriptorId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getLinkedListsToDescriptor(descriptorId, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                                          requestTimeOut = requestTimeOut,
                                          connectTimeOut = connectTimeOut, login = self.login,
                                          password = self.password, token = self.token, async = self.asyncClient,
                                          requestId = requestId)

    def getPortrait(self, descriptorId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function gets the portrait, which corresponds to *descriptorId*.

        :param descriptorId: descriptor *id*
        :type descriptorId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getPortrait(descriptorId, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                           requestTimeOut = requestTimeOut,
                           connectTimeOut = connectTimeOut, login = self.login,
                           password = self.password, token = self.token, async = self.asyncClient,
                           requestId = requestId)

    def identify(self, personId = None, descriptorId = None, listId = None, personIds = None, limit = 3,
                 raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function matches a descriptor or person with a list of candidate persons.

        Either *descriptor_id* or *person_id* parameter should be specified as the reference and
        either *list_id* or *person_ids* parameter should be determined as the candidate.

        :param personId: person id to take the reference descriptors from
        :type personId: str
        :param descriptorId: reference descriptor id.
        :type descriptorId: str
        :param listId: candidate list id.
        :type listId: str
        :param personIds: list of candidate person ids
        :type personIds: List[str]
        :param limit:
        :type limit: int
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return identify(personId, descriptorId, listId, personIds, limit, lunaUrl = self.getLunaUrl(),
                        raiseError = raiseError,
                        requestTimeOut = requestTimeOut,
                        connectTimeOut = connectTimeOut, login = self.login,
                        password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def match(self, personId = None, descriptorId = None, listId = None, descriptorIds = None, limit = 3,
              raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function matches a descriptor or a person with a list of candidate descriptors.

		Either *descriptor_id* or *person_id* parameter should be specified as the reference and either *list_id* or
		*descriptor_ids* parameter should be determined as the candidate.

		:param personId: person id to take the reference descriptors from
        :type personId: str
        :param descriptorId: reference descriptor id.
        :type descriptorId: str
        :param listId: candidates list id.
        :type listId: str
        :param descriptorIds: list of candidate descriptor ids
        :type descriptorIds: list[str]
        :param limit:
        :type limit: int
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return match(personId, descriptorId, listId, descriptorIds, limit, lunaUrl = self.getLunaUrl(),
                     raiseError = raiseError,
                     requestTimeOut = requestTimeOut,
                     connectTimeOut = connectTimeOut, login = self.login,
                     password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def verify(self, descriptorId, personId, raiseError = False, requestTimeOut = 60, connectTimeOut = 20,
               requestId = None):
        """
        The function matches a descriptor with candidate person descriptors.


        :param descriptorId: the reference descriptor id.
        :type descriptorId: str
        :param personId: the reference person id.
        :type personId: str
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return verify(descriptorId, personId, lunaUrl = self.getLunaUrl(), raiseError = raiseError,
                      requestTimeOut = requestTimeOut,
                      connectTimeOut = connectTimeOut, login = self.login,
                      password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def search(self, body = None, filename = None, contentType = None, limit = 3, warpedImage = False,
               estimateAttributes = False, estimateQuality = False, scoreThreshold = 0,
               extractExif = False, listId = None, descriptorIds = None, personIds = None, raiseError = False,
               requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function extracts a descriptor from a photo, then matches it to a list of candidates.

		Either *list_id* or *person_ids* or *descriptor_ids* parameter should be specified as the candidate.

		:param body: image bytes
        :type body: bytearray
        :param filename: path to folder with the image
        :type filename: str
        :param contentType: image mime type
        :type contentType: str
        :param warpedImage: Determines, whether an input image is a warped or an arbitrary one. Exact image warping
                            algorithm is proprietary and this flag is intended for VisionLabs front-end tools only.

                            The warped image has the following properties:

                            * size is always 250x250 pixels;

                            * color format is always RGB; 

                            * single face in a photo;

                            * the face is always centered and rotated so that imaginary line between the eyes is
                           horizontal.
        :type warpedImage: bool
        :param estimateAttributes: whether to estimate face attributes for the image or not (gender, age, glasses).
        :type estimateAttributes: bool
        :param estimateQuality: estimate face suitability for recognition
        :type estimateQuality: bool
        :param scoreThreshold: If estimate_quality parameter is set to 1, it is possible to apply a threshold check
                                 to each estimation. All face detections with the quality below the threshold are
                                 ignored and no descriptors are extracted from them. The function proceeds as
                                 usual with all the remaining detections (if left).
        :type scoreThreshold: float
        :param extractExif: Whether to extract EXIF meta information from the input image or not.

                            Exact output varies since there are no mandatory data writing requirements both to the
                            authoring software and digital cameras.

                            This function only parses the tags and outputs their names and values as-is.
        :type extractExif: bool
        :param listId: candidates list id.
        :type listId: str
        :param descriptorIds: list of candidate descriptor ids
        :type descriptorIds: list[str]
        :param personIds: list of candidate person ids
        :type personIds: list[str]
        :param limit:
        :type limit: int
        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
		
		
        return search(body = body, filename = filename, contentType = contentType,
                      warpedImage = warpedImage,
                      estimateAttributes = estimateAttributes, estimateQuality = estimateQuality,
                      scoreThreshold = scoreThreshold,
                      extractExif = extractExif,
                      listId = listId, descriptorIds = descriptorIds, personIds = personIds, limit = limit,
                      lunaUrl = self.getLunaUrl(), raiseError = raiseError, requestTimeOut = requestTimeOut,
                      connectTimeOut = connectTimeOut, login = self.login,
                      password = self.password, token = self.token, async = self.asyncClient, requestId = requestId)

    def getVersion(self, raiseError = False, requestTimeOut = 60, connectTimeOut = 20, requestId = None):
        """
        The function gets LUNA API version.


        :param raiseError: LunaApiException is raised if the request failed.
        :type raiseError: bool
        :param requestTimeOut: request processing timeout period (in seconds).
        :type requestTimeOut: int
        :param connectTimeOut: connection timeout (in seconds).
        :type connectTimeOut: int
        :param requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                          requests, in system logs.
        :type requestId: string - pattern:
                         ^[0-9]{10},[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$


        :rtype: LunaResponse
        :return: returns structure, containing status code, request and LUNA API response decoded body.
        """
        return getVersion(self.lunaHost + ":" + str(self.lunaPort), raiseError = raiseError,
                          requestTimeOut = requestTimeOut, connectTimeOut = connectTimeOut, async = self.asyncClient,
                          requestId = requestId)
