Welcome to VisionLabs LUNA! LUNA python library, developed for connection with VisionLabs LUNA service. 
=============================================================================

VisionLabs LUNA provides a comprehensive set of facial analysis algorithms.

The service solves such tasks as face detection; face attributes detection, grouping, and recognition.

This module realizes a simple HTTP-client to LUNA API and implements all service requests (except account creation).

Face detection and attributes estimation
---------------------------------------

Detect all faces in a picture
..........................

Luna API Service tries to detect all faces in an image.

.. image:: https://cdn1.savepice.ru/uploads/2017/10/6/d6d42f033731603f903e4b4797927283-full.jpg

Example

.. code-block:: python

	from lunavl.httpclient import LunaHttpClient
	lunaClient = LunaHttpClient(login = "hornsandhooves@ya.ru", password = "secretpassword", endPoint = "http://127.0.0.1", port = 5000)
	faces = lunaClient.extractDescriptors(filename = "./image.jpeg")
	print(faces.body)

	{
	  'faces': [
		{
		  'id': '4acd1fdf-1410-4bc2-9086-52e1562e806e',
		  'rect':
			{
			  'height': 185,
			  'width': 133,
			  'x': 72,
			  'y': 41
			},
		  'rectISO':
			{
			  'height': 315,
			  'width': 236,
			  'x': 6,
			  'y': -30
			},
		  'score': 0.9929579496
		}
	  ]
	}



Attributes estimation
...................

LUNA API Service can estimate the following face attributes:

* age (from 0 to 100). Age is determined with approximate accuracy ± 3 years;
* gender (0 for female and 1 for male);
* presence of glasses (value from 0 to 1).

.. image:: https://cdn1.savepice.ru/uploads/2017/10/6/433a59c278bfbff304000268ea843f2d-full.jpg

Example

.. code-block:: python

	from lunavl.httpclient import LunaHttpClient
	lunaClient = LunaHttpClient(login = "hornsandhooves@ya.ru", password = "secretpassword", endPoint = "http://127.0.0.1", port = 5000)
	faces = lunaClient.extractDescriptors(filename = "./image.jpeg",  estimateAttributes = True)
	print(faces.body)

	{
	  'faces': [
		{
		  'attributes':
			{
			  'age': 16.5907974243,
			  'eyeglasses': 0.0004581214,
			  'gender': 0.0238201451
			},
		  'id': '4acd1fdf-1410-4bc2-9086-52e1562e806e',
		  'rect':
			{
			  'height': 185,
			  'width': 133,
			  'x': 72,
			  'y': 41
			},
		  'rectISO':
			{
			  'height': 315,
			  'width': 236,
			  'x': 6,
			  'y': -30
			},
		  'score': 0.9929579496
		}
	  ]
	}



Persons and descriptors
-----------------------

By default, LUNA Service creates a descriptor with the unique *id* for every detected face. Descriptors are stored in the system 
according to the storage policy. You can compare descriptors and estimate their similarity (see [matching](#matching)). Close to 1 similarity 
values mean that descriptors belong to the same person. LUNA API service allows grouping several faces, which belong to one human in 
an object *'person'*. 

Example

.. code-block:: python

	from lunavl.httpclient import LunaHttpClient
	lunaClient = LunaHttpClient(login = "hornsandhooves@ya.ru", password = "secretpassword")
	person = lunaClient.createPerson("some person data")  #: create person
	personId = person.body["person_id"]  #: get person id

	face = lunaClient.extractDescriptors(filename = "./image.jpg")
	descriptor_id = face.body["faces"][0]["id"] #: get descriptor id

	attachResponse = lunaClient.linkDescriptorToPerson(personId, descriptor_id, "attach")  #: attach descriptor to person
	person = lunaClient.getPerson(personId)

	{
	  'id': 'abd7d5c9-e514-4dfc-a2e3-41d49902d1eb',
	  'user_data': 'some person data',
	  'create_time': '2017-10-06T14:19:13.531728Z',
	  'descriptors': ['8fd8d823-b4fd-4b11-8def-b2a2a5ad3e92'],
	  'lists': []
	}


Lists
-----

Lists API provides persons' and descriptors' grouping. For example, one can create a "VIP-persons" list and
match every new incoming person with it. Using lists, one can recognize persons of interest.

.. image:: https://cdn1.savepice.ru/uploads/2017/10/6/d4346c2eb8a0e4a032449f6713268562-full.jpg

Example

.. code-block:: python

	from lunavl.httpclient import LunaHttpClient
	lunaClient = LunaHttpClient(login = "hornsandhooves@ya.ru", password = "secretpassword", endPoint = "http://127.0.0.1", port = 5000)
	person = lunaClient.createPerson("some person data")  #: create person
	personId = person.body["person_id"]
	face = lunaClient.extractDescriptors(filename = "./image.jpg")
	descriptor_id = face.body["faces"][0]["id"] #: get descriptor id
	attachResponse = lunaClient.linkDescriptorToPerson(personId, descriptor_id, "attach")  #: attach descriptor to person
	list = lunaClient.createList("persons", "super peoples") #: create list of persons with list data "super peoples"
	listId = list.body["list_id"]	#: get id of list
	lunaClient.linkListToPerson(personId, listId, "attach")
	personsInList = lunaClient.getList(listId, 1, 10) #: get first 10 persons from list
	print(personsInList.body)

	{
	  'persons':                                                         #: type of list
		[
		  {                                                              #: person #1
			'id': 'b6de4ff8-7f4b-4cf5-81e7-2e45b5025499',
			'user_data': 'some person data',
			'create_time': '2017-10-06T14:35:51.858950Z',
			'descriptors': ['ebeee1e7-5f96-483c-89ed-dbc7af0a6c9b'],
			'lists': ['89fa62f6-9bbe-4a60-ae40-808cc8a62446']
		  }
		],
	  'count': 1,                                                        #: count objects in list
	  'list_data': 'super peoples'                                       #: user data for list
	}


Matching
--------

The matching module solves face recognition tasks by comparing face images. The service searches for persons or descriptors with 
the highest similarities in some groups, regarding a reference person or descriptor.  By "groups" we mean LUNA lists, descriptors' 
or persons' sets.


.. image:: https://cdn1.savepice.ru/uploads/2017/10/6/47d85c967893d800e26e80d5cdd88f0c-full.jpg

Example

.. code-block:: python

	from lunavl.httpclient import LunaHttpClient
	lunaClient = LunaHttpClient(login = "hornsandhooves@ya.ru", password = "secretpassword", endPoint = "http://127.0.0.1", port = 5000)
	list = lunaClient.createList("persons", "super peoples")
	listId = list.body["list_id"]
	for count, file in enumerate(["./img_1.jpg", "./img_2.jpg"]):
		descriptorId = lunaClient.extractDescriptors(filename = file).body["faces"][0]["id"]
		personId = lunaClient.createPerson("person {}".format(count + 1)).body["person_id"]
		lunaClient.linkDescriptorToPerson(personId, descriptorId, "attach")
		lunaClient.linkListToPerson(personId, descriptorId, "attach")
	searchResult = lunaClient.search(filename = "./warped-image.jpeg", listId = listId, estimateAttributes = True)
	print(searchResult.body)

	{
	  'candidates': [
		{
		  'similarity': 0.0005030526,
		  'person_id': '78beff5e-dec1-4f80-b19c-1d9ccb69dcfd',
		  'descriptor_id': '11cf3078-4317-4a4e-b4b3-11195cbdccfc',
		  'user_data': 'person 2'
		},
		{
		  'similarity': 8.83326e-05,
		  'person_id': 'ac790afa-ee82-4e11-8348-867001dc9500',
		  'descriptor_id': 'b061db5e-82b3-4351-bb0d-5e00d0b24220',
		  'user_data': 'person 1'
		}
	  ],
	  'face':
		{
		  'attributes':
		  {
			'age': 15.9235677719,
			'eyeglasses': 0.0007472112,
			'gender': 0.0452354811
		  },
		  'id': '2fd38ec2-7f72-4e4a-b344-475d73c28e06',
		  'rect':
			{
			  'height': 185,
			  'width': 133,
			  'x': 72,
			  'y': 41
			},
		  'rectISO':
			{
			  'height': 315,
			  'width': 236,
			  'x': 6,
			  'y': -30
			},
		  'score': 0.9929579496
		}
	}


Asynchronous mode
-----------------

The library supports asynchronous requests to LUNA API. If one chooses an asynchronous mode, he/she should create
[tornado ioloop](http://www.tornadoweb.org/en/stable/ioloop.html).

Example 

.. code-block:: python

	import tornado.httpclient
	from tornado import gen
	from lunavl.httpclient import LunaHttpClient

	@gen.coroutine
	def search():
		lunaClient = LunaHttpClient(login = "hornsandhooves@ya.ru", password = "secretpassword", async = True, endPoint = "http://127.0.0.1", port = 5000)
		list = yield lunaClient.createList("persons", "super peoples")
		listId = list.body["list_id"]
		personIds = []
		for count, file in enumerate(["./img_1.jpg", "./img_2.jpg"]):
			descriptor = yield lunaClient.extractDescriptors(filename = file)
			descriptorId = descriptor.body["faces"][0]["id"]
			person = yield lunaClient.createPerson("person {}".format(count + 1))
			personId = person.body["person_id"]
			personIds.append(personId)
			yield lunaClient.linkDescriptorToPerson(personId, descriptorId, "attach")
			yield lunaClient.linkListToPerson(personId, listId, "attach")
		searchResult = yield lunaClient.search(filename = "./warped-image.jpeg", personIds = personIds, estimateAttributes = True) #: search by dynamic list of persons
		print(searchResult.body)

	if __name__ == '__main__':
		ioloop = tornado.ioloop.IOLoop.current()					#: get tornado ioloop
		tornado.ioloop.IOLoop.current().spawn_callback(search)		#: add task to loop
		ioloop.start()												#: start loop

	{
	  'candidates': [
		{
		  'similarity': 0.0005030526,
		  'person_id': 'c34f1d06-3845-42e6-bf43-8c810e7ef3e8',
		  'descriptor_id': '3107b3f6-5904-4bcf-a527-6df9f3b13d31',
		  'user_data': 'person 2'
		},
		{
		  'similarity': 8.83326e-05,
		  'person_id': 'e4b7afb2-9bea-436c-adbf-ad992a4cd864',
		  'descriptor_id': '86f8d0d6-c080-4e7d-b5e9-673fa78fd60a',
		  'user_data': 'person 1'
		  }
		],
		'face':
		  {
			'attributes':
			  {
				'age': 15.9235677719,
				'eyeglasses': 0.0007472112,
				'gender': 0.0452354811
			  },
			'id': '8f81a1bf-29e4-44b2-b5dd-21bc998c4706',
			'rect':
			  {
				'height': 185,
				'width': 133,
				'x': 72,
				'y': 41
			  },
			'rectISO':
			  {
				'height': 315,
				'width': 236,
				'x': 6,
				'y': -30
			  },
			'score': 0.9929579496
		  }
	}
