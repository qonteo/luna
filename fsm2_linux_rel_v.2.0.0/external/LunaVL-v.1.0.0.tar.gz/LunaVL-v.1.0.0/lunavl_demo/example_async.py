import tornado.httpclient
from tornado import gen
from lunavl.httpclient import LunaHttpClient
from lunavl_demo.config import LUNA_API_LOGIN, LUNA_API_PASSWORD
from time import time

lunaClient = LunaHttpClient(token = "0ac16956-12b9-42b8-a2a1-b16ff3ebba74", async = True)


@gen.coroutine
def search():
    """
    Asynchronous  LunaHttpClient usage example.
    """
    list = yield lunaClient.createList("persons", "super peoples")
    listId = list.body["list_id"]
    personIds = []
    for count, file in enumerate(["./img_1.jpg", "./img_2.jpg"]):
        descriptor = yield lunaClient.extractDescriptors(filename = file)
        descriptorId = descriptor.body["faces"][0]["id"]
        person = yield lunaClient.createPerson("person {}".format(count + 1))
        personId = person.body["person_id"]
        personIds.append(personId)
        yield lunaClient.linkDescriptorToPerson(personId, descriptorId, "attach")
        yield lunaClient.linkListToPerson(personId, listId, "attach")
    searchResult = yield lunaClient.search(filename = "./warped-image.jpeg", personIds = personIds, estimateAttributes = True)
    print(searchResult.body)
    tornado.ioloop.IOLoop.current().stop()


@gen.coroutine
def upload():
    """
    Usage example of descriptors' extraction from a file (in the asynchronous mode).
    """
    start = time()
    futures = []
    for count, file in enumerate(["./img_1.jpg", "./img_2.jpg"]):
        futures.append(lunaClient.extractDescriptors(filename = file))
    for future in futures:
        res = yield future
        print(res.body)
    print("async time:", time() - start)
    lunaClient2 = LunaHttpClient(login = "hornsandhooves@ya.ru", password = "secretpassword", async = False)
    start2 = time()
    for count, file in enumerate(["./img_1.jpg", "./img_2.jpg"]):
        lunaClient2.extractDescriptors(filename = file)
    print("sync time:", time() - start2)
    tornado.ioloop.IOLoop.current().stop()


if __name__ == '__main__':
    io_loop = tornado.ioloop.IOLoop.current()
    tornado.ioloop.IOLoop.current().spawn_callback(upload)
    io_loop.start()
