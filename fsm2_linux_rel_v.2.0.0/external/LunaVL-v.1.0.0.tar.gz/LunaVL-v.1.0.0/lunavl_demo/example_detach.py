from lunavl.httpclient import LunaHttpClient
from lunavl_demo.config import LUNA_API_LOGIN, LUNA_API_PASSWORD

lunaClient = LunaHttpClient(login = LUNA_API_LOGIN, password = LUNA_API_PASSWORD, endPoint = "http://127.0.0.1")


def extractDescriptorFromFile(filename):
    """
    The function extracts a descriptor from an image and returns descriptor id.

    :param filename: path to the file
    :return: descriptor id
    """
    faces = lunaClient.extractDescriptors(filename = filename)
    return faces.body["faces"][0]["id"]


def createPersonWithDescriptor(filename):
    """
    The function creates a person, extracts a descriptor and links the descriptor to the person.

    :param filename: path to file
    :return: ids of person and descriptor
    """
    person = lunaClient.createPerson("some person data")    #: create a person
    personId = person.body["person_id"]
    descriptorId = extractDescriptorFromFile(filename)      #: extract a descriptor
    lunaClient.linkDescriptorToPerson(personId, descriptorId, "attach")
    return personId, descriptorId


def createList(listType, listData):
    """
    The function creates a list in LUNA and returns list id.

    :param listType: list type ("descriptors", "persons")
    :param listData: list data

    :return: list id
    """
    lunaList = lunaClient.createList(listType, listData)
    return lunaList.body["list_id"]


def main(filename):
    descriptorListId = createList("descriptors", "descriptors list")
    personListId = createList("persons", "persons list")
    personId, descriptorId = createPersonWithDescriptor(filename)
    lunaClient.linkListToDescriptor(descriptorId, descriptorListId, "attach")
    lunaClient.linkListToPerson(personId, personListId, "attach")
    personList = lunaClient.getList(personListId)
    print("update persons list:", personList.body)
    descriptorList = lunaClient.getList(descriptorListId)
    print("update descriptors list:", descriptorList.body)
    lunaClient.linkListToDescriptor(descriptorId, descriptorListId, "detach")   #: detach the descriptor from the list
    lunaClient.linkListToPerson(personId, personListId, "detach")               #: detach the person from the list
    personList = lunaClient.getList(personListId)
    print("update persons list:", personList.body)
    descriptorList = lunaClient.getList(descriptorListId)
    print("update descriptors list:", descriptorList.body)
    lunaClient.linkDescriptorToPerson(personId, descriptorId, "detach")         #: detach the descriptor from the person
    person = lunaClient.getPerson(personId)
    print("Update person", person.body)

if __name__ == '__main__':
    main("./img_1.jpg")