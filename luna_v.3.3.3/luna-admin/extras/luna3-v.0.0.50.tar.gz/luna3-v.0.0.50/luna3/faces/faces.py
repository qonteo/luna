from luna3.common.base_api import BaseAPI

from luna3.common.requests import makeRequest
from luna3.common.luna_response import LunaResponse
from typing import Optional, Generator, Union, List


class FacesApi(BaseAPI):
    """
    Class for request to luna-faces.

    Attributes:
        origin (str): luna-faces protocol, host and port; default "http://127.0.0.1:5030"
        api (int): api version of  luna-faces, default 1
        lunaRequestId: Luna-Request-Id.
        asyncRequest (bool): default mode for request async or blocking
        requestTimeout: request processing timeout in seconds.
        connectTimeout: connection timeout seconds.
    """

    def __init__(self, origin: Optional[str] = "http://127.0.0.1:5030", api: Optional[int] = 1,
                 asyncRequest: Optional[bool] = False, lunaRequestId: Optional[str] = None,
                 requestTimeout: int = 20, connectTimeout: int = 60):
        super().__init__(origin, api, asyncRequest, lunaRequestId, requestTimeout, connectTimeout)

    def createFace(self, accountId: str, attributesId: Optional[str] = None, eventId: Optional[str] = None,
                   userData: Optional[str] = "", externalId: Optional[str] = None,
                   lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create new face in luna-faces

        Args:
            userData: face user data
            eventId: reference to event which created face
            attributesId: attributes id
            accountId: id of account
            externalId: external id of the person, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with version will be returned.
        """
        body = {"account_id": accountId, "user_data": userData}
        if attributesId is not None:
            body["attributes_id"] = attributesId
        if eventId is not None:
            body["event_id"] = eventId
        if externalId is not None:
            body['external_id'] = externalId
        return makeRequest(self.baseUri + "/faces", "POST", json=body, asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def putFace(self, faceId: str, accountId: str, externalId: Optional[str] = None, attributesId: Optional[str] = None,
                eventId: Optional[str] = None, userData: Optional[str] = "", lunaRequestId: Optional[bool] = None,
                asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False, requestTimeout: int = None,
                connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Put face in luna-faces

        Args:
            faceId: external face id
            userData: face user data
            eventId: reference to event which created face
            externalId: external id of the face, if it has its own mapping in the system
            attributesId: attributes id
            accountId: id of account
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with face id will be returned.
        """
        body = {"account_id": accountId, "user_data": userData}
        if attributesId is not None:
            body["attributes_id"] = attributesId
        if eventId is not None:
            body["event_id"] = eventId
        if externalId is not None:
            body['external_id'] = externalId
        return makeRequest(self.baseUri + "/faces/" + faceId, "PUT", json=body,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getFaces(self, userData: Optional[str] = None, accountId: Optional[str] = None, eventId: Optional[str] = None,
                 listId: Optional[str] = None, faceIds: Optional[List[str]] = None, timeLt: Optional[str] = None,
                 timeGte: Optional[str] = None, page: Optional[int] = 1, pageSize: Optional[int] = 10,
                 externalId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                 asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                 requestTimeout: int = None, connectTimeout: int = None
                 ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get faces by filters. Optional you can set, that faces must belong to account.

        Args:
            userData: user data, part of user data, case insensitive
            accountId: account id
            eventId: event id
            listId: list id
            faceIds: face ids
            timeLt: upper bound of face create time
            timeGte: lower bound of face create time
            page: page count, default 1
            pageSize: page size, default 10
            externalId: external id of the face, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with faces will be returned.
        """
        queries = {"user_data": userData, "account_id": accountId, "event_id": eventId, "list_id": listId,
                   "face_ids": faceIds, "time__lt": timeLt, "time__gte": timeGte, "page": page, "page_size": pageSize,
                   'external_id': externalId}
        return makeRequest(self.baseUri + "/faces", "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteFaces(self, faceIds: List[str], accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                    asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                    requestTimeout: int = None, connectTimeout: int = None
                    ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete faces. Optional you can set, that faces must belong to account.

        Args:
            faceIds: face id list
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        body = {"face_ids": faceIds}
        return makeRequest(self.baseUri + "/faces", "DELETE", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           json=body, headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getFace(self, faceId: str, accountId: Optional[str] = None, externalId: Optional[str] = None,
                lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get face by id. Optional you can set, that face must belong to account.

        Args:
            faceId: face id
            accountId: account id
            asyncRequest: execution in asynchronous mode, disabled by default
            externalId: external id of the person, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with face will be returned.
        """
        queries = {"account_id": accountId, 'external_id': externalId}
        return makeRequest("{}/faces/{}".format(self.baseUri, faceId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def checkFace(self, faceId: str, accountId: Optional[str] = None, externalId: Optional[str] = None,
                  lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                  raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                  ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Check face existence by id. Optional you can set, that face must belong to account.

        Args:
            faceId: face id
            accountId: account id
            asyncRequest: execution in asynchronous mode, disabled by default
            externalId: external id of the person, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId, 'external_id': externalId}
        return makeRequest("{}/faces/{}".format(self.baseUri, faceId), "HEAD", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def updateFace(self, faceId: str, accountId: Optional[str] = None, attributesId: Optional[str] = None,
                   eventId: Optional[str] = None, userData: Optional[str] = None, externalId: Optional[str] = None,
                   lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Update face. You can update event id, user data, attributes id. Optional you can set, that face must belong
        to account.

        Args:
            faceId: face id
            accountId: account id
            attributesId: new attributes id
            eventId: new event id
            externalId: external id of the person, if it has its own mapping in the system
            userData: new user data
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest (bool): execution in asynchronous mode, disabled by default
            raiseError (bool): if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        body = {}
        if userData is not None:
            body["user_data"] = userData
        if attributesId is not None:
            body["attributes_id"] = attributesId
        if eventId is not None:
            body["event_id"] = eventId
        if externalId is not None:
            body['external_id'] = externalId
        queries = {"account_id": accountId}
        return makeRequest("{}/faces/{}".format(self.baseUri, faceId), "PATCH", json=body, queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteFace(self, faceId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                   asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete face. Optional you can set, that face must belong to account.

        Args:
            faceId: face id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/faces/{}".format(self.baseUri, faceId), "DELETE", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def createList(self, accountId: str, userData: Optional[str] = "", listType: Optional[int] = 0,
                   lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create list.

        Args:
            accountId: account id
            userData: user data
            listType: list type, 1 - persons, 0 faces
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with created list id will be returned.
        """
        body = {"account_id": accountId, "user_data": userData, "type": listType}
        return makeRequest(self.baseUri + "/lists", "POST", json=body, asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteLists(self, listIds: List[str], accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                    asyncRequest: Optional[bool] = None,
                    raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                    ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete lists. Optional you can set, that lists must belong to account.

        Args:
            listIds: ids of lists
            accountId: account id,
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        body = {"list_ids": listIds}
        return makeRequest(self.baseUri + "/lists", "DELETE", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def optionsLists(self, listIds: List[str], lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                     raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get lists with link and unlink keys by list ids.

        Args:
            listIds: lists ids
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with lists will be returned.
        """
        return makeRequest(self.baseUri + "/lists", "OPTIONS", json={'list_ids': listIds},
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getLists(self, userData: Optional[str] = None, accountId: Optional[str] = None, listType=None,
                 page: Optional[int] = 1, pageSize: Optional[int] = 10, lunaRequestId: Optional[str] = None,
                 asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                 requestTimeout: int = None, connectTimeout: int = None
                 ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get lists. Optional you can set, that lists must belong to account.

        Args:
            userData: user data, part of user data, case sensitive
            accountId: account id
            listType: list type, 1 - persons, 0 faces
            page: page, default 1
            pageSize: page size, default 10
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with lists will be returned.
        """
        queries = {"account_id": accountId, "user_data": userData, "page": page, "page_size": pageSize,
                   "type": listType}
        return makeRequest(self.baseUri + "/lists", "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getList(self, listId: str, accountId: Optional[str] = None, page: Optional[int] = 1,
                pageSize: Optional[int] = 10, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get list. Optional you can set, that list must belong to account.

        Args:
            listId: list id
            accountId: account id
            page: page count, default 1
            pageSize: page size, default 10
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with list will be returned.
        """
        queries = {"page": page, "page_size": pageSize, "account_id": accountId}
        return makeRequest("{}/lists/{}".format(self.baseUri, listId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def checkList(self, listId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                  asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                  requestTimeout: int = None, connectTimeout: int = None
                  ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Check list existence. Optional you can set, that list must belong to account.

        Args:
            listId: list id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/lists/{}".format(self.baseUri, listId), "HEAD", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteList(self, listId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                   asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Remove list. Optional you can set, that list must belong to account.

        Args:
            listId: list id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/lists/{}".format(self.baseUri, listId), "DELETE", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def updateListUserData(self, listId: str, userData: str, accountId: Optional[str] = None,
                           lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                           raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                           ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Update user data of list. Optional you can set, that list must belong to account.

        Args:
            listId: list id
            userData: new user data
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        body = {"user_data": userData}
        return makeRequest("{}/lists/{}".format(self.baseUri, listId), "PATCH", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def link(self, listId: str, faceIds: Optional[List[str]] = None, personIds: Optional[List[str]] = None,
             action: Optional[str] = "attach",
             accountId: Optional[str] = None, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
             raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
             ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Attach or detach faces to list. Optional you can set, that list and faces must belong to account.

        Args:
            listId: list id
            faceIds: face ids
            personIds: person ids
            action: attach or detach
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        body = {"action": action, "list_id": listId}
        if faceIds is not None:
            body["face_ids"] = faceIds
        else:
            body["person_ids"] = personIds
        return makeRequest("{}/linker".format(self.baseUri), "PATCH", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getAttributesFromList(self, listId: str, linkKeyLt: Optional[str] = None, linkKeyGte: Optional[str] = None,
                              limit: Optional[int] = 1000, lunaRequestId: Optional[str] = None,
                              asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                              requestTimeout: int = None, connectTimeout: int = None
                              ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get all attributes from list by period.

        Args:
            listId: list id
            linkKeyLt: upper bound of face update time
            linkKeyGte: lower bound of face update time
            limit: limit
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with attributes will be returned.
        """
        queries = {"link_key__lt": linkKeyLt, "link_key__gte": linkKeyGte, "limit": limit}
        return makeRequest("{}/lists/{}/attributes".format(self.baseUri, listId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getDeletionsFromList(self, listId: str, linkKeyLt: Optional[str] = None, linkKeyGte: Optional[str] = None,
                             limit: Optional[int] = 1000, lunaRequestId: Optional[str] = None,
                             asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                             requestTimeout: int = None, connectTimeout: int = None
                             ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get all deletions from list by period.

        Args:
            listId: list id
            linkKeyLt: upper bound of face update time
            linkKeyGte: lower bound of face update time
            limit: limit
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with attributes will be returned.
        """
        queries = {"link_key__lt": linkKeyLt, "link_key__gte": linkKeyGte, "limit": limit}
        return makeRequest("{}/lists/{}/deletions".format(self.baseUri, listId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def createPerson(self, accountId: str, userData: Optional[str] = "", externalId: Optional[str] = None,
                     lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                     raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create person.

        Args:
            accountId: account id
            userData: user data
            externalId: external id of the person, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with person id will be returned.
        """
        body = {"account_id": accountId, "user_data": userData}
        if externalId is not None:
            body["external_id"] = externalId
        return makeRequest(self.baseUri + "/persons", "POST", json=body,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deletePersons(self, personIds: List[str], accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                      asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                      requestTimeout: int = None, connectTimeout: int = None
                      ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete persons. Optional you can set, that persons must belong to account.

        Args:
            personIds: ids of persons
            accountId: account id,
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        body = {"person_ids": personIds}
        return makeRequest(self.baseUri + "/persons", "DELETE", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), json=body, raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getPersons(self, userData: Optional[str] = None, accountId: Optional[str] = None, timeLt: Optional[str] = None,
                   timeGte: Optional[str] = None, personIds: Optional[List[str]] = None,
                   page: Optional[int] = 1, pageSize: Optional[int] = 10, externalId: Optional[str] = None,
                   lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get persons. Optional you can set, that persons must belong to account.

        Args:
            userData: user data, part of user data, case sensitive
            accountId: account id
            personIds: list of person ids
            timeLt: upper bound of face create time
            timeGte: lower bound of face create time
            page: page, default 1
            pageSize: page size, default 10
            externalId: external id of the person, if it has its own mapping in the system
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with persons will be returned.
        """
        queries = {"account_id": accountId, "user_data": userData, "page": page, "page_size": pageSize,
                   "time__lt": timeLt, "time__gte": timeGte, "person_ids": personIds, "external_id": externalId}
        return makeRequest(self.baseUri + "/persons", "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getPerson(self, personId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                  asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False, requestTimeout: int = None,
                  connectTimeout: int = None
                  ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get person. Optional you can set, that person must belong to account.

        Args:
            personId: person id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with person will be returned.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/persons/{}".format(self.baseUri, personId), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def checkPerson(self, personId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                    asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False, requestTimeout: int = None,
                    connectTimeout: int = None
                    ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Check person existence. Optional you can set, that person must belong to account.

        Args:
            personId: person id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/persons/{}".format(self.baseUri, personId), "HEAD", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deletePerson(self, personId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                     asyncRequest: Optional[bool] = None,
                     raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Remove person. Optional you can set, that person must belong to account.

        Args:
            personId: person id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        return makeRequest("{}/persons/{}".format(self.baseUri, personId), "DELETE", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def updatePerson(self, personId: str, userData: str, accountId: Optional[str] = None,
                     externalId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                     asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                     requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Update user data of person. Optional you can set, that person must belong to account.

        Args:
            personId: person id
            userData: new user data
            externalId: external id of the person, if it has its own mapping in the system
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        body = {"user_data": userData}
        if externalId is not None:
            body['external_id'] = externalId
        return makeRequest("{}/persons/{}".format(self.baseUri, personId), "PATCH", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def linkFaceToPerson(self, faceId: str, personId: str, action: Optional[str] = "attach",
                         accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                         asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                         requestTimeout: int = None, connectTimeout: int = None
                         ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Attach or detach face to person.Optional you can set, that list must belong to account.

        Args:
            faceId: face id
            personId: person id
            action: attach or detach face from person
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"account_id": accountId}
        body = {"person_id": personId, "face_id": faceId, "action": action}
        return makeRequest("{}/facelinker".format(self.baseUri), "PATCH", queryParams=queries, json=body,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def removeNotLinkedFaces(self, accountId: Optional[str] = None, timeLt: Optional[str] = None, limit: int = 1000,
                             lunaRequestId: Optional[str] = None,
                             asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                             requestTimeout: int = None, connectTimeout: int = None
                             ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Removing not linked faces

        Args:

            accountId: account id
            timeLt: upper bound of face update time
            limit: max face count for removing (maximum 1000)
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with removed faces' ids will be returned.
        """
        queries = {"account_id": accountId, "limit": limit, "time__lt": timeLt}
        return makeRequest("{}/gc".format(self.baseUri), "PATCH", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def cleanLog(self, timeLt: Optional[str] = None, lunaRequestId: Optional[str] = None,
                 asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False, requestTimeout: int = None,
                 connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Remove notes from log

        Args:
            timeLt: upper bound of face update time with timezone excluding boundary
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with attributes ids will be returned.
        """
        queries = {'time__lt': timeLt}
        return makeRequest('{}/linker/unlink_history'.format(self.baseUri), 'PATCH', queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def facesAttributes(self, faceIds: List, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                        asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                        requestTimeout: int = None,
                        connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Return attributesID of faces from faceIds list

        Args:
            faceIds: list of faceId for return their attributes
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with attributes ids will be returned.
        """
        return makeRequest('{}/faces/attributes'.format(self.baseUri), 'GET',
                           queryParams={'faces_ids': faceIds, "account_id": accountId},
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def faceAttributes(self, faceId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                       asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                       requestTimeout: int = None,
                       connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Return attributesID of face

        Args:
            faceId: face id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with attributes ids will be returned.
        """
        return makeRequest('{}/faces/{}/attributes'.format(self.baseUri, faceId), 'GET',
                           queryParams={"account_id": accountId}, headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def personsAttributes(self, personIds: List, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                          asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                          requestTimeout: int = None,
                          connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Return attributesID faces of persons from personIds list

        Args:
            personIds: list of personId for return their faces attributes
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with attributes ids will be returned.
        """
        return makeRequest('{}/persons/attributes'.format(self.baseUri), 'GET',
                           queryParams={'persons_ids': personIds, "account_id": accountId},
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def personAttributes(self, personId: str, accountId: Optional[str] = None, lunaRequestId: Optional[str] = None,
                         asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                         requestTimeout: int = None,
                         connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Return attributesIDs faces of person

        Args:
            personId: person id
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with attributes ids will be returned.
        """
        return makeRequest('{}/persons/{}/attributes'.format(self.baseUri, personId), 'GET',
                           queryParams={"account_id": accountId}, headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getAttributesIds(self, listId: Optional[str] = None, accountId: Optional[str] = None,
                         timeLt: Optional[str] = None, timeGte: Optional[str] = None, page: Optional[int] = 1,
                         pageSize: Optional[int] = 1000, lunaRequestId: Optional[str] = None,
                         asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                         requestTimeout: int = None, connectTimeout: int = None
                         ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get ids of attributes from list by period.

        Args:
            listId: list id
            accountId: account id
            timeLt: upper bound of face update time
            timeGte: lower bound of face update time
            page: page, default 1
            pageSize: page size, default 1000, max 100000
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with attributes ids will be returned.
        """
        queries = {"time__lt": timeLt, "time__gte": timeGte, "page": page, "page_size": pageSize,
                   "account_id": accountId, "list_id": listId}
        return makeRequest("{}/attributes".format(self.baseUri), "GET", queryParams=queries,
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getAttributes(self, objects: List[str], meta: int = None, retrieve: str = None,
                      lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                      raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                      ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get list of attributes

        Args:
            objects: list of attributes to delete
            meta: meta information about attributes. samples from which the attributes were extracted
                and method as an attribute was obtained
            retrieve: List of attributes splitted by comma. retrieve only them. By default return all attributes.
                     descriptor, age, gender
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {'objects': objects}
        queries = {'meta': meta, 'retrieve': retrieve}
        return makeRequest('{}/attributes/collection'.format(self.baseUri), "GET", queryParams=queries, json=body,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.getRequestIdHeader(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def createAttributes(self, descriptor: str = None, descriptor_samples: List[str] = None,
                         descriptor_obtaining_method: int = None, gender: int = None, gender_samples: List[str] = None,
                         gender_obtaining_method: int = None, age: int = None, age_samples: List[str] = None,
                         age_obtaining_method: int = None, XPK: bytes = None, lunaRequestId: Optional[str] = None,
                         asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                         requestTimeout: int = None, connectTimeout: int = None
                         ) -> Union[Generator[LunaResponse, None, None], LunaResponse]:
        """
        Create new attributes. Notice that XPK argument overwrites everything above.

        Args:
            descriptor: binary descriptor encode in base64 string.
            descriptor_samples: list of warp image id from which the attribute was extracted.
            descriptor_obtaining_method: how the descriptor was obtained.
            gender: Gender. 0 - man, 1 - woman.
            gender_samples: list of warp image id from which the attribute was extracted.
            gender_obtaining_method: how the gender was obtained.
            age: age from 0 to 100.
            age_samples: list of warp image id from which the attribute was extracted.
            age_obtaining_method: how the age was obtained.
            XPK: xpk file bytes to load attributes from
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = self.getRequestIdHeader(lunaRequestId)
        if XPK is None:
            body = {}
            if descriptor is not None:
                body['descriptor'] = descriptor
            if descriptor_samples is not None:
                body['descriptor_samples'] = descriptor_samples
            if descriptor_obtaining_method is not None:
                body['descriptor_obtaining_method'] = descriptor_obtaining_method
            if gender is not None:
                body['gender'] = gender
            if gender_samples is not None:
                body['gender_samples'] = gender_samples
            if gender_obtaining_method is not None:
                body['gender_obtaining_method'] = gender_obtaining_method
            if age is not None:
                body['age'] = age
            if age_samples is not None:
                body['age_samples'] = age_samples
            if age_obtaining_method is not None:
                body['age_obtaining_method'] = age_obtaining_method
            kwargs = {'json': body}
        else:
            kwargs = {'body': XPK}
            headers.update({"Content-Type": "application/x-vl-xpk"})
        return makeRequest('{}/attributes/collection'.format(self.baseUri), "POST", **kwargs, headers=headers,
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteAttributes(self, objects: List[str], lunaRequestId: Optional[str] = None,
                         asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                         requestTimeout: int = None, connectTimeout: int = None
                         ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete list of attributes

        Args:
            objects: list of attributes to delete
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {'objects': objects}
        return makeRequest('{}/attributes/collection'.format(self.baseUri), "DELETE", json=body,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.getRequestIdHeader(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def optionsAttributes(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                          raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                          ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Returns allowed request methods and all attributes.

        Args:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/attributes/collection'.format(self.baseUri), "OPTIONS",
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def checkAttribute(self, attributesId: str, lunaRequestId: Optional[str] = None,
                       asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                       requestTimeout: int = None, connectTimeout: int = None
                       ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Check attributes with attributes id exists.

        Args:
            attributesId: attribute id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/attributes/{}'.format(self.baseUri, attributesId), "HEAD",
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.getRequestIdHeader(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getAttribute(self, attributesId: str, meta: int = None, retrieve: str = None, asXPK: Optional[bool] = None,
                     lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                     raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Retrieve a attributes by id.

        Args:
            attributesId: attribute id
            meta: meta information about attributes. samples from which the attributes were extracted
                and method as an attribute was obtained.
            retrieve: List of attributes splitted by comma. retrieve only them. By default return all attributes.
                     descriptor, age, gender
            asXPK: if to get attributes as XPK
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = self.getRequestIdHeader(lunaRequestId)
        headers.update(Accept='application/x-vl-xpk' if asXPK else 'application/json')

        queries = {'meta': meta, 'retrieve': retrieve}
        return makeRequest('{}/attributes/{}'.format(self.baseUri, attributesId), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=headers,
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def replaceAttributes(self, attributesId: str, descriptor: str = None, descriptor_samples: List[str] = None,
                          descriptor_obtaining_method: int = None, gender: int = None,
                          gender_samples: List[str] = None, gender_obtaining_method: int = None,
                          age: int = None, age_samples: List[str] = None, age_obtaining_method: int = None,
                          XPK: bytes = None, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                          raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                          ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create new attributes with specified id. Notice that XPK argument overwrites everything above.

        Args:
            attributesId: attribute id
            descriptor: binary descriptor encode in base64 string.
            descriptor_samples: list of warp image id from which the attribute was extracted.
            descriptor_obtaining_method: how the descriptor was obtained.
            gender: Gender. 0 - man, 1 - woman.
            gender_samples: list of warp image id from which the attribute was extracted.
            gender_obtaining_method: how the gender was obtained.
            age: age from 0 to 100.
            age_samples: list of warp image id from which the attribute was extracted.
            age_obtaining_method: how the age was obtained.
            XPK: xpk file bytes to load attributes from
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = self.getRequestIdHeader(lunaRequestId)
        if XPK is None:
            body = {}
            if descriptor is not None:
                body['descriptor'] = descriptor
            if descriptor_samples is not None:
                body['descriptor_samples'] = descriptor_samples
            if descriptor_obtaining_method is not None:
                body['descriptor_obtaining_method'] = descriptor_obtaining_method
            if gender is not None:
                body['gender'] = gender
            if gender_samples is not None:
                body['gender_samples'] = gender_samples
            if gender_obtaining_method is not None:
                body['gender_obtaining_method'] = gender_obtaining_method
            if age is not None:
                body['age'] = age
            if age_samples is not None:
                body['age_samples'] = age_samples
            if age_obtaining_method is not None:
                body['age_obtaining_method'] = age_obtaining_method
            kwargs = {'json': body}
        else:
            kwargs = {'body': XPK}
            headers.update({"Content-Type": "application/x-vl-xpk"})
        return makeRequest('{}/attributes/{}'.format(self.baseUri, attributesId), "PUT", **kwargs, headers=headers,
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def updateAttribute(self, attributesId: str, descriptor: str = None, descriptor_samples: List[str] = None,
                        descriptor_obtaining_method: int = None, gender: int = None,
                        gender_samples: List[str] = None, gender_obtaining_method: int = None,
                        age: int = None, age_samples: List[str] = None, age_obtaining_method: int = None,
                        lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                        raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                        ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Update attribute with specified id

        Args:
            attributesId: attribute id
            descriptor: binary descriptor encode in base64 string.
            descriptor_samples: list of warp image id from which the attribute was extracted.
            descriptor_obtaining_method: how the descriptor was obtained.
            gender: Gender. 0 - man, 1 - woman.
            gender_samples: list of warp image id from which the attribute was extracted.
            gender_obtaining_method: how the gender was obtained.
            age: age from 0 to 100.
            age_samples: list of warp image id from which the attribute was extracted.
            age_obtaining_method: how the age was obtained.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = {}
        if descriptor is not None:
            body['descriptor'] = descriptor
        if descriptor_samples is not None:
            body['descriptor_samples'] = descriptor_samples
        if descriptor_obtaining_method is not None:
            body['descriptor_obtaining_method'] = descriptor_obtaining_method
        if gender is not None:
            body['gender'] = gender
        if gender_samples is not None:
            body['gender_samples'] = gender_samples
        if gender_obtaining_method is not None:
            body['gender_obtaining_method'] = gender_obtaining_method
        if age is not None:
            body['age'] = age
        if age_samples is not None:
            body['age_samples'] = age_samples
        if age_obtaining_method is not None:
            body['age_obtaining_method'] = age_obtaining_method

        return makeRequest('{}/attributes/{}'.format(self.baseUri, attributesId), "PATCH", json=body,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.getRequestIdHeader(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteAttribute(self, attributesId: str, lunaRequestId: Optional[str] = None,
                        asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                        requestTimeout: int = None, connectTimeout: int = None
                        ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete attribute with specifeid id

        Args:
            attributesId: attribute id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/attributes/{}'.format(self.baseUri, attributesId), "DELETE",
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.getRequestIdHeader(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))
