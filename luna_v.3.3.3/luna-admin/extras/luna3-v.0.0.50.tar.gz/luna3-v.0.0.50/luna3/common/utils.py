import base64
import inspect


def isCoroutineFunction(func: callable) -> bool:
    """
    Check function is coroutine or not.
    Args:
        func: some func

    Returns:
        true if  func is coroutine otherwise false
    """
    return (getattr(func, '_is_coroutine', False) or
            inspect.iscoroutinefunction(func)) or getattr(func, '__tornado_coroutine__', False)


def createBasicAuth(login: str, password: str) -> dict:
    """
    The function generates an authorization header for LUNA API (by login and password).

    Args:
        login: login
        password: password
    Returns:
        return dict *{'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ=',
        'LUNA-Request-Id': 'RequestId'}*

    >>> createBasicAuth("hornsandhooves@ya.ru","secretpassword")
    {'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ='}
    """
    strAuth = login + ":" + password
    base64Auth = base64.b64encode(str.encode(strAuth)).decode("utf-8")
    headers = {'Authorization': 'Basic ' + base64Auth}
    return headers
