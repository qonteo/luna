import ujson as json
import chardet


class LunaResponse:
    """
    The container class for response from LUNA API
    Attributes:

        statusCode (int):      request's status code. Status code 599 means that request failed. Failure reasons are
                               connection refused, connection timeout, request timeout and others.
        body (bytes):          response body, None if body was empty.
        request (tornado `HTTPRequest`):         generating request
        contentType (str):     body content type.
        requestId (str):       External request id. Helps uniquely identifying messages, corresponding to particular
                                requests, in system logs.
        rawResponse (tornado.httpclient.HTTPResponse): raw tornado reply
    """

    def __init__(self, tornadoReply):
        self.rawResponse = tornadoReply
        self.statusCode = tornadoReply.code
        self.request = tornadoReply.request
        self.requestId = tornadoReply.request.headers.get('Luna-Request-Id')
        self.headers = tornadoReply.headers._dict
        if 'Luna-Request-Id' in tornadoReply.headers:
            self.requestId = tornadoReply.headers['Luna-Request-Id']
        if tornadoReply.code == 599:
            self.contentType = "application/json"
            if hasattr(tornadoReply.error, "errno"):
                self.body = json.dumps({"detail": tornadoReply.error.__class__.__name__,
                                        "desc": tornadoReply.error.errno,
                                        "error_code": 1})
            elif hasattr(tornadoReply.error, "message"):
                if tornadoReply.error.message == 'Timeout while connecting':
                    self.body = json.dumps(
                        {"detail": "Connect timeout to resource {}".format(tornadoReply.effective_url),
                         "desc": "Connect timeout",
                         "error_code": 2})
                elif tornadoReply.error.message == 'Timeout during request':
                    self.body = json.dumps(
                        {"detail": "Request timeout to resource {}".format(tornadoReply.effective_url),
                         "desc": "Request timeout",
                         "error_code": 3})
                else:
                    self.body = json.dumps({"detail": tornadoReply.error.__class__.__name__,
                                            "desc": tornadoReply.error.message,
                                            "error_code": 4})
            else:
                self.body = json.dumps({"detail": tornadoReply.error.__class__.__name__,
                                        "desc": "unknown tornado error",
                                        "error_code": 5})
        elif tornadoReply.code >= 400:
            self.contentType = tornadoReply.headers.get("Content-Type")
            self.body = tornadoReply.body
        elif tornadoReply.code == 204:
            self.contentType = ""
            self.body = None
        else:
            self.contentType = tornadoReply.headers.get("Content-Type")  # TODO: return __getitem__ when fix LUNA-954
            self.body = tornadoReply.body

    @property
    def json(self) -> dict:
        """
        Convert body to json (dict).

        :return: json
        """
        return json.loads(self.text)

    @property
    def text(self) -> str:
        """
        Convert body to string.

        Encoding will be guessed using ``chardet``.

        :return: decode body
        """
        if self.body is None:
            return ""
        if isinstance(self.body, str):
            return self.body
        encoding = chardet.detect(self.body)['encoding']
        # Decode unicode from given encoding.
        try:
            content = str(self.body, encoding, errors = 'replace')
        except (LookupError, TypeError):
            # A LookupError is raised if the encoding was not found which could
            # indicate a misspelling or similar mistake.
            #
            # A TypeError can be raised if encoding is None
            #
            # So we try blindly encoding.
            content = str(self.body, errors = 'replace')
        return content

    @property
    def success(self) -> bool:
        """
        Property for checking whther the reqiest was successful or not.

        :rtype: bool
        :return: True if statusCode < 400, else False
        """
        if self.statusCode < 400:
            return True
        return False
