from luna3.faces.faces import FacesApi
from luna3.image_store.image_store import StoreApi
from luna3.events.events import EventsApi
from luna3.core.core import CoreAPI
from luna3.index_manager.index_manager import IndexManagerApi
from typing import Optional


class Client:
    """
    Client for all services

    Attributes:
        lunaFaces (FacesApi): service luna-faces
        lunaImageStore (StoreApi): service luna-image-store
        lunaEvents (EventsApi): service luna-events
        lunaCore (CoreAPI): service luna-core
    """

    def __init__(self, lunaRequestId: str = None):
        """
        Init client for luna-services.

            lunaRequestId: request id
        """
        self.lunaFaces = FacesApi(lunaRequestId=lunaRequestId)
        self.lunaImageStore = StoreApi(lunaRequestId=lunaRequestId)
        self.lunaEvents = EventsApi(lunaRequestId=lunaRequestId)
        self.lunaCore = CoreAPI(lunaRequestId=lunaRequestId)
        self.lunaIndexManager = IndexManagerApi(lunaRequestId=lunaRequestId)

    def updateLunaFacesSettings(self, origin: Optional[str] = None, api: Optional[int] = None,
                                requestTimeout: Optional[int] = None, connectTimeout: Optional[int] = None,
                                asyncRequest: Optional[bool] = None) -> None:
        """
        Update settings of luna-faces

        Args:
            origin (str): host origin, "http://127.0.0.1:5030" for default
            api: api version of luna-faces, default 1
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.
            asyncRequest: default mode for request async or blocking
        """
        self.lunaFaces.updateSettings(origin=origin, api=api, asyncRequest=asyncRequest,
                                      requestTimeout=requestTimeout, connectTimeout=connectTimeout)

    def updateLunaImageStoreSettings(self, origin: Optional[str] = None, api: Optional[int] = None,
                                     requestTimeout: Optional[int] = None, connectTimeout: Optional[int] = None,
                                     asyncRequest: Optional[bool] = None) -> None:
        """
        Update settings of luna-faces

        Args:
            origin (str): host origin, "http://127.0.0.1:5020" for default
            api: api version of luna-faces, default 1
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.
            asyncRequest: default mode for request async or blocking
        """
        self.lunaImageStore.updateSettings(origin=origin, api=api, asyncRequest=asyncRequest,
                                           requestTimeout=requestTimeout, connectTimeout=connectTimeout)

    def updateLunaEventsSettings(self, origin: Optional[str] = None, api: Optional[int] = None,
                                 requestTimeout: Optional[int] = None, connectTimeout: Optional[int] = None,
                                 asyncRequest: Optional[bool] = None) -> None:
        """
        Update settings of luna-events

        Args:
            origin (str): host origin, "http://127.0.0.1:5040" for default
            api: api version of luna-events, default 1
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.
            asyncRequest: default mode for request async or blocking
        """
        self.lunaEvents.updateSettings(origin=origin, api=api, asyncRequest=asyncRequest,
                                       requestTimeout=requestTimeout, connectTimeout=connectTimeout)

    def updateLunaCoreSettings(self, origin: Optional[str] = None, api: Optional[int] = None,
                               requestTimeout: Optional[int] = None, connectTimeout: Optional[int] = None,
                               asyncRequest: Optional[bool] = None) -> None:
        """
        Update settings of luna-core

        Args:
            origin (str): host origin, "http://127.0.0.1:8083" for default
            api: api version of luna-core, default 13
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.
            asyncRequest: default mode for request async or blocking
        """
        self.lunaCore.updateSettings(origin=origin, api=api, asyncRequest=asyncRequest,
                                     requestTimeout=requestTimeout, connectTimeout=connectTimeout)

    def updateLunaIndexManagerSettings(self, origin: Optional[str] = None, api: Optional[int] = None,
                                       requestTimeout: Optional[int] = None, connectTimeout: Optional[int] = None,
                                       asyncRequest: Optional[bool] = None) -> None:
        """
        Update settings of luna-index-manager

        Args:
            origin (str): host origin, "http://127.0.0.1:5060" for default
            api: api version of luna-index-manager, default 1
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.
            asyncRequest: default mode for request async or blocking
        """
        self.lunaIndexManager.updateSettings(origin=origin, api=api, asyncRequest=asyncRequest,
                                             requestTimeout=requestTimeout, connectTimeout=connectTimeout)
