from luna3.common.base_api import BaseAPI
from luna3.common.requests import makeRequest
from luna3.common.luna_response import LunaResponse
from typing import Optional, Generator, Union, List


class IndexManagerApi(BaseAPI):
    """
    Class for request to luna-index-manager.

    Attributes:
        origin (str): luna-faces protocol, host and port; default "http://127.0.0.1:5060"
        api (int): api version of luna-index-manager, default 1
        asyncRequest (bool): default mode for request async or blocking
        lunaRequestId: Luna-Request-Id.
        requestTimeout: request processing timeout in seconds.
        connectTimeout: connection timeout in seconds.
    """

    def __init__(self, origin: Optional[str] = "http://127.0.0.1:5050", api: Optional[int] = 1,
                 asyncRequest: Optional[bool] = False, lunaRequestId: Optional[str] = None,
                 requestTimeout: int = 20, connectTimeout: int = 60):
        super().__init__(origin, api, asyncRequest, lunaRequestId, requestTimeout, connectTimeout)

    def getTasks(self, listIds: Optional[List[str]] = None, generations: Optional[List[str]] = None,
                 startTimeLt: Optional[str] = None, startTimeGte: Optional[str] = None,
                 status: Optional[int] = None, page: Optional[int] = 1, pageSize: Optional[int] = 10,
                 lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                 raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                 ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get indexer tasks.

        Args:
            listIds: list of luna lists
            generations: list of generations
            startTimeLt: upper bound of start task time excluding boundary
            startTimeGte: lower bound of start task time including boundary
            status: status of tsak, 0 - success done, 1 - failed, 2 - cancelled (not realize yet)
            page: pagination page
            pageSize: pagination page size
            lunaRequestId: Luna-Request-Id
            asyncRequest: mode for request async or blocking
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout in seconds.
        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with selected tasks "count" and "tasks" according to pagination
                will be returned.
        """
        queries = {"list_ids": listIds, "generations": generations, "start_time__lt": startTimeLt,
                   "start_time__gte": startTimeGte, "status": status, "page": page, "page_size": pageSize}
        return makeRequest(self.baseUri + '/indexes', 'GET', queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getQueue(self, page: Optional[int] = 1, pageSize: Optional[int] = 10,
                 lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                 raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                 ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get lists waiting for indexing.

        Args:
            page: pagination page
            pageSize: pagination page size
            lunaRequestId: Luna-Request-Id
            asyncRequest: mode for request async or blocking
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout in seconds.
        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json will be returned.
        """
        queries = {"page": page, "page_size": pageSize}
        return makeRequest(self.baseUri + '/queue', 'GET', queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def cleanQueue(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Clean the indexation queue.

        Args:
            lunaRequestId: Luna-Request-Id
            asyncRequest: mode for request async or blocking
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout in seconds.
        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"action": "clear"}
        return makeRequest(self.baseUri + '/queue', 'PATCH', queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def forwardListToQueue(self, listId: str,  lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                           raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                           ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Forward list to the head of the queue.

        Args:
            listId: list id from luna-faces. This list must satisfy criterion of indexation.
            lunaRequestId: Luna-Request-Id
            asyncRequest: mode for request async or blocking
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout in seconds.
        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        queries = {"action": "forward", "list_id": listId}
        return makeRequest(self.baseUri + '/queue', 'PATCH', queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getIndexedLists(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                        raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                        ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get lists, indexes of which have been uploaded into matches.

        Args:
            lunaRequestId: Luna-Request-Id
            asyncRequest: mode for request async or blocking
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout in seconds.
        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` json with [{"list_id": "", "generation": ""}] will be returned.
        """
        return makeRequest(self.baseUri + '/indexes/lists', 'GET', asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))
