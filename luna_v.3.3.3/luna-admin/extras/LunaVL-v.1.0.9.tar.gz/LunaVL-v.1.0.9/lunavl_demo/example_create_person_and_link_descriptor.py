from lunavl.httpclient import LunaHttpClient
from lunavl_demo.config import LUNA_API_LOGIN, LUNA_API_PASSWORD

lunaClient = LunaHttpClient(login = LUNA_API_LOGIN, password = LUNA_API_PASSWORD, endPoint = "http://127.0.0.1")


def extractDescriptorFromFile(filename):
    """
    The function extracts a descriptor from an image and returns descriptor id.

    Args:
        filename: path to file
    Returns:
         descriptor id
    """
    faces = lunaClient.extractDescriptors(filename = filename)
    return faces.body["faces"][0]["id"]


def createPersonWithDescriptor(filename):
    """
    The function creates a person, extracts a descriptor and links the descriptor to the person.

    Args:
        filename: path to file
    """
    person = lunaClient.createPerson("some person data")    #: create a person
    personId = person.body["person_id"]
    descriptorId = extractDescriptorFromFile(filename)      #: extract a descriptor
    lunaClient.linkDescriptorToPerson(personId, descriptorId, "attach")
    person = lunaClient.getPerson(personId)                 #: get person and descriptors, which are attached to the person
    print(person.body)

if __name__ == '__main__':
    createPersonWithDescriptor("./img_1.jpg")