"""Python http client for VisionLabs Luna."""
from tornado import escape

from lunavl.exceptions import ApiError
from lunavl.luna_api import *


def createAuthHeader(**kwargs) -> dict:
    if ("login" not in kwargs) or ("password" not in kwargs):
        raise AuthorizationError("Authorization data does not set", 1)
    login = kwargs["login"]
    password = kwargs["password"]
    strAuth = login + ":" + password
    base64Auth = base64.b64encode(str.encode(strAuth)).decode("utf-8")
    headers = {'Authorization': 'Basic ' + base64Auth}
    return headers


class LunaHttpClient:
    """
    Synchronous and  asynchronous HTTP-client for connecting to VisionLabs LUNA API.

    The :class:`~.LunaHttpClient` object holds information necessary to
    connect to LUNA API. Also, one can choose either a synchronous or asynchronous operation mode. Asynchronous requests
    to Luna API are realized using tornado-coroutine. In asynchronous mode one should run tornado ioloop. Every
    asynchronous request returns coroutine with :class:`~.LunaResponse`.

    For more information on requests and responses from LUNA API refer to the LUNA API documentation.

    Attributes:
        lunaHost:                    LUNA API service hostname ("http://127.0.0.1")
        lunaPort:                    LUNA API service listener port (5000)
        lunaApi:                     Luna API version (4)
        asyncRequest:                client operation mode, default (synchronous)
        login:                       account login
        password:                    account password
        token:                       account token

    One must set login/password or token for authorization in LUNA API service.

    **ATTENTION**:  some LUNA API methods support authorization by login/password only.

    """

    def __init__(self, api: Optional[int] = DEFAULT_API, endPoint: Optional[str] = "http://127.0.0.1", port: Optional[int] = 5000,
                 asyncRequest: Optional[bool] = False, **kwargs):

        self.lunaHost = endPoint
        self.lunaPort = str(port)
        self.lunaApi = api
        self.login = None
        self.password = None
        self.token = None
        self.asyncClient = asyncRequest

        if "login" in kwargs:
            self.login = kwargs["login"]
        if "password" in kwargs:
            self.password = kwargs["password"]
        if "token" in kwargs:
            self.token = kwargs["token"]

        if not self.checkAPIVersion():
            raise ApiError("Version  API of Luna API does not match", 10)

    def checkAPIVersion(self) -> bool:
        """
        Checks Luna API version.

        Returns:
            True if version was set correctly and False otherwise
        """

        reply = getVersion(self.lunaHost + ":" + str(self.lunaPort))
        if reply.statusCode == 599:
            raise LunaApiException("Failed connect to LUNA API", 100)
        elif reply.statusCode != 200:
            raise LunaApiException("Not expected code fom LUNA API", 101, escape.json_decode(reply.body))
        if self.lunaApi == 1:
            if reply.body["Version"]["api"] == self.lunaApi:
                return True
            return False
        else:
            if "luna_api" not in reply.body["Version"]:
                return False
            if reply.body["Version"]["luna_api"]["api"] == self.lunaApi:
                return True
            return False

    def getLunaUrl(self) -> str:
        """
        Luna API URL generation

        Returns:
            base part, for example: "http://127.0.0.1:5000/3"
        """
        return "{}:{}/{}".format(self.lunaHost, self.lunaPort, self.lunaApi)

    def getAccountData(self, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                       connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets account data: e-mail, organization name, and status (account is suspended or not).

        Args:
            raiseError: LunaApiException is raised if the request failed
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getAccountData(self.getLunaUrl(), raiseError, requestTimeOut=requestTimeOut,
                              connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                              asyncRequest=self.asyncClient, requestId=requestId)

    def getTokens(self, page: Optional[int] = 1, pageSize: Optional[int] = 100, raiseError: Optional[bool] = False,
                  requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                  requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets account tokens. Every token is represented by *id* and *token data*.

        Args:
            page: page number, positive
            pageSize: number of results per page, positive.
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getTokens(page, pageSize, self.getLunaUrl(), raiseError, requestTimeOut=requestTimeOut,
                         connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                         asyncRequest=self.asyncClient, requestId=requestId)

    def createToken(self, tokenData: Optional[str] = "", raiseError: Optional[bool] = False,
                    requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                    requestId: Optional[str] = None) -> LunaResponse:
        """
        The function creates a token with token data. Returns the new token *id*.

        Args:
            tokenData: user data for the token
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return createToken(tokenData, self.getLunaUrl(), raiseError, requestTimeOut=requestTimeOut,
                           connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                           asyncRequest=self.asyncClient, requestId=requestId)

    def deleteTokens(self, tokens: List[str], raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                     connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function removes tokens' list.

        Args:
            tokens: list of token ids.
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return deleteTokens(tokens, self.getLunaUrl(), raiseError, requestTimeOut=requestTimeOut,
                            connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                            asyncRequest=self.asyncClient, requestId=requestId)

    def getToken(self, tokenId: str, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                 connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets *token data* for a token, which corresponds to *tokenId*.

        Args:
            tokenId: token *id*
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getToken(tokenId, self.getLunaUrl(), raiseError, requestTimeOut=requestTimeOut,
                        connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                        asyncRequest=self.asyncClient, requestId=requestId)

    def patchTokenData(self, tokenId: str, tokenData: str, raiseError: Optional[bool] = False,
                       requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                       requestId: Optional[str] = None) -> LunaResponse:
        """
        The function patch token data to the token, which corresponds to *tokenId*.

        Args:
            tokenId: token *id*
            tokenData: user data for the token
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return patchTokenData(tokenId, tokenData, self.getLunaUrl(), raiseError, requestTimeOut=requestTimeOut,
                              connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                              asyncRequest=self.asyncClient, requestId=requestId)

    def deleteToken(self, tokenId: str, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                    connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function removes a token, which corresponds to *tokenId*.

        Args:
            tokenId: token *id*
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return deleteToken(tokenId, self.getLunaUrl(), raiseError, requestTimeOut=requestTimeOut,
                           connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                           asyncRequest=self.asyncClient, requestId=requestId)

    def getPersons(self, page: Optional[int] = 1, pageSize: Optional[int] = 10, raiseError: Optional[bool] = False,
                   requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                   requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets all persons of the account. Result is a list of persons and number of persons for the account.
        Each person is represented by *person_id*, *user_data*, *linked_descriptors*, linked_lists*.

        Args:
            page: page number, positive.
            pageSize: number of results per page, positive.
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getPersons(lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                          connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                          page=page, pageSize=pageSize, asyncRequest=self.asyncClient, requestId=requestId)

    def createPerson(self, userData: Optional[str] = "", raiseError: Optional[bool] = False,
                     requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                     requestId: Optional[str] = None) -> LunaResponse:
        """
        The function creates a person with user data. New person's *Id* is returned.

        Args:
            userData: user data for person
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return createPerson(lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                            connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                            userData=userData, asyncRequest=self.asyncClient, requestId=requestId)

    def getPerson(self, personId: str, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                  connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets a person, which corresponds to *personId*.

        Args:
            personId: person *id*
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getPerson(lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                         connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                         personId=personId, asyncRequest=self.asyncClient, requestId=requestId)

    def patchPerson(self, personId: str, userData: Optional[str] = None, externalId: Optional[str] = None,
                    raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                    connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function patches *user_data* to the person.

        Args:
            personId: person *id*
            userData: user data for the person | Attention: one of parameters - userData or externalId - is required
            externalId: external id of the person, if it has its own mapping in external system
                        Attention: one of parameters - userData or externalId - is required
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return patchPerson(lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                           connectTimeOut=connectTimeOut, login=self.login, asyncRequest=self.asyncClient,
                           password=self.password, token=self.token, personId=personId, userData=userData,
                           externalId=externalId, requestId=requestId)

    def deletePerson(self, personId: str, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                     connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function removes a person, which corresponds *personId*.

        Args:
            personId: person *id*
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return deletePerson(lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                            connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                            personId=personId, asyncRequest=self.asyncClient, requestId=requestId)

    def createList(self, listType: str, listData: Optional[str] = "", raiseError: Optional[bool] = False,
                   requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                   requestId: Optional[str] = None) -> LunaResponse:
        """
        The function creates a list with list data. New list's *Id* is returned.

        Args:
            listType: list's type ("persons" or "descriptors)
            listData: list data for the list
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return createList(listType, listData, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                          requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                          password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def getLists(self, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                 connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function get all lists for the account.

        Args:
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getLists(lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                        connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                        asyncRequest=self.asyncClient, requestId=requestId)

    def deleteLists(self, lists: List[str], raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                    connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function removes lists.

        Args:
            lists: list of list ids.
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return deleteLists(lists, lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                           connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                           asyncRequest=self.asyncClient, requestId=requestId)

    def getList(self, listId: str, page: Optional[int] = 1, pageSize: Optional[int] = 10,
                raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets objects in the list.

        Args:
            listId: list *id*
            page: page number, positive.
            pageSize: number of results per page, positive.
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getList(listId, page, pageSize, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                       requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                       password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def patchListData(self, listId: str, listData: str, raiseError: Optional[bool] = False,
                      requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                      requestId: Optional[str] = None) -> LunaResponse:
        """
        The function patches list data.

        Args:
            listId: list *id*
            listData: list data
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return patchListData(listId, listData, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                             requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                             password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def deleteList(self, listId: str, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                   connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function removes a list.

        Args:
            listId: list *id*
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return deleteList(listId, lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                          connectTimeOut=connectTimeOut, login=self.login, password=self.password, token=self.token,
                          asyncRequest=self.asyncClient, requestId=requestId)

    def link(self, listId: str, descriptorIds: Optional[List[str]] = None, personIds: Optional[List[str]] = None,
             action: Optional[str] = "attach",
             raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
             connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None
             ) -> LunaResponse:
        """
        Attach or detach descriptors or persons to list. Optional you can set, that list and descriptors must belong to
        account.

        Args:
            listId: list id
            action: attach or detach
            descriptorIds: descriptor ids
            personIds: person ids
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            raiseError: if request fails, LunaApiException is raised
            requestTimeOut: request processing timeout in seconds.
            connectTimeOut: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
        """
        return link(listId, descriptorIds, personIds, action, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                    requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                    password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def extractDescriptors(self, body: Optional[ByteString] = None, filename: Optional[str] = None,
                           contentType: Optional[str] = None, warpedImage: Optional[bool] = False,
                           estimateAttributes: Optional[bool] = False, estimateEmotions: Optional[bool] = False,
                           estimateEthnicities=False, estimateQuality: Optional[bool] = False,
                           scoreThreshold: Optional[float] = 0, extractDescriptor: Optional[bool] = True,
                           extractExif: Optional[bool] = False,
                           raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                           connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function extracts descriptors from an image. Image can be represented as raw bytes or a path to some folder.

        Args:
            body: image's bytes
            filename: path to the folder with the image
            contentType: image mime type
            warpedImage: Determines, whether an input image is a warped or an arbitrary one. Exact image warping
                algorithm is proprietary and this flag is intended for VisionLabs front-end tools only.

                The warped image has the following properties:

                * size is always 250x250 pixels;

                * color format is always RGB;

                * single face in a photo;

                * the face is always centered and rotated so that imaginary line between the eyes is
                horizontal.

            estimateAttributes: whether to estimate face attributes from the image or not(gender, age, glasses).
            estimateEmotions: Whether to estimate emotions from the image.
            estimateQuality: whether to estimate faces' suitability for recognition or not
            scoreThreshold: If estimate_quality parameter is set to 1, it is possible to apply a threshold check
                to each estimation. All face detections with quality below the threshold are
                ignored and no descriptors are extracted from them. The function proceeds as
                usual with all the remaining detections (if left).
            extractDescriptor: whether to extract face descriptor(s) or not.
            estimateEthnicities: whether to estimate ethnicities from the image.
            extractExif: Whether to extract EXIF meta information from the input image or not.

                Exact output varies since there are no mandatory data writing requirements both to the
                authoring software and digital cameras.

                This function parses only the tags and outputs their names and values as-is.
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """

        return extractDescriptors(body=body, filename=filename, contentType=contentType, warpedImage=warpedImage,
                                  estimateAttributes=estimateAttributes, estimateEmotions=estimateEmotions,
                                  estimateEthnicities=estimateEthnicities,
                                  estimateQuality=estimateQuality, scoreThreshold=scoreThreshold,
                                  extractDescriptor=extractDescriptor, extractExif=extractExif,
                                  lunaUrl=self.getLunaUrl(), raiseError=raiseError, requestTimeOut=requestTimeOut,
                                  connectTimeOut=connectTimeOut, login=self.login, password=self.password,
                                  token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def getDescriptors(self, page: Optional[int] = 1, pageSize: Optional[int] = 10, raiseError: Optional[bool] = False,
                       requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                       requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets accounts' descriptors. Result is a list of descriptors and number of descriptors
        for the account. Every descriptor is represented by *descriptor_id* and number of  *linked_lists*, the
        descriptor is attached to.

        Args:
            page: page number, positive.
            pageSize: number of results per page, positive.
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getDescriptors(page, pageSize, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                              requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                              password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def getDescriptor(self, descriptorId: str, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                      connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets the descriptor, which corresponds to *descriptorId*.

        Args:
            descriptorId: descriptor *id*
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getDescriptor(descriptorId, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                             requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                             password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def linkDescriptorToPerson(self, personId: str, descriptorId: str, action: Optional[str] = "attach",
                               raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                               connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function creates or deletes a link between a descriptor and a person.

        Args:
            personId: person id
            descriptorId: descriptor id
            action: "attach" or "detach"
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return linkDescriptorToPerson(personId, descriptorId, action, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                                      requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                                      password=self.password, token=self.token, asyncRequest=self.asyncClient,
                                      requestId=requestId)

    def getLinkedDescriptorToPerson(self, personId: str, raiseError: Optional[bool] = False,
                                    requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                                    requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets the list of descriptors, which are linked to a person.

        Args:
            personId: person id
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getLinkedDescriptorToPerson(personId, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                                           requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut,
                                           login=self.login, password=self.password, token=self.token,
                                           asyncRequest=self.asyncClient, requestId=requestId)

    def linkListToPerson(self, personId: str, listId: str, action: Optional[str] = "attach",
                         raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                         connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function creates or deletes a link between a list and a person.

        Args:
            personId:  person id
            listId: list id
            action: "attach" or "detach"
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return linkListToPerson(personId, listId, action, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                                requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                                password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def getLinkedListsToPerson(self, personId: str, raiseError: Optional[bool] = False,
                               requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                               requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets the list of lists, which are linked to a person.

        Args:
            personId: person id
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getLinkedListsToPerson(personId, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                                      requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                                      password=self.password, token=self.token, asyncRequest=self.asyncClient,
                                      requestId=requestId)

    def linkListToDescriptor(self, descriptorId, listId, action="attach", raiseError: Optional[bool] = False,
                             requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                             requestId: Optional[str] = None) -> LunaResponse:
        """
        The function creates or deletes a link between a list and a descriptor.

        Args:
            descriptorId: descriptor id
            listId: list id
            action: "attach" or "detach"
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return linkListToDescriptor(descriptorId, listId, action, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                                    requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                                    password=self.password, token=self.token, asyncRequest=self.asyncClient,
                                    requestId=requestId)

    def getLinkedListsToDescriptor(self, descriptorId: str, raiseError: Optional[bool] = False,
                                   requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                                   requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets the list of lists, the descriptor is linked to.

        Args:
            descriptorId: descriptor id
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getLinkedListsToDescriptor(descriptorId, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                                          requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut,
                                          login=self.login, password=self.password, token=self.token,
                                          asyncRequest=self.asyncClient, requestId=requestId)

    def getPortrait(self, descriptorId: str, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                    connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets the portrait, which corresponds to *descriptorId*.

        Args:
            descriptorId: descriptor *id*
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getPortrait(descriptorId, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                           requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                           password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def identify(self, personId: Optional[str] = None, descriptorId: Optional[str] = None, listId: Optional[str] = None,
                 personIds: List[str] = None, limit: Optional[int] = 3, raiseError: Optional[bool] = False,
                 requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
                 requestId: Optional[str] = None) -> LunaResponse:
        """
        The function matches a descriptor or person with a list of candidate persons.

        Either *descriptor_id* or *person_id* parameter should be specified as the reference and
        either *list_id* or *person_ids* parameter should be determined as the candidate.

        Args:
            personId: person id to take the reference descriptors from
            descriptorId: reference descriptor id.
            listId: candidate list id.
            personIds: list of candidate person ids
            limit: identify result limit
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return identify(personId, descriptorId, listId, personIds, limit, lunaUrl=self.getLunaUrl(),
                        raiseError=raiseError, requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut,
                        login=self.login, password=self.password, token=self.token, asyncRequest=self.asyncClient,
                        requestId=requestId)

    def match(self, personId: Optional[str] = None, descriptorId: Optional[str] = None,
              listId: Optional[str] = None, descriptorIds: List[str] = None, limit: Optional[int] = 3,
              raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
              connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function matches a descriptor or a person with a list of candidate descriptors.

        Either *descriptor_id* or *person_id* parameter should be specified as the reference and either *list_id* or
        *descriptor_ids* parameter should be determined as the candidate.

        Args:
            personId: person id to take the reference descriptors from
            descriptorId: reference descriptor id.
            listId: candidates list id.
            descriptorIds: list of candidate descriptor ids
            limit:
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return match(personId, descriptorId, listId, descriptorIds, limit, lunaUrl=self.getLunaUrl(),
                     raiseError=raiseError, requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut,
                     login=self.login, password=self.password, token=self.token, asyncRequest=self.asyncClient,
                     requestId=requestId)

    def verify(self, descriptorId: str, personId: str, raiseError: Optional[bool] = False,
               requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
               requestId: Optional[str] = None) -> LunaResponse:
        """
        The function matches a descriptor with candidate person descriptors.

        Args:
            descriptorId: the reference descriptor id.
            personId: the reference person id.
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return verify(descriptorId, personId, lunaUrl=self.getLunaUrl(), raiseError=raiseError,
                      requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, login=self.login,
                      password=self.password, token=self.token, asyncRequest=self.asyncClient, requestId=requestId)

    def search(self, body: Optional[ByteString] = None, filename: Optional[str] = None,
               contentType: Optional[str] = None, limit: Optional[int] = 3, warpedImage: Optional[bool] = False,
               estimateAttributes: Optional[bool] = False, estimateEthnicities: bool = False,
               estimateEmotions: bool = False, estimateQuality: Optional[bool] = False,
               scoreThreshold: Optional[float] = 0, extractExif: Optional[bool] = False, listId: Optional[str] = None,
               descriptorIds: List[str] = None, personIds: List[str] = None, raiseError: Optional[bool] = False,
               requestTimeOut: Optional[int] = 60, connectTimeOut: Optional[int] = 20,
               requestId: Optional[str] = None) -> LunaResponse:
        """
        The function extracts a descriptor from a photo, then matches it to a list of candidates.

        Either *list_id* or *person_ids* or *descriptor_ids* parameter should be specified as the candidate.

        Args:
            body: image bytes
            filename: path to folder with the image
            contentType: image mime type
            warpedImage: Determines, whether an input image is a warped or an arbitrary one. Exact image warping
                algorithm is proprietary and this flag is intended for VisionLabs front-end tools only.

                The warped image has the following properties:

                * size is always 250x250 pixels;

                * color format is always RGB;

                * single face in a photo;

                * the face is always centered and rotated so that imaginary line between the eyes is
                horizontal.
            estimateAttributes: whether to estimate face attributes for the image or not (gender, age, glasses).
            estimateEthnicities: whether to estimate ethnicities from the image.
            estimateEmotions: Whether to estimate emotions from the image.
            estimateQuality: estimate face suitability for recognition
            scoreThreshold: If estimate_quality parameter is set to 1, it is possible to apply a threshold check
                to each estimation. All face detections with the quality below the threshold are
                ignored and no descriptors are extracted from them. The function proceeds as
                usual with all the remaining detections (if left).
            extractExif: Whether to extract EXIF meta information from the input image or not.

                Exact output varies since there are no mandatory data writing requirements both to the
                authoring software and digital cameras.

                This function only parses the tags and outputs their names and values as-is.
            listId: candidates list id.
            descriptorIds: list of candidate descriptor ids
            personIds: list of candidate person ids
            limit: search result limit
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return search(body=body, filename=filename, contentType=contentType, warpedImage=warpedImage,
                      estimateAttributes=estimateAttributes, estimateQuality=estimateQuality,
                      estimateEmotions=estimateEmotions, estimateEthnicities=estimateEthnicities,
                      scoreThreshold=scoreThreshold, extractExif=extractExif, listId=listId,
                      descriptorIds=descriptorIds, personIds=personIds, limit=limit, lunaUrl=self.getLunaUrl(),
                      raiseError=raiseError, requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut,
                      login=self.login, password=self.password, token=self.token, asyncRequest=self.asyncClient,
                      requestId=requestId)

    def getVersion(self, raiseError: Optional[bool] = False, requestTimeOut: Optional[int] = 60,
                   connectTimeOut: Optional[int] = 20, requestId: Optional[str] = None) -> LunaResponse:
        """
        The function gets LUNA API version.

        Args:
            raiseError: LunaApiException is raised if the request failed.
            requestTimeOut: request processing timeout period (in seconds).
            connectTimeOut: connection timeout (in seconds).
            requestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs.
        Returns:
             structure, containing status code, request and LUNA API response decoded body.
        """
        return getVersion(self.lunaHost + ":" + str(self.lunaPort), raiseError=raiseError,
                          requestTimeOut=requestTimeOut, connectTimeOut=connectTimeOut, asyncRequest=self.asyncClient,
                          requestId=requestId)
