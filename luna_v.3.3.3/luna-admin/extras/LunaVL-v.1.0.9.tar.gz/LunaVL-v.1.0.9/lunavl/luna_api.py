from tornado import httpclient, gen
from tornado.httpclient import HTTPRequest

import base64
import json

from typing import Union, ByteString, Generator, List, Optional

from lunavl.exceptions import AuthorizationError, LunaApiException
from lunavl.luna_response import LunaResponse

import filetype

DEFAULT_API = 4


def processedTornadoReply(reply: LunaResponse, raiseError: bool) -> LunaResponse:
    """
    If *raiseError* is true and the request fails, an exception is thrown.

    Args:
        reply: response
        raiseError: bool
    Returns:
        row(tuple) if row exist else None
    Raises:
        LunaApiException if raiseError is True
    """
    if reply.success:
        return reply
    else:
        if raiseError:
            raise LunaApiException("Not expected code fom LUNA API", 101, reply)
        return reply


def createAuthHeaderFromLoginPassword(authData: dict) -> dict:
    """
    The function generates an authorization header for LUNA API by login and password.

    Args:
        authData: dictionary with login and password
    Returns:
        Basic Authorisation header dict

    >>> createAuthHeaderFromLoginPassword({"login": "hornsandhooves@ya.ru", "password" : "secretpassword"})
    {'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ='}
    """
    login = authData["login"]
    password = authData["password"]
    strAuth = login + ":" + password
    base64Auth = base64.b64encode(str.encode(strAuth)).decode("utf-8")
    headers = {'Authorization': 'Basic ' + base64Auth}
    return headers


def createAuthHeaderFromToken(authData: dict) -> dict:
    """
    The function generates authorization header for LUNA API by the token.

    Args:
        authData: dictionary with the token
    Returns:
        X-Auth-Token authorization header dict

    >>> createAuthHeaderFromToken({"token": "16fd2706-8baf-433b-82eb-8c7fada847da"})
    {'X-Auth-Token': "16fd2706-8baf-433b-82eb-8c7fada847da"}
    """
    return {'X-Auth-Token': authData["token"]}


def createAuthHeader(authData: dict) -> dict:
    """
    The function creates authorization header for LUNA API from the dictionary with authorization data. If authorization
    data is not found, :class:`~.AuthorizationError` is thrown.

    Args:
        authData: dict with keys "login" and "password" or "token".
    Returns:
         dictionary in format {'X-Auth-Token': "16fd2706-8baf-433b-82eb-8c7fada847da"} or
         {'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ='}

    >>> createAuthHeader({"login": "hornsandhooves@ya.ru", "password" : "secretpassword"})
    {'Authorization': 'Basic aG9ybnNhbmRob292ZXNAeWEucnU6c2VjcmV0cGFzc3dvcmQ='}

    >>> createAuthHeader({"login": "hornsandhooves@ya.ru", "token":
    ... "16fd2706-8baf-433b-82eb-8c7fada847da", "some_data" : "test"})
    {'X-Auth-Token': '16fd2706-8baf-433b-82eb-8c7fada847da'}

    >>> createAuthHeader({"login": "hornsandhooves@ya.ru"})
    Traceback (most recent call last):
        ...
    lunavl.exceptions.AuthorizationError: Authorization data does not set

    """
    if "token" in authData:
        if authData["token"] is not None:
            return createAuthHeaderFromToken(authData)
    if ("login" not in authData) or ("password" not in authData):
        raise AuthorizationError("Authorization data does not set", 1)
    if authData["login"] is not None and authData["password"] is not None:
        return createAuthHeaderFromLoginPassword(authData)
    raise AuthorizationError("Authorization data does not set", 1)


def createRequest(url: str, method: str, body: Optional[Union[str, ByteString]] = None,
                  queryParams: Optional[dict] = None, additionalHeaders: Optional[dict] = None,
                  **kwargs) -> HTTPRequest:
    """
    The function generates *tornado HTTPRequest*.

    Args:
        url: request URL
        method: request method
        body: request body
        queryParams: query parameters
        additionalHeaders: headers for request without an authorization header
        login (str): account's login for authorization
        password (str): account's password for authorization
        token (str): token id for authorization
        requestTimeOut (int): request processing timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout seconds (20 by default)
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        HTTP-request. The request can be used in method  *fetch*
    """
    headers = createAuthHeader(kwargs)
    if additionalHeaders is not None:
        headers.update(additionalHeaders)
    if "requestId" in kwargs and kwargs["requestId"] is not None:
        headers["LUNA-Request-Id"] = kwargs["requestId"]
    url += "?" + generateStringQueryParams(queryParams)
    requestParams = {}
    if "requestTimeOut" in kwargs:
        requestParams["request_timeout"] = kwargs["requestTimeOut"]
    if "connectTimeOut" in kwargs:
        requestParams["connect_timeout"] = kwargs["connectTimeOut"]
    request = HTTPRequest(url, method=method, body=body, headers=headers, allow_nonstandard_methods=True,
                          **requestParams)
    return request


def executeRequest(request: HTTPRequest, raiseError: bool) -> LunaResponse:
    """
    The function executes the request in the synchronous mode.

    If raiseError is True and response status code is different from 2xx, an exception is thrown.

    Args:
        request: prepared request to fetch
        raiseError: throw exception or not
    Returns:
        Luna API Answer
    """
    httpClient = httpclient.HTTPClient()
    reply = LunaResponse(httpClient.fetch(request, raise_error=False))
    return processedTornadoReply(reply, raiseError)


@gen.coroutine
def executeAsyncRequest(request: HTTPRequest, raiseError: bool) -> Generator:
    """
    The function executes the request in the asynchronous mode.

    If raiseError is True and response status code is different from 2xx, an exception is thrown.

    ** ATTENTION** This function works in tornado ioloop.

    Args:
        request: prepared request to fetch
        raiseError: throw exception or not
    Returns:
        Luna API Answer
    """
    httpClient = httpclient.AsyncHTTPClient()
    result = yield httpClient.fetch(request, raise_error=False)
    reply = LunaResponse(result)
    return processedTornadoReply(reply, raiseError)


def makeRequest(url: str, method: str, queryParams: Optional[dict] = None,
                body: Optional[Union[str, ByteString]] = None, raiseError: Optional[bool] = False,
                additionalHeaders: Optional[dict] = None, **kwargs) -> Union[LunaResponse, Generator]:
    """
    The function creates and fetches a request.

    Args:
        url: request URL
        method: request method
        body: request body
        queryParams: query parameters
        raiseError: if request fails, LunaApiException is raised
        additionalHeaders: headers for request without authorization header
        login (str): account's login for authorization
        password (str): account's password for authorization
        token (str): token id for authorization
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds (20 by default)
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    request = createRequest(url, method, body, queryParams, additionalHeaders, **kwargs)
    if "asyncRequest" in kwargs:
        if kwargs["asyncRequest"]:
            return executeAsyncRequest(request, raiseError)
    return executeRequest(request, raiseError)


def generateStringQueryParams(queryParams: Optional[dict] = None) -> str:
    """
    The function generates a string with the query parameters for the request to LUNA API

    Args:
        queryParams: dictionary with parameters
    Returns:
        query parameters string

    >>> generateStringQueryParams({"warped_image": 1, "estimate_attributes": 0})
    'warped_image=1&estimate_attributes=0'

    >>> generateStringQueryParams({"warped_image": 1, "parts": [0,1,2,5]})
    'warped_image=1&parts=0,1,2,5'

    >>> generateStringQueryParams()
    ''
    """
    queryStr = ""
    if queryParams is not None:
        for param in queryParams:
            if type(queryParams[param]) in [list, tuple]:
                queryStr += "&{}={}".format(param, ",".join(str(elem) for elem in queryParams[param]))
            else:
                queryStr += "&{}={}".format(param, queryParams[param])
        queryStr = queryStr[1:]
    return queryStr


def getAccountData(lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                   raiseError: Optional[bool] = False, **kwargs) \
        -> LunaResponse:
    """
    The function gets account's data: email, organization name and status (whether the account is suspended or not).

    Args:
        lunaUrl: base part of URL to Luna API with API version
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account".format(lunaUrl), "GET", raiseError=raiseError, **kwargs)


def getTokens(page: Optional[int] = 1, pageSize: Optional[int] = 10,
              lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
              raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets account's tokens. Every token is represented ин *id* and *token data*.

    Args:
        page: page number, positive
        pageSize: number of results per page, positive.
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens".format(lunaUrl), "GET", raiseError=raiseError,
                       queryParams={"page": page, "page_size": pageSize}, **kwargs)


def createToken(tokenData: Optional[str] = "", lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function creates a token with token data. New token's *id* is returned.

    Args:
        tokenData: token data for token
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
         structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens".format(lunaUrl), "POST", body=json.dumps({"token_data": tokenData}),
                       raiseError=raiseError, **kwargs)


def deleteTokens(tokens: List[str], lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                 raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function remove a tokens' list.

    Args:
        tokens: list of token ids.
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens".format(lunaUrl), "DELETE", body=json.dumps({"tokens": tokens}),
                       raiseError=raiseError, **kwargs)


def getToken(tokenId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
             raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets *token data* of a token, which corresponds to *tokenId*.

    Args:
        tokenId: token *id*
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens/{}".format(lunaUrl, tokenId), "GET", raiseError=raiseError, **kwargs)


def patchTokenData(tokenId: str, tokenData: str,
                   lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                   raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function patches a token data for the token, which corresponds to *tokenId*.

    Args:
        tokenId: token *id*
        tokenData: token data
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens/{}".format(lunaUrl, tokenId), "PATCH",
                       body=json.dumps({"token_data": tokenData}), raiseError=raiseError, **kwargs)


def deleteToken(tokenId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                raiseError: Optional[bool] = False,
                **kwargs) -> LunaResponse:
    """
    The function remove a token, which corresponds to *tokenId*.

    Args:
        tokenId: token *id*
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/account/tokens/{}".format(lunaUrl, tokenId), "DELETE", raiseError=raiseError, **kwargs)


def getPersons(page: Optional[int] = 1, pageSize: Optional[int] = 10, userData: Optional[str] = None,
               lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
               raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets all persons of the account. Result is a list of persons and number of persons for the account.
    Each person is represented by *person_id*, *user_data*, *linked_descriptors*, linked_lists*.

    Args:
        page: page number, positive.
        pageSize: number of results per page, positive.
        userData: user data or part of user data to search by it
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    query = {"page": page, "page_size": pageSize}
    if userData is not None:
        query["user_data"] = userData
    return makeRequest("{}/storage/persons".format(lunaUrl), "GET", raiseError=raiseError,
                       queryParams=query, **kwargs)


def createPerson(userData: Optional[str] = "", externalId: Optional[str] = None,
                 lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                 raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function creates a person with user data and/or external id. New person's *Id* is returned.

    Args:
        userData: user data for person
        externalId: external id of the person, if it has its own mapping in external system
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    body = {"user_data": userData}
    if externalId is not None:
        body['external_id'] = externalId
    return makeRequest("{}/storage/persons".format(lunaUrl), "POST", raiseError=raiseError,
                       body=json.dumps(body), **kwargs)


def getPerson(personId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
              raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets a person, which corresponds to *personId*.

    Args:
        personId: person *id*
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}".format(lunaUrl, personId), "GET", raiseError=raiseError, **kwargs)


def deletePerson(personId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                 raiseError: Optional[bool] = False,
                 **kwargs) -> LunaResponse:
    """
    The function removes a person, which corresponds *personId*.

    Args:
        personId: person *id*
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}".format(lunaUrl, personId), "DELETE", raiseError=raiseError, **kwargs)


def patchPerson(personId: str, userData: Optional[str] = None, externalId: Optional[str] = None,
                lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function patches *user_data* and/or external id to the person.

    Args:
        personId: person *id*
        userData: user data for person
        externalId: external id of the person, if it has its own mapping in external system
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    body = {"user_data": userData}
    if externalId is not None:
        body['external_id'] = externalId
    return makeRequest("{}/storage/persons/{}".format(lunaUrl, personId), "PATCH", raiseError=raiseError,
                       body=json.dumps(body), **kwargs)


def createList(listType: str, listData: Optional[str] = "",
               lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
               raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function creates a list with list data. New list's *Id* is returned.

    Args:
        listType: list's type ("persons" or "descriptors)
        listData: list data
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists".format(lunaUrl), "POST", queryParams={"type": listType},
                       raiseError=raiseError, body=json.dumps({"list_data": listData}), **kwargs)


def getLists(page: Optional[int] = 1, pageSize: Optional[int] = 100,
             lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
             raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function get all lists for the account.

    Args:
        page: page number, positive.
        pageSize: number of results per page, positive.
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists".format(lunaUrl), "GET", raiseError=raiseError,
                       queryParams={"page": page, "page_size": pageSize}, **kwargs)


def deleteLists(lists: List[str], lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function removes lists.

    Args:
        lists: list of list ids.
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists".format(lunaUrl), "DELETE", body=json.dumps({"lists": lists}),
                       raiseError=raiseError, **kwargs)


def getList(listId: str, page: Optional[int] = 1, pageSize: Optional[int] = 10,
            lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API), raiseError: Optional[bool] = False,
            **kwargs) -> LunaResponse:
    """
    The function gets objects in the list.

    Args:
        listId: list *id*
        page: page number, positive.
        pageSize: number of results per page, positive.
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists/{}".format(lunaUrl, listId), "GET", raiseError=raiseError,
                       queryParams={"page": page, "page_size": pageSize}, **kwargs)


def patchListData(listId: str, listData: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                  raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function patches list data.

    Args:
        listId: list *id*
        listData: list data
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists/{}".format(lunaUrl, listId), "PATCH", raiseError=raiseError,
                       body=json.dumps({"list_data": listData}), **kwargs)


def deleteList(listId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
               raiseError: Optional[bool] = False,
               **kwargs) -> LunaResponse:
    """
    The function removes a list.

    Args:
        listId: list *id*
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/lists/{}".format(lunaUrl, listId), "DELETE", raiseError=raiseError, **kwargs)


def link(listId: str, descriptorIds: Optional[List[str]] = None, personIds: Optional[List[str]] = None,
         action: Optional[str] = "attach",
         lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
         raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    Attach or detach descriptors or persons to list. Optional you can set, that list and descriptors must belong to
    account.

    Args:
        listId: list id
        action: attach or detach
        descriptorIds: descriptor ids
        personIds: person ids
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
    """
    payload = {"action": action, 'list_id': listId}

    if descriptorIds is not None:
        payload['descriptor_ids'] = descriptorIds
    else:
        payload['person_ids'] = personIds

    return makeRequest("{}/storage/linker".format(lunaUrl), "PATCH", raiseError=raiseError,
                       body=json.dumps(payload), **kwargs)


def extractDescriptors(body: Optional[ByteString] = None, filename: Optional[str] = None,
                       contentType: Optional[str] = None,
                       warpedImage: Optional[bool] = False, estimateAttributes: Optional[bool] = False,
                       estimateEmotions: Optional[bool] = False, estimateEthnicities: bool = False,
                       estimateQuality: Optional[bool] = False, scoreThreshold: Optional[float] = 0,
                       extractDescriptor: Optional[bool] = True,
                       extractExif: Optional[bool] = False,
                       lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                       raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    Extract descriptors from a image. Image can be represented as raw bytes or path to file.

    Args:
        body: image's bytes
        filename: path to the folder with the image
        contentType: image mime type, if contentType is not set, will try to determine it by ourselves
            raise ValueError if mimetype of content is not matches with acceptable formats
            (Available mimetypes are: image/jpeg, image/png, image/gif, image/bmp, image/tiff,
            application/x-vl-xpk, application/x-vl-face-descriptor, image/x-portable-pixmap)
        warpedImage: Determines, whether an input image is a warped or an arbitrary one. Exact image warping
            algorithm is proprietary and this flag is intended for VisionLabs front-end tools only.

            The warped image has the following properties:

            * size is always 250x250 pixels;

            * color format is always RGB;

            * single face in a photo;

            * the face is always centered and rotated so that imaginary line between the eyes is horizontal.
        estimateAttributes: whether to estimate face attributes from the image or not(gender, age, glasses).
        estimateEmotions: Whether to estimate emotions from the image.
        estimateEthnicities: Whether to estimate ethnicities from the image.
        estimateQuality: whether to estimate faces' suitability for recognition or not
        scoreThreshold: If estimate_quality parameter is set to 1, it is possible to apply a threshold check
             to each estimation. All face detections with quality below the threshold are
             ignored and no descriptors are extracted from them. The function proceeds as
             usual with all the remaining detections (if left).
        extractDescriptor: whether to extract face descriptor(s) or nor.
        extractExif: Whether to extract EXIF meta information from the input image or not.

            Exact output varies since there are no mandatory data writing requirements both to the authoring
            software and digital cameras.

            This function parses only the tags and outputs their names and values as-is.
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    if body is None and filename is None:
        raise ValueError

    if body is not None:
        body = body
    else:
        with open(filename, "rb") as f:
            body = f.read()

    if contentType is None:
        contentType = getContentType(body)

    queryParams = {"estimate_attributes": int(estimateAttributes),
                   "estimate_emotions": int(estimateEmotions),
                   "estimate_ethnicities": int(estimateEthnicities),
                   "estimate_quality": int(estimateQuality),
                   "extract_descriptor": int(extractDescriptor),
                   "warped_image": int(warpedImage),
                   "extract_exif": int(extractExif),
                   "score_threshold": scoreThreshold}

    return makeRequest("{}/storage/descriptors".format(lunaUrl), "POST", queryParams=queryParams, raiseError=raiseError,
                       additionalHeaders={"Content-Type": contentType}, body=body, **kwargs)


def getDescriptors(page: Optional[int] = 1, pageSize: Optional[int] = 10,
                   lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                   raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets accounts' descriptors. Result is a list of descriptors and number of descriptors
    for the account. Every descriptor is represented by *descriptor_id* and number of  *linked_lists*, the descriptor
    is attached to.

    Args:
        page: page number, positive.
        pageSize: number of results per page, positive.
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/descriptors".format(lunaUrl), "GET", raiseError=raiseError,
                       queryParams={"page": page, "page_size": pageSize}, **kwargs)


def getDescriptor(descriptorId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                  raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets the descriptor, which corresponds to *descriptorId*.

    Args:
        descriptorId: descriptor *id*
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/descriptors/{}".format(lunaUrl, descriptorId), "GET", raiseError=raiseError,
                       **kwargs)


def linkDescriptorToPerson(personId: str, descriptorId: str, action: str,
                           lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                           raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function creates or deletes a link between a descriptor and a person.

    Args:
        personId: person id
        descriptorId: descriptor id
        action: "attach" or "detach"
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}/linked_descriptors".format(lunaUrl, personId), "PATCH",
                       raiseError=raiseError, queryParams={"descriptor_id": descriptorId, "do": action}, **kwargs)


def getLinkedDescriptorToPerson(personId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                                raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets the list of descriptors, which are linked to a person.

    Args:
        personId: person id
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}/linked_descriptors".format(lunaUrl, personId), "GET",
                       raiseError=raiseError, **kwargs)


def linkListToPerson(personId: str, listId: str, action: str,
                     lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                     raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function creates or deletes a link between a list and a person.

    Args:
        personId: person id
        listId: list id
        action: "attach" or "detach"
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}/linked_lists".format(lunaUrl, personId), "PATCH",
                       raiseError=raiseError, queryParams={"list_id": listId, "do": action}, **kwargs)


def getLinkedListsToPerson(personId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                           raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets the list of lists, which are linked to a person.

    Args:
        personId: person id
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/persons/{}/linked_lists".format(lunaUrl, personId), "GET", raiseError=raiseError,
                       **kwargs)


def linkListToDescriptor(descriptorId: str, listId: str, action: str,
                         lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                         raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function creates or deletes a link between a list and a descriptor.

    Args:
        descriptorId: descriptor id
        listId:  list id
        action: "attach" or "detach"
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/descriptors/{}/linked_lists".format(lunaUrl, descriptorId), "PATCH",
                       raiseError=raiseError, queryParams={"list_id": listId, "do": action}, **kwargs)


def getLinkedListsToDescriptor(descriptorId: str,
                               lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                               raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets the list of lists, the descriptor is linked to.

    Args:
        descriptorId: descriptor id
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/descriptors/{}/linked_lists".format(lunaUrl, descriptorId), "GET",
                       raiseError=raiseError, **kwargs)


def getPortrait(descriptorId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
                raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets the portrait, which corresponds to *descriptorId*.

    Args:
        descriptorId: descriptor id
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    return makeRequest("{}/storage/portraits/{}".format(lunaUrl, descriptorId), "GET", raiseError=raiseError, **kwargs)


def setOneRequiredArgument(args: dict, t: dict) -> type(None):
    """
    Sets one default parameter to "args" from default "t".

    Args:
        args: arguments to set default argument in
        t: default arguments
    Returns:
        None
    Raises:
        ValueError if no default peremeters were set
    """
    for params in t:
        if t[params] is not None:
            args[params] = t[params]
            return
    raise ValueError


def identify(personId: Optional[str] = None, descriptorId: Optional[str] = None, listId: Optional[str] = None,
             personIds: List[str] = None,
             limit: Optional[int] = 3, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
             raiseError: Optional[bool] = False,
             **kwargs) -> LunaResponse:
    """
    The function matches a descriptor or person with a list of candidate persons.

    Either *descriptor_id* or *person_id* parameter should be specified as the reference and
    either *list_id* or *person_ids* parameter should be determined as the candidate.

    Args:
        personId: person id to take the reference descriptors from
        descriptorId: reference descriptor id.
        listId: candidate list id.
        personIds: list of candidate person ids
        limit: identify result limit
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    queryParams = {"limit": limit}
    setOneRequiredArgument(queryParams, {"person_id": personId, "descriptor_id": descriptorId})
    setOneRequiredArgument(queryParams, {"list_id": listId, "person_ids": personIds})
    return makeRequest("{}/matching/identify".format(lunaUrl), "POST", queryParams=queryParams, raiseError=raiseError,
                       **kwargs)


def match(personId: Optional[str] = None, descriptorId: Optional[str] = None, listId: Optional[str] = None,
          descriptorsIds: List[str] = None,
          limit: Optional[int] = 3, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
          raiseError: Optional[bool] = False,
          **kwargs) -> LunaResponse:
    """
    The function matches a descriptor or a person with a list of candidate descriptors.

    Either *descriptor_id* or *person_id* parameter should be specified as the reference and either *list_id* or
    *descriptor_ids*  parameter should be determined as the candidate.

    Args:
        personId: person id to take the reference descriptors from
        descriptorId: reference descriptor id.
        listId: candidate list id.
        descriptorsIds: list of candidate descriptor ids
        limit:
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    queryParams = {"limit": limit}
    setOneRequiredArgument(queryParams, {"person_id": personId, "descriptor_id": descriptorId})
    setOneRequiredArgument(queryParams, {"list_id": listId, "descriptor_ids": descriptorsIds})

    return makeRequest("{}/matching/match".format(lunaUrl), "POST", queryParams=queryParams, raiseError=raiseError,
                       **kwargs)


def verify(descriptorId: str, personId: str, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
           raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function matches a descriptor with candidate person descriptors.

    Args:
        descriptorId: reference descriptor id.
        personId: reference person id.
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    queryParams = {"person_id": personId, "descriptor_id": descriptorId}
    return makeRequest("{}/matching/verify".format(lunaUrl), "POST", queryParams=queryParams, raiseError=raiseError,
                       **kwargs)


def search(body: Optional[ByteString] = None, filename: Optional[str] = None, contentType: Optional[str] = None,
           limit: Optional[int] = 3,
           warpedImage: Optional[bool] = False, estimateAttributes: Optional[bool] = False,
           estimateEthnicities: bool = False, estimateEmotions: bool = False,
           estimateQuality: Optional[bool] = False,
           scoreThreshold: Optional[float] = 0, extractExif: Optional[bool] = False, listId: Optional[str] = None,
           descriptorIds: List[str] = None,
           personIds: List[str] = None, lunaUrl: Optional[str] = "http://127.0.0.1:5000/{}".format(DEFAULT_API),
           raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function extracts a descriptor from a photo, then matches it to a list of candidates.

    Either *list_id* or *person_ids* or *descriptor_ids* parameter should be specified as the candidate.

    Args:
        body: image bytes
        filename: path to folder with the image
        contentType: image mime type, if contentType is not set, will try to determine it by ourselves
            raise ValueError if mimetype of content is not matches with acceptable formats
            (Available mimetypes are: image/jpeg, image/png, image/gif, image/bmp, image/tiff,
            application/x-vl-xpk, application/x-vl-face-descriptor, image/x-portable-pixmap)
        warpedImage: Determines, whether an input image is a warped or an arbitrary one. Exact image warping
            algorithm is proprietary and this flag is intended for VisionLabs front-end tools only.

            The warped image has the following properties:

            * size is always 250x250 pixels;

            * color format is always RGB;

            * single face in a photo;

            * the face is always centered and rotated so that imaginary line between the eyes is horizontal.
        estimateAttributes: whether to estimate face attributes for the image or not (gender, age, glasses).
        estimateEthnicities: whether to estimate ethnicities from the image.
        estimateEmotions: Whether to estimate emotions from the image.
        estimateQuality: estimate face suitability for recognition
        scoreThreshold: If estimate_quality parameter is set to 1, it is possible to apply a threshold check
            to each estimation. All face detections with the quality below the threshold are
            ignored and no descriptors are extracted from them. The function proceeds as
            usual with all the remaining detections (if left).
        extractExif: Whether to extract EXIF meta information from the input image or not.

            Exact output varies since there are no mandatory data writing requirements both to the authoring
            software and digital cameras.

            This function only parses the tags and outputs their names and values as-is.
        listId: candidate list id.
        descriptorIds: list of candidate descriptor ids
        personIds: list of candidate person ids
        limit: search result limit
        lunaUrl: base part of URL to Luna API with API version.
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        login (str): account's login for authorization
        password (str): account's password for authorization
        asyncRequest (bool): execution in asynchronous mode, disabled by default
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    if body is None and filename is None:
        raise ValueError

    if body is not None:
        body = body
    else:
        with open(filename, "rb") as f:
            body = f.read()

    if contentType is None:
        contentType = getContentType(body)

    queryParams = {"estimate_attributes": int(estimateAttributes),
                   "estimate_quality": int(estimateQuality),
                   "warped_image": int(warpedImage),
                   "extract_exif": int(extractExif),
                   "limit": limit,
                   "estimate_emotions": int(estimateEmotions),
                   "estimate_ethnicities": int(estimateEthnicities),
                   "score_threshold": scoreThreshold}

    setOneRequiredArgument(queryParams, {"list_id": listId, "person_ids": personIds, "descriptor_ids": descriptorIds})
    return makeRequest("{}/matching/search".format(lunaUrl), "POST", queryParams=queryParams,
                       raiseError=raiseError, additionalHeaders={"Content-Type": contentType}, body=body, **kwargs)


def getVersion(url: str, raiseError: Optional[bool] = False, **kwargs) -> LunaResponse:
    """
    The function gets LUNA API version.

    Args:
        url: base LUNA API url
        raiseError: if request fails, LunaApiException is raised
        requestTimeOut (int): request's processing  timeout in seconds (20 by default)
        connectTimeOut (int): connection timeout in seconds.
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    requestParams = {}
    if "requestTimeOut" in kwargs:
        requestParams["request_timeout"] = kwargs["requestTimeOut"]
    if "connectTimeOut" in kwargs:
        requestParams["connect_timeout"] = kwargs["connectTimeOut"]
    if "requestId" in kwargs and kwargs["requestId"] is not None:
        requestParams["headers"] = {"LUNA-Request-Id": kwargs["requestId"]}
    request = HTTPRequest(url + "/version", method="GET", **requestParams)

    return executeRequest(request, raiseError=raiseError)


def getContentType(body: ByteString) -> str:
    """"
    The function gets mimetype of body

    Available mimetypes are: image/jpeg, image/png, image/gif, image/bmp, image/tiff, application/x-vl-xpk,
        application/x-vl-face-descriptor, image/x-portable-pixmap

    Args:
        body: image's bytes
    Returns:
        Content-type of body.
    Raises:
        ValueError if body has unsupported mimetype
    """

    contentType = filetype.guess(body)
    if contentType is not None:
        if contentType.mime in ('image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/tiff'):
            return contentType.mime
    else:
        if body[:4] == b'XPKF':
            return 'application/x-vl-xpk'
        elif body[:2] == b'dp':
            return 'application/x-vl-face-descriptor'
        elif body[:2] in (b'P6', b'P3'):
            return 'image/x-portable-pixmap'
    raise ValueError("wrong mimetype, availbale mimetypes are: image/jpeg, image/png, image/gif, image/bmp, "
                     "image/tiff, application/x-vl-xpk, application/x-vl-face-descriptor")
