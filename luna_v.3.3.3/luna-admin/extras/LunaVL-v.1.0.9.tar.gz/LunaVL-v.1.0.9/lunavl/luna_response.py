from tornado import escape


class LunaResponse:
    """
    The container class for response from LUNA API

    Attributes:
        statusCode (int): request's status code. Status code 599 means that request failed. Failure reasons are
            connection refused, connection timeout, request timeout and others.
        body (dict): response body, None if body was empty. If json is returned, response body is dict; if image is
            returned, response body is bytes; else response body is a string.
        request (tornado.HTTPRequest): generated request
        contentType (str): body content type.
        requestId (str): External request id. Helps uniquely identifying messages, corresponding to particular
            requests, in system logs.
    """
    def __init__(self, tornadoReply):
        self.statusCode = tornadoReply.code
        self.request = tornadoReply.request
        self.requestId = None
        if 'Luna-Request-Id' in self.request.headers:
            self.requestId = self.request.headers['Luna-Request-Id']
        if tornadoReply.code == 599:
            self.contentType = "application/json"
            if hasattr(tornadoReply.error, "errno"):
                self.body = {"detail": tornadoReply.error.__class__.__name__,
                             "error_code": tornadoReply.error.errno}
            elif hasattr(tornadoReply.error, "message"):
                self.body = {"detail": tornadoReply.error.__class__.__name__,
                             "error_code": tornadoReply.error.message}
            else:
                self.body = {"detail": tornadoReply.error.__class__.__name__,
                             "error_code": "unknown tornado error"}
        elif tornadoReply.code >= 400:
            self.contentType = "application/json"
            self.body = escape.json_decode(tornadoReply.body)
            return
        elif tornadoReply.code == 204:
            self.contentType = ""
            self.body = None
        else:
            self.contentType = tornadoReply.headers["Content-Type"]
            if self.contentType == "application/json":
                self.body = escape.json_decode(tornadoReply.body)
            elif self.contentType == "image/jpeg":
                self.body = tornadoReply.body
            else:
                self.body = tornadoReply.body.decode("utf-8")

    def __repr__(self):
        return '<LunaResponse> {}: {}'.format(self.statusCode, self.body)

    @property
    def success(self) -> bool:
        """
        Property to check whether the request was successful or not.

        Returns:
            True if statusCode < 400, else False
        """
        if self.statusCode < 400:
            return True
        return False
