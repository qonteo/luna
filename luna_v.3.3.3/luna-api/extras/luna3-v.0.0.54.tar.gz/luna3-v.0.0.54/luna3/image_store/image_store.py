from luna3.common.base_api import BaseAPI
from luna3.common.requests import makeRequest
from luna3.common.luna_response import LunaResponse
from typing import Optional, Generator, Union, List


class StoreApi(BaseAPI):
    """
    Class for request to luna-image-store.

    Attributes:
        origin (str): luna-faces protocol, host and port; default "http://127.0.0.1:5020"
        api (int): api version of luna-image-store, default 1
        asyncRequest (bool): default mode for request async or blocking
        lunaRequestId: Luna-Request-Id.
        requestTimeout: request processing timeout in seconds.
        connectTimeout: connection timeout seconds.
    """

    def __init__(self, origin: Optional[str] = "http://127.0.0.1:5020", api: Optional[int] = 1,
                 asyncRequest: Optional[bool] = False, lunaRequestId: Optional[str] = None,
                 requestTimeout: int = 20, connectTimeout: int = 60):
        super().__init__(origin, api, asyncRequest, lunaRequestId, requestTimeout, connectTimeout)

    def createBucket(self, bucketName: Optional[str] = '', lunaRequestId: Optional[str] = None,
                     asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                     requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create bucket with bucketName.

        Args:
            bucketName: bucket's name
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"bucket": bucketName}
        return makeRequest(self.baseUri + '/buckets', 'POST', queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getBuckets(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get buckets with lunaRequestId.

        Args:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest(self.baseUri + '/buckets', 'GET', headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def postImage(self, imageInBytes: bytearray, bucketName: str, contentType: Optional[str] = "image/jpeg",
                  createThumbnails: Optional[int] = 0, lunaRequestId: Optional[str] = None,
                  asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                  requestTimeout: int = None, connectTimeout: int = None
                  ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Post an image to bucket.

        Args:
            imageInBytes: byte's array (image)
            bucketName: bucket's name
            contentType: content-type of image or image/jpeg for default
            createThumbnails: thumbnails creation's flag
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"thumbnails": createThumbnails}
        headers = {"Content-Type": contentType, **self.getRequestIdHeader(lunaRequestId)}
        return makeRequest('{}/buckets/{}/images'.format(self.baseUri, bucketName), 'POST', queryParams=queries,
                           headers=headers, body=imageInBytes, asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteBucket(self, bucketName: str, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                     raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete bucket with bucketName.

        Args:
            bucketName: bucket's name
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            In body of :class:`~.LunaResponse` will be None.
        """
        queries = {"bucket": bucketName}
        return makeRequest('{}/buckets/{}'.format(self.baseUri, bucketName), 'DELETE', queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.getRequestIdHeader(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def putImage(self, imageInBytes, imageId, bucketName, contentType: Optional[str] = "image/jpeg",
                 createThumbnails: Optional[int] = 0, lunaRequestId: Optional[str] = None,
                 asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                 requestTimeout: int = None, connectTimeout: int = None
                 ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Put an image to bucket.

        Args:
            imageInBytes: byte's array (image)
            imageId: image id
            bucketName: bucket's name
            contentType: content-type of image or image/jpeg for default
            createThumbnails: thumbnails creation's flag
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {"thumbnails": createThumbnails}
        headers = {"Content-Type": contentType, **self.getRequestIdHeader(lunaRequestId)}
        return makeRequest('{}/buckets/{}/images/{}'.format(self.baseUri, bucketName, imageId), 'PUT',
                           queryParams=queries, headers=headers, body=imageInBytes,
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getImage(self, bucketName: str, imageId: str, lunaRequestId: Optional[str] = None,
                 asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                 requestTimeout: int = None, connectTimeout: int = None
                 ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get image from bucket.

        Args:
            bucketName: bucket's name
            imageId: external image id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/images/{}'.format(self.baseUri, bucketName, imageId), 'GET',
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def checkImage(self, bucketName: str, imageId: str, lunaRequestId: Optional[str] = None,
                   asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                   requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Check image existence in bucket.

        Args:
            bucketName: bucket's name
            imageId: external image id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/images/{}'.format(self.baseUri, bucketName, imageId), 'HEAD',
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteImage(self, bucketName: str, imageId: str, lunaRequestId: Optional[str] = None,
                    asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                    requestTimeout: int = None, connectTimeout: int = None
                    ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete image from bucket.

        Args:
            bucketName: bucket's name
            imageId: image id to delete
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/images/{}'.format(self.baseUri, bucketName, imageId), 'DELETE',
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteImages(self, bucketName: str, imageIds: List[str], lunaRequestId: Optional[str] = None,
                     asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                     requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete images from bucket.

        Args:
            bucketName: bucket's name
            imageIds: images ids to delete
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/images'.format(self.baseUri, bucketName), 'DELETE', json={'images': imageIds},
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def postObject(self, objectBody: str, bucketName: str, contentType: Optional[str] = "application/json",
                   lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Post object to bucket.

        Args:
            objectBody: object, available: text, json
            bucketName: bucket's name
            contentType: content-type of object or application/json for default
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = {"Content-Type": contentType, **self.getRequestIdHeader(lunaRequestId)}
        return makeRequest('{}/buckets/{}/objects'.format(self.baseUri, bucketName), 'POST', headers=headers,
                           body=objectBody, asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def putObject(self, objectBody: str, objectId: str, bucketName: str,
                  contentType: Optional[str] = "application/json", lunaRequestId: Optional[str] = None,
                  asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                  requestTimeout: int = None, connectTimeout: int = None
                  ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Put object to bucket.

        Args:
            objectBody: object, available: text, json
            objectId: object id
            bucketName: bucket's name
            contentType: content-type of object or application/json for default
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = {"Content-Type": contentType, **self.getRequestIdHeader(lunaRequestId)}
        return makeRequest('{}/buckets/{}/objects/{}'.format(self.baseUri, bucketName, objectId), 'PUT',
                           headers=headers, body=objectBody, asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getObject(self, bucketName: str, objectId: str, acceptType: Optional[str] = None,
                  lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                  raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                  ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get object from bucket.

        Args:
            bucketName: bucket's name
            objectId: object id
            acceptType: acceptable content-type of response body
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = self.getRequestIdHeader(lunaRequestId)
        if acceptType is not None:
            headers.update({"Accept": acceptType})
        return makeRequest('{}/buckets/{}/objects/{}'.format(self.baseUri, bucketName, objectId), 'GET',
                           headers=headers, asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def checkObject(self, bucketName: str, objectId: str, acceptType: Optional[str] = None,
                    lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                    raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                    ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Check object existence in bucket.

        Args:
            bucketName: bucket's name
            objectId: object id
            acceptType: acceptable content-type of response body
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        headers = self.getRequestIdHeader(lunaRequestId)
        if acceptType is not None:
            headers.update({"Accept": acceptType})
        return makeRequest('{}/buckets/{}/objects/{}'.format(self.baseUri, bucketName, objectId), 'HEAD',
                           headers=headers, asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteObject(self, bucketName: str, objectId: str, lunaRequestId: Optional[str] = None,
                     asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                     requestTimeout: int = None, connectTimeout: int = None
                     ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete object from bucket.

        Args:
            bucketName: bucket's name
            objectId: object id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/objects/{}'.format(self.baseUri, bucketName, objectId), 'DELETE',
                           headers=self.getRequestIdHeader(lunaRequestId), asyncRequest=self.getAsyncMode(asyncRequest),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def deleteObjects(self, bucketName: str, objectIds: List[str], lunaRequestId: Optional[str] = None,
                      asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                      requestTimeout: int = None, connectTimeout: int = None
                      ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Delete objects from bucket.

        Args:
            bucketName: bucket's name
            objectIds: objects ids to delete
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/buckets/{}/objects'.format(self.baseUri, bucketName), 'DELETE',
                           json={'objects': objectIds}, headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))
