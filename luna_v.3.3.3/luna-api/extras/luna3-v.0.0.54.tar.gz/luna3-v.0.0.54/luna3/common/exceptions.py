import ujson as json


class AuthorizationError(Exception):

    def __init__(self, message, errorCode):
        super(AuthorizationError, self).__init__(message)
        self.errorCode = errorCode


class ApiError(Exception):

    def __init__(self, message, errorCode):
        super(ApiError, self).__init__(message)
        self.errorCode = errorCode


class LunaApiException(Exception):

    def __init__(self, message, response, lunaAPIError = None):
        super(LunaApiException, self).__init__(message)
        self.error = lunaAPIError
        self.statusCode = response.statusCode
        self.body = response.body
        self.request = response.request

    @property
    def json(self):
        return json.loads(self.body)