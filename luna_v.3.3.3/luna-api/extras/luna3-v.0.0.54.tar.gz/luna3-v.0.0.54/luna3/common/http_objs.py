from typing import Union

import filetype


class Image:
    """Image obj

        Args:
            filename: filename. may be path to the image.
            name: name of image.
            mimetype: property. image mimetype. Can be autodetected from body.
            _mimetype: privat store mimetype
            body: property. binary representation of image. Can be uploaded by filename path.
            _body: privat store body bytes
            multipartHeaders: Custom headers for multipart body
            lunaOutputDescriptorID: Optional header to specify descriptor id to be used for DB storage
                        instead of auto-generated one.
                        This header may also be specified on per-part basis when posting multipart/form-data requests.
                        Only supported with warped images. Pattern:
                        ^[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}$
        """
    def __init__(self, filename: str, name: str = None, mimetype: str = None, body: bytes = None,
                 multipartHeaders: dict = None, lunaOutputDescriptorID: str = None) -> None:
        self.filename = filename
        self.name = name
        self._body = body
        self._mimetype = mimetype

        if multipartHeaders is None:
            self.multipartHeaders = {}
        else:
            self.multipartHeaders = multipartHeaders

        if lunaOutputDescriptorID is not None:
            self.multipartHeaders['LUNA-Output-Descriptor-ID'] = lunaOutputDescriptorID

    @property
    def body(self) -> bytes:
        """
        Lazy body. If not set, upload by filename path.
        :return: body
        """
        if self._body is not None:
            return self._body
        else:
            with open(self.filename, 'rb') as f:
                self._body = f.read()
            return self._body

    @body.setter
    def body(self, body: bytes):
        """
        Set body
        :param body: binary representation of image
        """
        self._body = body

    @property
    def mimetype(self):
        """
        Lazy mimetype. If not set, executed from body.
        :return: mimetype
        """
        if self._mimetype is not None:
            return self._mimetype
        else:
            self._mimetype = self.getMimetype(self.body)
            return self._mimetype

    @mimetype.setter
    def mimetype(self, mimetype: str):
        """
        Set mimetype

        :param mimetype: image mimetype
        """
        self._mimetype = mimetype

    @property
    def multipartContentDisposition(self) -> str:
        """
        generate ContentDisposition for multipart body

        :return: Content-Disposition
        """
        if self.name is not None:
            name = ' name="%s";' % self.name
        else:
            name = ''
        return 'Content-Disposition: form-data;%s filename="%s"' % (name, self.filename)

    @staticmethod
    def getMimetype(body) -> str:
        """"
        The function gets mimetype of body
        Available mimetypes are: image/jpeg, image/png, image/gif, image/bmp, image/tiff, image/x-portable-pixmap

        :param body: image's bytes
        :type body: bytes

        :raise Exception: ValueError if body has wrong mimetype

        :rtype: String
        :return: Content-type of body.
        """

        contentType = filetype.guess(body)
        if contentType is not None:
            if contentType.mime in ('image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/tiff'):
                return contentType.mime
        else:
            if body[:2] in (b'P6', b'P3'):
                return 'image/x-portable-pixmap'
        raise ValueError("wrong mimetype, availbale mimetypes are: image/jpeg, image/png, image/gif, image/bmp, "
                         "image/tiff, image/x-portable-pixmap")


class StatQuery:
    """
    Object for easy create query to event servise for statistic
    """
    def __init__(self):
        self.query = {}

    def addTarget(self, column: str, aggregator: str = 'count') -> 'StatQuery':
        """
        Add target query field

        Args:
            column: column for select (descriptor_id, source, gender, age, head_angle,
                emotion, race, top_similar_face_id, top_similar_face_list,
                account_id, event_id, source, face_id)
            aggregator: aggregation function (count, max, min, avg, group_by)

        Returns:
            self
        """
        new = {'column': column, 'aggregator': aggregator}

        if self.query.get('targets'):
            self.query['targets'].append(new)
        else:
            self.query['targets'] = [new]
        return self

    def addFilter(self, column: str, operator: str, value: Union[str, list, float, int]) -> 'StatQuery':
        """
        Add filter query field

        For column 'tags' work only operator 'like/nlike' on each tag.

        Args:
            column: column for filter (account_id, event_id, descriptor_id, attributes_id, source,
                            top_similar_face_id, top_similar_face_list, top_similar_face_sim,
                            face_id, gender, age, head_angle, emotion, race, tags, user_data)
            operator:  filter operation (eq, neq, in, nin, like, nlike, gt, gte, lt, lte).
                            For tags must be like/nlike only.
            value: filter value

        Returns:
            self
        """
        new = {'column': column, 'operator': operator, 'value': value}

        if self.query.get('filters'):
            self.query['filters'].append(new)
        else:
            self.query['filters'] = [new]
        return self

    def addPeriod(self, operator: str, value: str) -> 'StatQuery':
        """
        Add period query field

        Args:
            operator: period operation (gt, gte, lt, lte)
            value: value for operation (time in ISO or now-time format)

        Returns:
            self
        """
        new = {'operator': operator, 'value': value}

        if self.query.get('period'):
            self.query['period'].append(new)
        else:
            self.query['period'] = [new]
        return self

    def addGroupBy(self, group_by: str) -> 'StatQuery':
        """
        Add group by query field

        Args:
            group_by: events histogram "group by" time clause in frequency grouping: minuteOfHour, hourOfDay,
                dayOfWeek, dayOfMonth, dayOfYear, weekOfYear, monthOfYear
                or periodic grouping (y|M|w|d|h|m|s)+int

        Returns:
            self
        """
        self.query['group_by'] = group_by
        return self
