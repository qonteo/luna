from typing import List, Generator

from tornado import gen

from .http_objs import Image


@gen.coroutine
def asyncMultipartProducer(multipartBoundary: str, images: List[Image], write,
                           bufferSize: int = 16 * 1024) -> Generator:
    """
    Tornado producer what async send valid multipart body

    :param multipartBoundary: boundary for multipart
    :param images: list of images
    :param write: tornado write function
    :param bufferSize: read bytes per iteration
    :return: *tornado coroutine*
    """
    for image in images:

        headers = image.multipartHeaders or {}
        headers = ''.join('{}: {}\r\n'.format(k, v) for k, v in headers.items())

        buf = (
                '--{}\r\n'.format(multipartBoundary).encode() +
                '{}\r\n'.format(image.multipartContentDisposition).encode() +
                'Content-Type: {}\r\n{}'.format(image.mimetype, headers).encode() +
                b'\r\n'
        )
        yield write(buf)

        for i in range((len(image.body) + bufferSize - 1) // (bufferSize)):
            # 16k at a time.

            chunk = image.body[i * bufferSize: (i + 1) * bufferSize]
            if not chunk:
                break
            yield write(chunk)

        yield write(b'\r\n')

    yield write('--{}--\r\n'.format(multipartBoundary).encode())


def createMultipart(multipartBoundary: str, images: List[Image]) -> bytes:
    """
    Return valid multipart body

    :param multipartBoundary: boundary for multipart
    :param images: list of images
    :return: multipart body
    """
    msgBody = b''
    for image in images:

        headers = image.multipartHeaders or {}
        headers = ''.join('{}: {}\r\n'.format(k, v) for k, v in headers.items())

        buf = (
                '--{}\r\n'.format(multipartBoundary).encode() +
                '{}\r\n'.format(image.multipartContentDisposition).encode() +
                'Content-Type: {}\r\n{}'.format(image.mimetype, headers).encode() +
                b'\r\n' +
                image.body + b'\r\n'
        )
        msgBody += buf

    msgBody += '--{}--\r\n'.format(multipartBoundary).encode()

    return msgBody
