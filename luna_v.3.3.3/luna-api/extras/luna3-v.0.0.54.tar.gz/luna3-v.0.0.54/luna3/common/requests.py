from tornado import httpclient, gen, escape
from tornado.httpclient import HTTPRequest
from typing import Optional, Union, Generator
import ujson

from .luna_response import LunaResponse
from .exceptions import LunaApiException


def generateStringQueryParams(queryParams : Optional[dict]= None)-> str:
    """
    The function generates a string with the query parameters for the request to LUNA API

    Args:
        queryParams: dictionary with parameters

    Returns:
        query parameters string

    >>> generateStringQueryParams({"warped_image": 1, "estimate_attributes": 0})
    'warped_image=1&estimate_attributes=0'

    >>> generateStringQueryParams({"warped_image": 1, "parts": [0,1,2,5]})
    'warped_image=1&parts=0,1,2,5'

    >>> generateStringQueryParams({"user_data": "new data"})
    'user_data=new%20data'
    """
    queryStr = ""
    if queryParams is not None:
        for param in queryParams:
            if queryParams[param] is None:
                continue
            if type(queryParams[param]) in [list, tuple]:
                queryStr += "&{}={}".format(param, ",".join(str(p) for p in queryParams[param]))
            elif type(queryParams[param]) in [int, float]:
                queryStr += "&{}={}".format(param, queryParams[param])
            elif type(queryParams[param]) == bool:
                queryStr += "&{}={}".format(param, int(queryParams[param]))
            else:
                queryStr += "&{}={}".format(param, escape.url_escape(queryParams[param], plus=False))
        queryStr = queryStr[1:] if len(queryStr) > 0 else ""
    return queryStr


def processedTornadoReply(reply: LunaResponse, raiseError: bool) -> LunaResponse:
    """
    :class:`~.LunaApiException` generator.

    If *raiseError* is true and the request fails, an exception is thrown.

    Args:
        reply: response
        raiseError: throw exception or not

    Returns:
        *reply*

    Raises:
        LunaApiException: if *reply* is not success, and *raiseError* is true
    """
    if reply.success:
        return reply
    else:
        if raiseError:
            msg = "Not expected code from service: {} {} {}".format(reply.statusCode, reply.request.method,
                                                                   reply.request.url)
            raise LunaApiException(msg, reply)
        return reply


def createRequest(url: str, method: str, body: Optional[Union[str, bytes]] = None, body_producer: Generator = None,
                  json: Optional[Union[list, dict]] = None, queryParams: Optional[dict] = None,
                  headers: Optional[dict] = None, requestTimeout: int = None, connectTimeout: int = None,
                  ) -> HTTPRequest:
    """
    The function generates *tornado HTTPRequest*.

    Args:
        url: request URL
        method: request method
        body: request body
        body_producer: coroutine that generates body
        json: json
        queryParams: query parameters
        headers: headers for request
        requestTimeout: request processing timeout in seconds.
        connectTimeout: connection timeout seconds.

    Returns:
        HTTP-request. The request can be used in method  *fetch*
    """
    headers_ = {}
    if headers is not None:
        headers_.update(headers)
    url += "?" + generateStringQueryParams(queryParams)

    requestParams = {}
    if requestTimeout is not None:
        requestParams["request_timeout"] = requestTimeout
    if connectTimeout is not None:
        requestParams["connect_timeout"] = connectTimeout
    if body_producer is not None:
        requestParams["body_producer"] = body_producer

    body_ = None
    if body is not None:
        body_ = body
    elif json is not None:
        body_ = ujson.dumps(json, ensure_ascii=False)
        headers_["Content-Type"] = "application/json"

    request = HTTPRequest(url, method=method, body=body_, headers=headers_,
                          allow_nonstandard_methods=True, **requestParams)
    return request


def executeRequest(request: HTTPRequest, raiseError: bool) -> LunaResponse:
    """
    The function executes the request in the synchronous mode.

    If raiseError is True and response status code is different from 2xx, an exception is thrown.

    Args:
        request: tornado HTTPRequest to execute
        raiseError: throw exception or not

    Returns:
        :class:`~.LunaResponse` with LUNA API Answer
    """
    httpClient = httpclient.HTTPClient()
    reply = LunaResponse(httpClient.fetch(request, raise_error=False))
    return processedTornadoReply(reply, raiseError)


@gen.coroutine
def executeAsyncRequest(request: HTTPRequest, raiseError: bool) -> Generator[None, None, LunaResponse]:
    """
    The function executes the request in the asynchronous mode.

    If raiseError is True and response status code is different from 2xx, an exception is thrown.

    ** ATTENTION** This function works in tornado ioloop.

    Args:
        request: tornado HTTPRequest to execute
        raiseError: throw exception or not

    Returns:
        *tornado coroutine* with :class:`~.LunaResponse`
    """
    httpClient = httpclient.AsyncHTTPClient()
    result = yield httpClient.fetch(request, raise_error=False)
    reply = LunaResponse(result)
    return processedTornadoReply(reply, raiseError)


def makeRequest(url: str, method: str, queryParams: Optional[dict] = None,
                body: Optional[Union[str, bytes]] = None, body_producer: Generator = None,
                json: Optional[Union[list, dict]] = None, headers: Optional[dict] = None,
                requestTimeout: int = None, connectTimeout: int = None,
                asyncRequest: bool = None, raiseError: Optional[bool] = False
                ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
    """
    The function creates and fetches a request.

    Args:
        json: json
        url: request URL
        method: request method
        body: request body
        body_producer: coroutine that generates body
        queryParams: query parameters
        headers: headers for request
        raiseError: if request fails, LunaApiException is raised
        requestTimeout: request's processing  timeout in seconds.
        connectTimeout: connection timeout in seconds.
        asyncRequest: execution in asynchronous mode, disabled by default
    Returns:
        structure with status code, request and decoded Luna API response body is returned.
    """
    request = createRequest(url=url, method=method, body=body, json=json, queryParams=queryParams, headers=headers,
                            body_producer=body_producer, requestTimeout=requestTimeout, connectTimeout=connectTimeout)
    if asyncRequest:
        return executeAsyncRequest(request, raiseError)
    return executeRequest(request, raiseError)
