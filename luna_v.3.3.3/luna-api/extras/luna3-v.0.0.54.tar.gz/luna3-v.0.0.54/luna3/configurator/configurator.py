from luna3.common.requests import makeRequest
from luna3.common.base_api import BaseAPI
from luna3.common.luna_response import LunaResponse
from typing import Optional, Generator, Union


class ConfiguratorApi(BaseAPI):
    """
    Class for request to luna-configurator.

    Attributes:
        origin (str): luna-configurator protocol, host and port; default "http://127.0.0.1:5050"
        api (int): api version of  luna-configurator, default 1
        lunaRequestId: Luna-Request-Id.
        asyncRequest (bool): default mode for request asyncRequest or blocking
        requestTimeout: request processing timeout in seconds.
        connectTimeout: connection timeout seconds.
    """

    def __init__(self, origin: Optional[str] = "http://127.0.0.1:5070", api: Optional[int] = 1,
                 asyncRequest: Optional[bool] = False, lunaRequestId: Optional[str] = None,
                 requestTimeout: int = 20, connectTimeout: int = 60):
        super().__init__(origin, api, asyncRequest, lunaRequestId, requestTimeout, connectTimeout)

    def pullConfig(self, serviceName: str, filters: Optional[dict] = None, lunaRequestId: Optional[str] = None,
                   asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False, requestTimeout: int = None,
                   connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Returns an actual config which corresponding  a service and filters.

        Args:
            serviceName: service name
            filters: dict with filters
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with config for service.
        """
        return makeRequest('{}/puller/{}'.format(self.baseUri, serviceName), "GET", queryParams=filters,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getSettings(self, page: int = 1, pageSize: int = 10, serviceName: Optional[str] = None,
                    settingName: Optional[str] = None, filters: Optional[dict] = None,
                    lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                    raiseError: Optional[bool] = False, requestTimeout: int = None,
                    connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get settings with filters and pagination.

        Args:
            page: page
            pageSize: page size
            serviceName: service name
            settingName: setting name
            filters: dict with filters
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with settings.
        """
        queryParams = {"page": page, "page_size": pageSize, "service_name": serviceName, "setting_name": settingName}
        if filters is not None:
            queryParams.update(filters)
        return makeRequest('{}/settings'.format(self.baseUri), "GET", queryParams=queryParams,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def createSetting(self, settingName: str, value: Union[dict, list, str, int, float],
                      priority: float, filters: dict, description: Optional[str] = None,
                      checkSetting: bool = False,
                      lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                      raiseError: Optional[bool] = False, requestTimeout: int = None,
                      connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Create new setting.

        Args:
            settingName: setting name
            value: setting value
            filters: dict with filters
            priority: priority
            description: description
            checkSetting: validate that setting value is work. Depending on the setting some check steps will be made:
                checking connection to service, checking api version of service, checking tables existence
                in a database.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with setting id.
        """
        payload = {"priority": priority, "filters": filters, "name": settingName,
                   "value": value, "description": description}
        queryParams = {"check": int(checkSetting)}
        return makeRequest('{}/settings'.format(self.baseUri), "POST", json=payload, queryParams=queryParams,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def putSetting(self, settingId: int, settingName: Optional[str] = None,
                   value: Optional[Union[dict, list, str, int, float]] = None,
                   description: Optional[str] = None, priority: Optional[float] = None,
                   filters: Optional[dict] = None, checkSetting: bool = False, lunaRequestId: Optional[str] = None,
                   asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False, requestTimeout: int = None,
                   connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Rewrite a setting.

        Args:
            settingId: setting id
            settingName: setting name
            value: setting value
            filters: dict with filters
            priority: priority
            description: description
            checkSetting: validate that setting value is work. Depending on the setting will be make some check steps:
                checking connection to services, checking api version of services, checking to exist tables
                in a database.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return.
        """
        payload = {"priority": priority, "filters": filters if filters is not None else {}, "name": settingName,
                   "value": value, "description": description}
        queryParams = {"check": int(checkSetting)}
        return makeRequest('{}/settings/{}'.format(self.baseUri, settingId), "PUT", json=payload,
                           queryParams=queryParams,
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getSetting(self, settingId: int, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None,
                   connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get setting by id.

        Args:
            settingId: setting id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with setting.
        """
        return makeRequest('{}/settings/{}'.format(self.baseUri, settingId), "GET",
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def removeSetting(self, settingId: int, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                      raiseError: Optional[bool] = False, requestTimeout: int = None,
                      connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Remove setting.

        Args:
            settingId: setting id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return
        """
        return makeRequest('{}/settings/{}'.format(self.baseUri, settingId), "DELETE",
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getLimitations(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                       raiseError: Optional[bool] = False, requestTimeout: int = None,
                       connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get limitations.

        Args:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with limmitations.
        """
        return makeRequest('{}/settings/limitations'.format(self.baseUri), "GET",
                           asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))
