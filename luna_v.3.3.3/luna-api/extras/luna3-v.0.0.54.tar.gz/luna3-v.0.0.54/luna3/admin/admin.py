from typing import Optional, List, Generator, Union

from ..common.utils import createBasicAuth
from ..common.requests import makeRequest
from ..common.base_api import BaseAPI
from ..common.luna_response import LunaResponse


class AdminApi(BaseAPI):
    """
    Class for request to luna-attributes.

    Attributes:
        basicAuth (str): basic auth header
        origin (str): luna-admin protocol, host and port; default "http://127.0.0.1:5010"
        api (int): api version of  luna-events, default 1
        lunaRequestId: Luna-Request-Id.
        asyncRequest (bool): default mode for request asyncRequest or blocking
        requestTimeout: request processing timeout in seconds.
        connectTimeout: connection timeout seconds.
    """

    def __init__(self, login: str, password: str, origin: Optional[str] = "http://127.0.0.1:5010",
                 api: Optional[int] = 1, asyncRequest: Optional[bool] = False, lunaRequestId: Optional[str] = None,
                 requestTimeout: int = 20, connectTimeout: int = 60):
        super().__init__(origin, api, asyncRequest, lunaRequestId, requestTimeout, connectTimeout)
        self.basicAuth = createBasicAuth(login, password)

    def updateSettings(self, login: str, password: str, **kwargs):
        """
        Update settings (origin, api, asyncRequest, requestTimeout, connectTimeout, login, password).
        Args:
            login: new login
            password: new password

        Keyword Args:
            origin (str): protocol, host and port; for example, "http://127.0.0.1:8000"
            api (int): api version, 1 for default
            lunaRequestId (str): Luna-Request-Id
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.
        """
        super().updateSettings(**kwargs)
        self.basicAuth = createBasicAuth(login, password)

    def headersForRequest(self, requestId: Optional[str] = None) -> dict:
        """
        Generate headers: LUNA-Request-Id, Authorization

        Args:
            requestId: request id

        Returns:
            dict, keys are LUNA-Request-Id (if requestId is not None) and Authorization
        """
        headers = self.getRequestIdHeader(requestId)
        headers.update(self.basicAuth)
        return headers

    def gc(self, target, taskType, targetId=None, lunaRequestId: Optional[str] = None,
           asyncRequest: Optional[bool] = None,
           raiseError: Optional[bool] = False, requestTimeout: int = None,
           connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Start clean old descriptors tasks.

        Args:
            target: all or account
            taskType: descriptors only
            targetId: target id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'task_type': taskType, 'target': target, "target_id": targetId}

        return makeRequest('{}/gc'.format(self.baseUri), "POST", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def reextract(self, descriptors: Optional[List[str]] = None, lunaRequestId: Optional[str] = None,
                  asyncRequest: Optional[bool] = None,
                  raiseError: Optional[bool] = False, requestTimeout: int = None,
                  connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Start clean old descriptors tasks.

        Args:
            descriptors: list of descriptors for re-extract. If parameter is None will be run task to re-extract all
              descriptors

            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        body = None
        if descriptors is not None:
            body = {"descriptors": descriptors}
        return makeRequest('{}/reextract'.format(self.baseUri), "POST", json=body,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getTasks(self, taskType=None, page=1, pageSize=10, lunaRequestId: Optional[str] = None,
                 asyncRequest: Optional[bool] = None,
                 raiseError: Optional[bool] = False, requestTimeout: int = None,
                 connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get tasks with pagination.

        Args:
            taskType: task type (re-extract, descriptors)
            page: page
            pageSize: page size
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'task_type': taskType, 'page': page, "page_size": pageSize}
        return makeRequest('{}/tasks'.format(self.baseUri), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getTask(self, taskId, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                raiseError: Optional[bool] = False, requestTimeout: int = None,
                connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get a task.

        Args:
            taskId: task id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/tasks/{}'.format(self.baseUri, taskId), "GET",
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getTaskError(self, taskId, page=1, pageSize=10, lunaRequestId: Optional[str] = None,
                     asyncRequest: Optional[bool] = None,
                     raiseError: Optional[bool] = False, requestTimeout: int = None,
                     connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get errors of the task

        Args:
            taskId: task id
            page:  page
            pageSize: page size
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'page': page, "page_size": pageSize}
        return makeRequest('{}/tasks/{}/errors'.format(self.baseUri, taskId), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getAccounts(self, page=1, pageSize=10, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                    raiseError: Optional[bool] = False, requestTimeout: int = None,
                    connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get accounts.

        Args:
            page: page
            pageSize: page size
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.

        """
        queries = {'page': page, "page_size": pageSize}
        return makeRequest('{}/accounts'.format(self.baseUri), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getAccount(self, accountId, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None,
                   connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get an account.

        Args:
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest('{}/accounts/{}'.format(self.baseUri, accountId), "GET",
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getAccountToken(self, accountId, page=1, pageSize=10, lunaRequestId: Optional[str] = None,
                        asyncRequest: Optional[bool] = None,
                        raiseError: Optional[bool] = False, requestTimeout: int = None,
                        connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get account tokens.

        Args:

            page: page
            pageSize: page size
            accountId: account id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'page': page, "page_size": pageSize}
        return makeRequest('{}/accounts/{}/tokens'.format(self.baseUri, accountId), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getLists(self, listType=None, accountId=None, page=1, pageSize=10, lunaRequestId: Optional[str] = None,
                 asyncRequest: Optional[bool] = None,
                 raiseError: Optional[bool] = False, requestTimeout: int = None,
                 connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get lists.

        Args:
            listType: list type (persons or descriptors)
            accountId: account id
            page: page
            pageSize: page size
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'page': page, "page_size": pageSize, "type": listType, "account_id": accountId}
        return makeRequest('{}/lists'.format(self.baseUri), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getList(self, listId, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                raiseError: Optional[bool] = False, requestTimeout: int = None,
                connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get a list

        Args:
            listId: list id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.

        """
        return makeRequest('{}/lists/{}'.format(self.baseUri, listId), "GET",
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getPersons(self, accountId=None, page=1, pageSize=10, lunaRequestId: Optional[str] = None,
                   asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                   requestTimeout: int = None,
                   connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get persons.

        Args:
            accountId: account id
            page: page
            pageSize: page size
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'page': page, "page_size": pageSize, "account_id": accountId}
        return makeRequest('{}/persons'.format(self.baseUri), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getPerson(self, personId, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                  raiseError: Optional[bool] = False, requestTimeout: int = None,
                  connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get a person.

        Args:
            personId: person id
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.

        """
        return makeRequest('{}/persons/{}'.format(self.baseUri, personId), "GET",
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getGrafana(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None,
                   connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get grafana url.

        Args:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.

        """
        return makeRequest('{}/grafana'.format(self.baseUri), "GET",
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def search(self, searchParam: str, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
               raiseError: Optional[bool] = False, requestTimeout: int = None,
               connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Search account, person, list, descriptor by id or email.

        Args:
            searchParam: search param.
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'q': searchParam}
        return makeRequest('{}/search'.format(self.baseUri), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getErrorStatistics(self, resource: Optional[str] = None, error: Optional[int] = None,
                           timeLt: Optional[str] = None, timeGte: Optional[str] = None,
                           groupBy: Optional[str] = None, accountId: Optional[str] = None, server: Optional[str] = None,
                           lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                           raiseError: Optional[bool] = False, requestTimeout: int = None,
                           connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get error stats.
        Args:
            resource: one of descriptors, search, match, identify, verify
            error: Luna API error code
            timeLt: upper limit of time range.
            timeGte: lower limit of time range, including boundary.
            groupBy: grouping period
            accountId: account id
            server: server ip
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        queries = {'time__lt': timeLt, "time__gte": timeGte, "account_id": accountId, "group_by": groupBy,
                   "server": server, "resource": resource, "error": error}
        return makeRequest('{}/realtime_statistics/errors'.format(self.baseUri), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getMatchStatistics(self, resource: Optional[str] = None, limit: Optional[int] = None,
                           template: Optional[int] = None, candidate: Optional[int] = None,
                           aggregator: str = "count", timeLt: Optional[str] = None,
                           timeGte: Optional[str] = None, groupBy: Optional[str] = None,
                           accountId: Optional[str] = None, server: Optional[str] = None,
                           lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                           raiseError: Optional[bool] = False, requestTimeout: int = None,
                           connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get admin statistics about matching

        Args:

            limit: match limit
            template: template in match request. 1 - person, 0 - descriptor
            candidate: candidate in match request. 1 - dynamic list, 0 - static
            aggregator: aggregation type
            resource: one of search, match, identify, verify
            timeLt: upper limit of time range.
            timeGte: lower limit of time range, including boundary.
            groupBy: grouping period
            accountId: account id
            server: server ip
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.

        """
        queries = {'time__lt': timeLt, "time__gte": timeGte, "account_id": accountId, "group_by": groupBy,
                   "server": server, "resource": resource, "template": template, "limit": limit, "candidate": candidate,
                   "aggregator": aggregator}
        return makeRequest('{}/realtime_statistics/matching_success'.format(self.baseUri), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getExtractStatistics(self, aggregator: str = "count", countFaces: Optional[int] = None, timeLt=None,
                             timeGte=None, groupBy: Optional[str] = None, accountId: Optional[str] = None,
                             server: Optional[str] = None, lunaRequestId: Optional[str] = None,
                             asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                             requestTimeout: int = None,
                             connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """

        Args:
            aggregator:  aggregation type, one of max, min, mean, count
            countFaces: count extracted faces
            timeLt: upper limit of time range.
            timeGte: lower limit of time range, including boundary.
            groupBy: grouping period
            accountId: account id
            server: server ip
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.

        """
        queries = {'time__lt': timeLt, "time__gte": timeGte, "account_id": accountId, "group_by": groupBy,
                   "server": server, "aggregator": aggregator, "count_faces": countFaces}
        return makeRequest('{}/realtime_statistics/extract_success'.format(self.baseUri), "GET", queryParams=queries,
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getConfig(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                  raiseError: Optional[bool] = False, requestTimeout: int = None,
                  connectTimeout: int = None) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get config.

        Args:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.

        """
        return makeRequest('{}/config'.format(self.baseUri), "GET",
                           asyncRequest=self.getAsyncMode(asyncRequest), headers=self.headersForRequest(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))
