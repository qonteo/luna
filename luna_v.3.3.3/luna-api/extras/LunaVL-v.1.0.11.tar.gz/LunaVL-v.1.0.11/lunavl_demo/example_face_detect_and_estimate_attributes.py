from lunavl.httpclient import LunaHttpClient
from lunavl_demo.config import LUNA_API_LOGIN, LUNA_API_PASSWORD


def detect_faces_in_image(filename):
    """
    The function detect all faces in an image and estimates face attributes for each detection.

    Args:
        filename: path to the file
    """
    lunaClient = LunaHttpClient(login=LUNA_API_LOGIN, password=LUNA_API_PASSWORD, endPoint="http://127.0.0.1")
    faces = lunaClient.extractDescriptors(filename=filename, estimateAttributes=True)
    print(faces.body)


if __name__ == '__main__':
    detect_faces_in_image("./img_1.jpg")
