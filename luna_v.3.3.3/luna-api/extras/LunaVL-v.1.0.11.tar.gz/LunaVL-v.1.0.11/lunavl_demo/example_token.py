from lunavl.httpclient import LunaHttpClient
from lunavl_demo.config import LUNA_API_LOGIN, LUNA_API_PASSWORD

lunaClient = LunaHttpClient(login = LUNA_API_LOGIN, password = LUNA_API_PASSWORD)


def exampleToken(tokenData):
    """
    The function creates, gets and deletes one token

    Args:
         tokenData: token data
    """
    token = lunaClient.createToken(tokenData)
    tokenId = token.body["token"]
    print(tokenId)
    print(lunaClient.getToken(tokenId).body)
    lunaClient.deleteToken(tokenId)
    print(lunaClient.getToken(tokenId).body)


if __name__ == '__main__':
    exampleToken("new token")
