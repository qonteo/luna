LUNA_API_LOGIN = "hornsandhooves@ya.ru"
LUNA_API_PASSWORD = "secretpassword"
