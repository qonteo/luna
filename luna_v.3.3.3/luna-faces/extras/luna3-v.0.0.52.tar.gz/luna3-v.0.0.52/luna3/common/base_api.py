from typing import Optional, Dict, Union, Generator

from luna3.common.luna_response import LunaResponse

from .requests import makeRequest
from tornado import gen


class BaseAPI:
    """
    Base class for request to luna services.

    Attributes:
        origin (str): protocol, host and port; for example, "http://127.0.0.1:8000"
        api (int): api version of  luna, default 1
        asyncRequest (bool): default mode for request async or blocking
        lunaRequestId (str): Luna-Request-Id.
        requestTimeout: request processing timeout in seconds.
        connectTimeout: connection timeout seconds.
    """

    def __init__(self, origin: str, api: Optional[int] = 1, asyncRequest: Optional[bool] = False,
                 lunaRequestId: Optional[str] = None, requestTimeout: int = 20, connectTimeout: int = 60):
        self.origin = origin
        self.api = api
        self.asyncRequest = asyncRequest
        self.lunaRequestId = lunaRequestId
        self.requestTimeout = requestTimeout
        self.connectTimeout = connectTimeout

    def _connectionChecker(self, reply: LunaResponse) -> bool:
        """
        Checking connection

        Args:
            reply: LunaResponse
        Returns:
            status in bool
        """
        return reply.success and int(reply.json['Version']['api']) == self.api

    @gen.coroutine
    def _asyncTestConnection(self, lunaRequestId: Optional[str] = None, raiseError: Optional[bool] = False,
                             requestTimeout: int = None, connectTimeout: int = None) -> Generator:
        """
        Async test connection to current configured service.

        Args:
            lunaRequestId: External request id. Helps uniquely identifying messages,
                corresponding to particular requests, in system logs.
                Pattern: ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            *tornado coroutine* with *LunaResponse*
        """
        reply = yield self.getVersion(lunaRequestId=lunaRequestId, asyncRequest=True, raiseError=raiseError,
                                      requestTimeout=requestTimeout, connectTimeout=connectTimeout)
        return self._connectionChecker(reply)

    def testConnection(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                       raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                       ) -> Union[Generator, bool]:
        """
        Test connection to current configured service.

        Args:
            lunaRequestId: External request id. Helps uniquely identifying messages,
                corresponding to particular requests, in system logs.
                Pattern: ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest (bool): default mode for request async or blocking
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            boolean status of establish connection
        """
        if asyncRequest:
            return self._asyncTestConnection(lunaRequestId=lunaRequestId, raiseError=raiseError,
                                             requestTimeout=requestTimeout, connectTimeout=connectTimeout)
        else:
            reply = self.getVersion(lunaRequestId=lunaRequestId, asyncRequest=False, raiseError=raiseError,
                                    requestTimeout=requestTimeout, connectTimeout=connectTimeout)
            return self._connectionChecker(reply)

    def updateSettings(self, **kwargs):
        """
        Update settings (origin, api, asyncRequest, requestTimeout, connectTimeout).

        Keyword Args:
            origin (str): protocol, host and port; for example, "http://127.0.0.1:8000"
            api (int): api version, 1 for default
            lunaRequestId (str): Luna-Request-Id
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.
        """
        for setting in self.__dict__:
            if setting in kwargs and kwargs[setting] is not None:
                self.__dict__[setting] = kwargs[setting]

    @property
    def baseUri(self) -> str:
        """
        Property get base part of url.

        >>> self.baseUri
        "http://127.0.0.1:5030/1"
        """
        return "{}/{}".format(self.origin, self.api)

    def getAsyncMode(self, asyncRequest: Optional[bool] = None) -> bool:
        """
        Get final async mode.

        Args:
            asyncRequest: async mode as function argument.

        Returns:
            If async is None, return self.asyncRequest else async
        """
        return asyncRequest if asyncRequest is not None else self.asyncRequest

    def getRequestTimeout(self, requestTimeout: Optional[int] = None) -> int:
        """
        Get final requestTimeout.

        Args:
            requestTimeout: request's processing timeout in seconds.

        Returns:
            request timeout seconds.
        """
        return requestTimeout if requestTimeout is not None else self.requestTimeout

    def getConnectTimeout(self, connectTimeout: Optional[int] = None) -> int:
        """
        Get final connectTimeout.

        Args:
            connectTimeout: connection timeout in seconds.

        Returns:
            connect timeout seconds.
        """
        return connectTimeout if connectTimeout is not None else self.connectTimeout

    def getRequestIdHeader(self, lunaRequestId: Optional[str] = None) -> Optional[Dict[str, str]]:
        """
        Get final request id.

        Args:
            lunaRequestId: Luna-Request-Id as function argument. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
        Returns:
            None if both lunaRequestId and self.lunaRequestId are None or
                return dict with lunaRequestId or self.lunaRequestId
        """
        if lunaRequestId is not None:
            return {"LUNA-Request-Id": lunaRequestId}
        elif self.lunaRequestId is not None:
            return {"LUNA-Request-Id": self.lunaRequestId}
        else:
            return {}

    def getVersion(self, lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                   raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                   ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get version of luna service

        Args:
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request's processing  timeout in seconds.
            connectTimeout: connection timeout in seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with version.
        """
        return makeRequest("{}/{}".format(self.origin, "version"), "GET",
                           headers=self.getRequestIdHeader(lunaRequestId),
                           asyncRequest=self.getAsyncMode(asyncRequest), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))
