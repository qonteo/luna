"""Timers

Timer help utilities

Attributes:
    stdoutLogger (Logger): logger for objects without own logger.
"""
import sys
import time
from functools import wraps
from typing import Callable, Optional

import logbook
from tornado import gen
from .utils import isCoroutineFunction
from contextlib import contextmanager


defaultLogger = logbook.Logger('TimerStdout', logbook.DEBUG)
defaultLogger.handlers.append(logbook.StreamHandler(sys.stdout, level='DEBUG', bubble=True))


def setDefaultLogger(logger: logbook.Logger = defaultLogger):
    """
    Change global module logger

    Args:
        logger: logger
    """
    global defaultLogger
    defaultLogger = logger


def timer(extLogger: Optional[logbook.Logger] = None) -> Callable:
    """
    Decorator for function work time estimation.

    Args:
        extLogger: external logger
    Returns:
        decorated function.
    """
    extLogger = extLogger or defaultLogger

    def timerWrapper(func: callable) -> Callable:

        if isCoroutineFunction(func):
            @gen.coroutine
            @wraps(func)
            def wrap(*func_args, **func_kwargs):
                start = time.time()
                res = yield func(*func_args, **func_kwargs)
                end = time.time()
                _objectPrintLogger(func_args[0] if func_args else None, func, end - start, extLogger)
                return res
        else:
            @wraps(func)
            def wrap(*func_args, **func_kwargs):
                start = time.time()
                res = func(*func_args, **func_kwargs)
                end = time.time()
                _objectPrintLogger(func_args[0] if func_args else None, func, end - start, extLogger)
                return res

        return wrap

    return timerWrapper


@contextmanager
def contextTime(msg, logger: logbook.Logger = None):
    """
    Context manager for logging context execution time

    Args:
        msg: message
        logger: logger, by default use defaultLogger

    Yields:
        checkpoint function for logging duration between start or last checkpoint
    """
    logger = logger or defaultLogger

    def checkpoint(msg: str = msg):
        nonlocal lastCheckpoint
        _simplePrintLogger(msg, time.time() - lastCheckpoint, logger)
        lastCheckpoint = time.time()

    _simplePrintLogger('Begin block {}'.format(msg), 0, logger)
    start = time.time()
    lastCheckpoint = start

    yield checkpoint

    _simplePrintLogger('End block {}'.format(msg), time.time() - start, logger)


def _objectPrintLogger(self: Optional[object], func: callable, duration: float, extLogger: logbook.Logger) -> None:
    """
    Print timing to log

    Args:
        self: class instance with logger
        func: measured function
        duration: calling duration of function in secs
        extLogger: external logger
    """
    if hasattr(self, "logger"):
        self.logger.debug("{} time: {}".format(func.__qualname__, round(duration, 5)))
    else:
        extLogger.debug("{} time: {}".format(func.__qualname__, round(duration, 5)))


def _simplePrintLogger(msg: str, duration: float, logger: logbook.Logger) -> None:
    """
    Print timing to log

    Args:
        msg: print message
        duration: calling duration of function in secs
        extLogger: external logger
    """
    logger.debug("{} time: {}".format(msg, round(duration, 5)))
