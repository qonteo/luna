VERSION={"major": 0, "minor": 0, "patch": 52}
