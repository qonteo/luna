from luna3.common.requests import makeRequest
from luna3.common.base_api import BaseAPI
from luna3.common.luna_response import LunaResponse
from typing import Optional, List, Generator, Union
from luna3.common.http_objs import StatQuery


class EventsApi(BaseAPI):
    """
    Class for request to luna-events.

    Attributes:
        origin (str): luna-events protocol, host and port; default "http://127.0.0.1:5040"
        api (int): api version of  luna-events, default 1
        lunaRequestId: Luna-Request-Id.
        asyncRequest (bool): default mode for request async or blocking
        requestTimeout: request processing timeout in seconds.
        connectTimeout: connection timeout seconds.
    """

    def __init__(self, origin: Optional[str] = "http://127.0.0.1:5060", api: Optional[int] = 1,
                 asyncRequest: Optional[bool] = False, lunaRequestId: Optional[str] = None,
                 requestTimeout: int = 20, connectTimeout: int = 60):
        super().__init__(origin, api, asyncRequest, lunaRequestId, requestTimeout, connectTimeout)

    def putEvents(self, events: List[dict], lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                  raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                  ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Put events to luna-events.

        Args:
            events: list of events. Every event is following dict:
                .. json:object:: event
                    :showexample:

                    :property account_id UUID4: account id, required
                    :property create_time iso8601: create time, required
                    :property event_id UUID4: event id, required
                    :property descriptor_id UUID4: descriptor id, required, unique
                    :property handler_id: id of handler, which gave birth to event
                    :property attribute_id UUID4: attribute id
                    :property source street_address: source
                    :property top_similar_face_id UUID4: sim face id
                    :property top_similar_face_list UUID4: sim face list
                    :property top_similar_face_similarity float: most similar face similarity
                    :property match_result object: match result
                    :property extract_result object: extract result
                    :property face_id UUID4: face id
                    :property attach_result object: attach result
                    :property gender boolean: gender
                    :property age _range_100: age
                    :property emotion _enum_(1)_(2)_(3)_(4)_(5)_(6): emotion
                    :property ethnic_group _enum_(1)_(2)_(3)_(4): ethnic group
                    :property tags _list_str: tag list
                    :property user_data user_name: user data
                    :property sample_ids _list_(UUID4): user data

            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with response.
        """
        return makeRequest(self.baseUri + "/events", "PUT", json=events, asyncRequest=self.getAsyncMode(asyncRequest),
                           headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getEvents(self, target: Optional[List[str]] = None, createTimeGte: Optional[str] = None,
                  createTimeLt: Optional[str] = None, accountId: Optional[str] = None,
                  eventIds: Optional[List[str]] = None, handlerIds: Optional[List[str]] = None,
                  topSimilarFaceList: Optional[List[str]] = None, topSimilarFaceIds: Optional[List[str]] = None,
                  topSimilarFaceSimGte: Optional[str] = None, topSimilarFaceSimLt: Optional[str] = None,
                  ageLt: Optional[int] = None, ageGte: Optional[int] = None,
                  gender: Optional[int] = None, emotions: Optional[List[int]] = None,
                  ethnicGroups: Optional[List[int]] = None, headAngles: Optional[List[int]] = None,
                  faceIds: Optional[List[str]] = None, userData: Optional[str] = None, page: Optional[int] = 1,
                  pageSize: Optional[int] = 10, order: Optional[str] = "desc", sources: Optional[List[str]] = None,
                  tags: Optional[List[str]] = None, lunaRequestId: Optional[str] = None,
                  asyncRequest: Optional[bool] = None, raiseError: Optional[bool] = False,
                  requestTimeout: int = None, connectTimeout: int = None
                  ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get events by filters.

        Args:
            target: list of events' fields to receive instead of full events,
                fields should be from ("account_id", "create_time", "event_id", "descriptor_id",
                "attribute_id", "source", "top_similar_face_id", "top_similar_face_list",
                "top_similar_face_sim", "match_result", "extract_result", "face_id", "attach_result",
                "gender", "age", "emotions", "ethnic_group", "tags", "user_data", "sample_ids")

            createTimeGte: lower including create time boundary
            createTimeLt: upper excluding create time boundary
            accountId: event account id
            faceIds: ids of faces linked with an event
            eventIds: event ids
            handlerIds: handler ids
            userData: event user data
            sources: list of source
            tags: users tags
            topSimilarFaceList: searched Luna API list
            topSimilarFaceIds: top similar face ids
            topSimilarFaceSimGte: lower including top similarity boundary
            topSimilarFaceSimLt: upper excluding top similarity boundary
            ageLt: upper excluding age boundary
            ageGte: lower including age boundary
            gender: gender of event (0 or 1)
            emotions: dominant emotions in event (one of (1, 2, 3, 4, 5, 6) -
                      matches "anger", "disgust", "fear", "happiness", "neutral", "sadness")
            ethnicGroups: dominant ethnicity of the face ((1, 2, 3, 4) -
                                  means (indian, asian, african_american, caucasian)
            headAngles: head angle(0, 1, 2)
            page: number of result page
            pageSize: count of results in page
            order: result sort order (ask or desc)
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with response.
        """
        queries = {'target': target, "create_time__gte": createTimeGte, "account_id": accountId, "event_ids": eventIds,
                   "top_similar_face_list": topSimilarFaceList, "top_similar_face_ids": topSimilarFaceIds,
                   "top_similar_face_sim__gte": topSimilarFaceSimGte, "top_similar_face_sim__lt": topSimilarFaceSimLt,
                   "age__lt": ageLt, "age__gte": ageGte, "gender": gender, "emotions": emotions,
                   "ethnic_groups": ethnicGroups, "handler_ids": handlerIds,
                   "user_data": userData, "create_time__lt": createTimeLt, "tags": tags, "face_ids": faceIds,
                   "sources": sources, "page": page, "page_size": pageSize, "order": order}
        return makeRequest(self.baseUri + "/events", "GET", asyncRequest=self.getAsyncMode(asyncRequest),
                           queryParams=queries, headers=self.getRequestIdHeader(lunaRequestId), raiseError=raiseError,
                           requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))

    def getEventsStats(self, query: StatQuery = StatQuery(), lunaRequestId: Optional[str] = None, asyncRequest: Optional[bool] = None,
                       raiseError: Optional[bool] = False, requestTimeout: int = None, connectTimeout: int = None
                       ) -> Union[Generator[None, None, LunaResponse], LunaResponse]:
        """
        Get events statistics by aggregation (<aggregator> and <groupBy> on <target>) and filters.

        Args:
            query: query object
            lunaRequestId: External request id. Helps uniquely identifying messages, corresponding to particular
                requests, in system logs. Pattern:
                ^[0-9]{10},[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$
            asyncRequest: execution in asynchronous mode, disabled by default
            raiseError: if request fails, LunaApiException is raised
            requestTimeout: request processing timeout in seconds.
            connectTimeout: connection timeout seconds.

        Returns:
            class:`~.LunaResponse` or *tornado coroutine* with *LunaResponse*.
            In body of :class: `~.LunaResponse` will return json with response.
        """
        return makeRequest(self.baseUri + "/events/stats", "POST", asyncRequest=self.getAsyncMode(asyncRequest),
                           json=query.query, headers=self.getRequestIdHeader(lunaRequestId),
                           raiseError=raiseError, requestTimeout=self.getRequestTimeout(requestTimeout),
                           connectTimeout=self.getConnectTimeout(connectTimeout))
